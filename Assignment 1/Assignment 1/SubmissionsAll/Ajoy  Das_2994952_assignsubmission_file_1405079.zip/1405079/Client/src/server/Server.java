package server;

import protocol.Chunk;
import protocol.FileInfo;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Math.min;
import static protocol.Protocol.*;

public class Server {
    public static int clientThreadCount = 0;
    public static ArrayList<ClientThread> threads = new ArrayList<>();
    public static ArrayList<FileInfo> files = new ArrayList<>();
    public static int bufferSize = 13000;
    public static ArrayList<Integer> currentBuffers;
    public static int fileCount=1;

    public static void main(String args[])
    {
        try
        {
            ServerSocket ss = new ServerSocket(5555);
            System.out.println("Server has been started successfully.");

            while(true)
            {
                Socket s = ss.accept();	
                ClientThread wt = new ClientThread(s,s.getInetAddress().toString());
                threads.add(wt);
                Thread t = new Thread(wt);
                t.start();
                clientThreadCount++;
                System.out.println("A new client is connected. Total num of client threads = " + clientThreadCount);
            }
        }
        catch(Exception e)
        {
            System.err.println("Problem in ServerSocket operation. Exiting main.");
        }
    }
}

class ClientThread implements Runnable
{
    public Socket socket;
    public InputStream is;
    public OutputStream os;
    public BufferedReader br;
    public PrintWriter pr;

    public int studentId;
    public String ipaddr;
    public int port;

    public ClientThread(Socket s, String ipaddr)
    {
        this.socket = s;
        this.studentId = 0;
        try
        {
            this.is = this.socket.getInputStream();
            this.os = this.socket.getOutputStream();
            this.br = new BufferedReader(new InputStreamReader(this.is));
            this.pr = new PrintWriter(this.os);

        }
        catch(Exception e)
        {
            e.printStackTrace();
            println("Client isn't configured..");
        }
        this.ipaddr = ipaddr;
        println("Ip : "+ipaddr+" Port: "+port);
    }

    public void run() {
        try{
            this.socket.setSoTimeout(10000);
            String sid = br.readLine();
            println("Requested id: "+ sid);
            this.studentId = Integer.valueOf(sid);

            String port = br.readLine();
            println("Requested from port: "+ port);
            this.port = Integer.valueOf(port);

            int threadSize =Server.threads.size()-1;
            for ( int i=0; i<threadSize;i++) {
                ClientThread wt= Server.threads.get(i);
                if(wt.studentId==this.studentId && wt.ipaddr.equals(this.ipaddr) && wt.port != this.port)
                {
                    pr.println("You can't login from two different ip:port address. Connection terminated.");
                    pr.flush();
                    Server.threads.remove(threadSize);
                    return;
                }
            }
            pr.println("Welcome client with id " + this.studentId);
            pr.flush();

            while (true)
            {
                this.socket.setSoTimeout(10000);
                try {
                    FileInfo fileInfo = new FileInfo();
                    String rid = br.readLine();
                    println("Msg Received : " + rid);
                    //this.socket.setSoTimeout(300000);

                    String fileName = br.readLine();
                    String fileSize = br.readLine();
                    println("File Info : " + rid + " " + fileName + " " + fileSize);

                    boolean flag= true;
                    threadSize = Server.threads.size();
                    int i;
                    for (i = 0; i < threadSize; i++) {
                        ClientThread wt = Server.threads.get(i);
                        if (wt.studentId == Integer.valueOf(rid)) {
                            println("Found Receiver Online");
                            int currentBufferSize = 0;
                            for (FileInfo file : Server.files) {
                                currentBufferSize += file.fileSize;
                            }

                            if (currentBufferSize + Integer.valueOf(fileSize) > Server.bufferSize) {
                                flag=false;
                                break;
                            }

                            fileInfo = new FileInfo(Server.fileCount++, fileName, Integer.valueOf(fileSize), studentId, Integer.valueOf(rid));
                            Server.files.add(fileInfo);
                            println("Request Accepted.");
                            pr.println("yes");
                            pr.flush();
                            pr.println(fileInfo.chunkSize);
                            pr.flush();
                            pr.println(fileInfo.fileID);
                            pr.flush();
                            break;
                        }
                    }
                    if (i == threadSize) {
                        println("Receiver is not online. Request aborted. No: " + rid);
                        pr.println("No");
                        pr.flush();
                    }
                    else if(!flag)
                    {
                        println("Buffer Sized Crossed. Request Unsuccessful");
                        pr.println("No");
                        pr.flush();
                    }
                    else {
                        try {
                            int bytesRead = 0;
                            Boolean success = true;
                            int lastSeq=0;

                            while (fileInfo.currentSize != fileInfo.fileSize) {

                                println("Reading #2");
                                byte[] contents = new byte[fileInfo.chunkSize * 2 + 6];
                                bytesRead = is.read(contents);
                                println("Bytes read: " + bytesRead);
                                // ------------------------------------------------------------------------//
                                //01111110 | 00000000 | 00000001 | 01101000 | 01100101 | 01101100 | 01101100 | 00000000 | 00001111 | 01111110 |
                                println("Implementing protocol.....");
                                //List<Boolean> deStuffedData = getDeStuffedData(contents);
                                List<Boolean> boolArr = byteToBoolArr(contents);
                                printBoolArr(boolArr);

                                List<Boolean> stuffflag = Arrays.asList(false,true,true,true,true,true,true,false);
                                printBoolArr(stuffflag);
                                List<Boolean> lastFlag = boolArr.subList(boolArr.size()-8,boolArr.size());
                                printBoolArr(lastFlag);

                                int firstIndx = flagIndex(boolArr);
                                System.out.println("First Indx:"+firstIndx);
                                for(int j=0;j<firstIndx+8;j++)boolArr.remove(0);
                                printBoolArr(boolArr);

                                int lastIndx = flagIndex(boolArr);
                                System.out.println("Last Indx:"+lastIndx);
                                int boolarrSize = boolArr.size();
                                for(int j=lastIndx;j<boolarrSize;j++)boolArr.remove(lastIndx);
                                printBoolArr(boolArr);
                                boolArr = bitDeStuffing(boolArr);
                                printBoolArr(boolArr);

                                int seqNo = byteArrayToInt(toByteArray(boolArr.subList(0,16)));
                                System.out.println("Seq No.: "+seqNo);
                                int checkSumNo = byteArrayToInt(toByteArray(boolArr.subList(boolArr.size()-16,boolArr.size())));
                                System.out.println("ChecksumNo.: "+checkSumNo);

                                List<Boolean> dataArr = boolArr.subList(16,boolArr.size()-16);
                                System.out.println(checkCheckSum(dataArr,checkSumNo));
                                if(checkCheckSum(dataArr,checkSumNo)==false || seqNo!= lastSeq+1){
                                    println("Checksum error or Seq no error. Waiting to receive again.\n");
                                }
                                else {
                                    lastSeq = seqNo;
                                    //bytesRead = (lastIndx -firstIndx)/8 - 4;
                                    // ------------------------------------------------------------------------//

                                    byte[] dataBytes = toByteArray(dataArr);
                                    int dataRead = dataBytes.length;
                                    println("Bytes decoded: " + dataRead);
        //                            bos.write(contents, 0, bytesRead);
        //                            bos.flush();
                                    println("Sending ack for SeqNo.: "+seqNo);
                                    byte[] ackFrame = createAckFrame(seqNo);
                                    os.write(ackFrame);
                                    os.flush();

                                    fileInfo.currentSize += dataRead;
                                    fileInfo.file.add(new Chunk(dataRead, contents,bytesRead));
                                    System.out.println("FileSize:"+fileInfo.fileSize+" CurrentSize:"
                                            +fileInfo.currentSize+" DataByte:"+dataRead);
        //                            println("Sleeping.....");
        //                            sleep(11000);
        //                            println("Waking.....");
                                }
                            }
                            if (success == false) {
                                println("Connection aborted. File transfer failed.\n");
                                removeFile(fileInfo.fileID);
                                //break ;
                            } else {
                                println("Reading #3");
                                String msgRecv = br.readLine();
                                println("Msg Received : " + msgRecv);
                                if (!msgRecv.contains("sent fully")) {
                                    println("Connection aborted. File transfer failed.\n");
                                    removeFile(fileInfo.fileID);
                                    //break;
                                } else {
                                    int fileReceived = 0;
                                    FileOutputStream fos = new FileOutputStream("server_"+fileInfo.receiverId+"_"+
                                            fileInfo.fileID+"_"+fileInfo.fileName);
                                    BufferedOutputStream bos = new BufferedOutputStream(fos);

                                    for (Chunk chunks : fileInfo.file) {
                                        println("Chunk Size : " + chunks.size);
                                        printBoolArr(byteToBoolArr(fileInfo.file.get(i).chunk));
                                        fileReceived += chunks.size;
                                        bos.write(chunks.chunk, 0, chunks.size);
                                    }

                                    bos.flush();
                                    bos.close();
                                    fos.close();

                                    if (fileReceived != fileInfo.fileSize) {
                                        println("File Received: " + fileReceived + " Real size: " + fileInfo.fileSize);
                                        println("File size miss-matched. File transfer failed.\n");
                                        removeFile(fileInfo.fileID);
                                        // break;
                                    } else {

                                        println("File Received : " + fileReceived);
                                        pr.println("received fully");
                                        pr.flush();
                                        fileInfo.complete=true;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            removeFile(fileInfo.fileID);
                            System.err.println("Could not transfer file.");
                        }
                    }
                }

                catch (SocketTimeoutException e)
                {
                    //e.printStackTrace();

                    println("java.net.SocketTimeoutException: Read timed out");

                    println("File Sending to Receiver Phase. ");
                    threadSize =Server.threads.size();
                    int j;
                    FileInfo fileInfo=null;
                    int filelist = Server.files.size();
                    for (j = 0; j < filelist; j++) {
                        fileInfo = Server.files.get(j);
                        if (fileInfo.receiverId == this.studentId && fileInfo.complete) {
                            println("Found Receiver Online for sending");
                            break;
                        }
                    }
                    if(j==filelist)
                    {
                        println("No new file for this client");
                        continue;
                    }

                    this.socket.setSoTimeout(0);
                    PrintWriter rpr = this.pr;
                    BufferedReader rbr = this.br;

                    rpr.println("acceptance");
                    rpr.flush();
                    rpr.println(fileInfo.fileName);
                    rpr.flush();
                    rpr.println(fileInfo.fileSize);
                    rpr.flush();
                    rpr.println(fileInfo.senderId);
                    rpr.flush();

                    println("Info sent to receiver");
                    println("Reading #4");

                    String msgRecv = rbr.readLine();
                    println("Msg Received : "+ msgRecv);
                    if(msgRecv.contains("yes"))
                    {
                        rpr.println(fileInfo.chunkSize);
                        rpr.flush();
                        rpr.println(fileInfo.fileID);
                        rpr.flush();

                        int part =fileInfo.file.size();
                        int start=0;
                        int end=min(8,part);
                        while(start!=end){
                            for(int i = start;i<end;i++){
                                System.out.println("Sending file chunk : " + (i+1)+" No.");
                                printBoolArr(byteToBoolArr(fileInfo.file.get(i).chunk));
                                os.write(fileInfo.file.get(i).chunk);
                                os.flush();
                            }
                            try{
                                socket.setSoTimeout(3000);
                                for(int i = start;i<end;i++){
                                    System.out.println("Waiting for ack chunk : " + (i+1));
                                    byte[] contents = new byte[5];
                                    int bytesread = socket.getInputStream().read(contents);
                                    System.out.println("Ack Byte read : " + bytesread);
                                    int ackNo = decodeAckFrame(contents);
                                    System.out.println("Decoded ack: " + ackNo);
                                    if(ackNo != start+1){
                                        System.out.println("Unordered Ack received");
                                        break;
                                    }
                                    start++;
                                }
                            }
                            catch (SocketTimeoutException e2)
                            {
                                socket.setSoTimeout(0);
                                System.out.println("Ack not received. Sending again.");
                            }
                            if(start == end)
                            {
                                end=min(end+8, part);
                            }
                            System.out.println("Start: "+start+" End: "+end);
                        }
                        rpr.println("sent fully");
                        rpr.flush();

                        println("Reading #7");
                        msgRecv = rbr.readLine();
                        if (!msgRecv.contains("received fully")) {
                            println(msgRecv);
                            println("Connection aborted. FileInfo transfer failed #2.");
                        }
                        println("File sent successfully!");
                        removeFile(fileInfo.fileID);

                    }
                    else{
                        println("Requested rejected.");
                        removeFile(fileInfo.fileID);
                    }

                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            println("Connection aborted");
        }
        removeClient(this.studentId);

    }

    public void removeFile(int id)
    {
        int filelist= Server.files.size();
        for (int j = 0; j < filelist; j++) {
            FileInfo temp = Server.files.get(j);
            if (temp.fileID == id) {
                println("Removing file id: " + id);
                Server.files.remove(j);
                break;
            }
        }
    }

    public void removeClient(int id)
    {
        int threadlist= Server.threads.size();
        for (int j = 0; j < threadlist; j++) {
            ClientThread temp = Server.threads.get(j);
            if (temp.studentId == id) {
                println("Removing disconnected client id: " + id);
                Server.files.remove(j);
                break;
            }
        }
    }

    public void println(String s)
    {
        System.out.println("Client Id: #"+this.studentId+" "+s);
    }
}

