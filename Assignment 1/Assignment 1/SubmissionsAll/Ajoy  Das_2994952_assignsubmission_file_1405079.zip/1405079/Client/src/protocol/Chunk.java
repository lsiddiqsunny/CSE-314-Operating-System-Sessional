package protocol;

public class Chunk {
    public int size;
    public int chunkSize;
    public byte[] chunk;

    public Chunk(int size, byte[] chunk, int chunkSize)
    {
        this.size = size;
        this.chunkSize = chunkSize;
        this.chunk = new byte[chunkSize];
        for(int i=0;i<chunkSize;i++) {
            this.chunk[i] = chunk[i];
        }
    }
}
