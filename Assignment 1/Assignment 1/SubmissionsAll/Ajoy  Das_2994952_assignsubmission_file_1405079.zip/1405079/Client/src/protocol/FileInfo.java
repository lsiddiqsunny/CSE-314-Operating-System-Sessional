package protocol;

import java.util.ArrayList;
import java.util.Random;

import static java.lang.Math.min;

public class FileInfo {
    public int fileID;
    public String fileName;
    public int fileSize;
    public int senderId;
    public int receiverId;
    public int currentSize;
    public int chunkSize;
    public ArrayList<Chunk> file;
    public boolean complete;
    public FileInfo(int fileID, String fileName, int fileSize, int senderId, int receiverId) {
        this.fileID = fileID;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.senderId = senderId;
        this.receiverId = receiverId;
        complete = false;
        this.currentSize=0;
        Random rand = new Random();
        //this.chunkSize = min(rand.nextInt(1000) + 1 , fileSize);
        this.chunkSize = rand.nextInt(min(1024,fileSize) + 1 );
        //this.chunkSize = 1;
        file= new ArrayList<>();
    }

    public FileInfo() {
    }
}
