package protocol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.StrictMath.pow;

/**
 * Created by ajoy on 19/10/17.
 */
public class Protocol {
    public static void main(String[] args) {
        byte[] chunk = new byte[]{63,11,7,31};
        printByteArray(chunk);

        byte[] frame = createDataFrame(chunk,27,5,true);

        List<Boolean> deStuffedData = getDeStuffedData(frame);
//        byte seq = (toByteArray(deStuffedData.subList(0,8)))[0];
//        int seqNo = (int) seq & 0xFF;
        int seqNo = byteArrayToInt(toByteArray(deStuffedData.subList(0,16)));
        System.out.println("Seq No.: "+seqNo);

//        byte checkSum = (toByteArray(deStuffedData.subList(deStuffedData.size()-8,deStuffedData.size())))[0];
//        int checkSumNo = (int) checkSum & 0xFF;
        int checkSumNo = byteArrayToInt(toByteArray(deStuffedData.subList(deStuffedData.size()-16,deStuffedData.size())));
        System.out.println("ChecksumNo.: "+checkSumNo);

        List<Boolean> dataArr = deStuffedData.subList(8,deStuffedData.size()-8);
        System.out.println(checkCheckSum(dataArr,checkSumNo));
        byte[] data = toByteArray(dataArr);

        byte[] ackFrame = createAckFrame(seqNo);
        int ackNo = decodeAckFrame(ackFrame) ;
        System.out.println("Decoded ack: "+ackNo);

    }


    public static boolean checkCheckSum(List<Boolean> data, int checkSumNo)
    {
        int countedSum = countChecksum(data);
        System.out.println(countedSum);

        return checkSumNo == countedSum;
    }

    public static List<Boolean> getDeStuffedData(byte[] data)
    {
        List<Boolean> boolArr = byteToBoolArr(data);
        printBoolArr(boolArr);

        List<Boolean> flag = Arrays.asList(false,true,true,true,true,true,true,false);
        printBoolArr(flag);

//        System.out.println(boolArr.lastIndexOf(flag));

        List<Boolean> lastFlag = boolArr.subList(boolArr.size()-8,boolArr.size());
        printBoolArr(lastFlag);

        int firstIndx = flagIndex(boolArr);
        System.out.println(firstIndx);
        for(int i=0;i<firstIndx+8;i++)boolArr.remove(0);
        printBoolArr(boolArr);

        int lastIndx = flagIndex(boolArr);
        System.out.println(lastIndx);
        for(int i=lastIndx;i<lastIndx+8;i++)boolArr.remove(lastIndx);
        printBoolArr(boolArr);

        boolArr = bitDeStuffing(boolArr);
        printBoolArr(boolArr);

//        byte[] frameData = toByteArray(boolArr);
//        printByteArray(frameData);

        return boolArr;
    }

    public static int flagIndex(List<Boolean> boolArr)
    {
        int indx=-1;
        for(int i=0;i <= boolArr.size()-8;i++)
        {
            if(!boolArr.get(i) && boolArr.get(i+1) && boolArr.get(i+2) && boolArr.get(i+3)
                    && boolArr.get(i+4) && boolArr.get(i+5) && boolArr.get(i+6) &&  !boolArr.get(i+7))
            {
                indx=i;
                break;
            }
        }
        return indx;
    }

    /*public static byte[] createAckFrame(int ackNo)
    {
        System.out.println("Creating Ack frame......");

        List<Boolean> boolArr = byteToBoolArr((byte)ackNo);
        printBoolArr(boolArr);
        boolArr = bitStuffing(boolArr);
        printBoolArr(boolArr);

        List<Boolean> flag = Arrays.asList(false,true,true,true,true,true,true,false);
        printBoolArr(flag);

        boolArr.addAll(0,flag);
        boolArr.addAll(flag);
        printBoolArr(boolArr);

        byte[] frame = toByteArray(boolArr);
        printByteArray(frame);

        return frame;
    }*/

    /*public static int decodeAckFrame(byte[] bytes){
        return byteArrayToInt(new byte[]{bytes[1],bytes[2]});
    }*/

    /*public static byte[] createAckFrame(int ackNo)
    {
        System.out.println("Creating Ack frame......");
        byte[] bytes = intTOByteArr(ackNo);
        byte[] frame = new byte[]{(byte)126, bytes[0],bytes[1],(byte)126};
        printByteArray(frame);
        return frame;
    }*/

    public static int decodeAckFrame(byte[] bytes){
        List<Boolean> boolArr = byteToBoolArr(bytes);
        printBoolArr(boolArr);

        List<Boolean> stuffflag = Arrays.asList(false,true,true,true,true,true,true,false);
        //printBoolArr(stuffflag);
        List<Boolean> lastFlag = boolArr.subList(boolArr.size()-8,boolArr.size());
        //printBoolArr(lastFlag);

        int firstIndx = flagIndex(boolArr);
        System.out.println("First Indx:"+firstIndx);
        for(int j=0;j<firstIndx+8;j++)boolArr.remove(0);
        //printBoolArr(boolArr);
        int lastIndx = flagIndex(boolArr);
        System.out.println("Last Indx:"+lastIndx);
        int boolarrSize = boolArr.size();
        for(int j=lastIndx;j<boolarrSize;j++)boolArr.remove(lastIndx);
        //printBoolArr(boolArr);
        boolArr = bitDeStuffing(boolArr);
        //printBoolArr(boolArr);

        int ackNo = byteArrayToInt(toByteArray(boolArr.subList(0,16)));
        return ackNo;
    }

    public static byte[] createAckFrame(int ackNo)
    {
        System.out.println("Creating Ack frame......");

        List<Boolean> boolArr = intTOBoolList(ackNo);
        boolArr = bitStuffing(boolArr);
        List<Boolean> flag = Arrays.asList(false,true,true,true,true,true,true,false);
        printBoolArr(flag);
        boolArr.addAll(0,flag);
        boolArr.addAll(flag);
        printBoolArr(boolArr);

        byte[] bytes = toByteArray(boolArr);
        int rem = 5 - bytes.length;
        System.out.println("Remaining Length: "+rem+"\n Padding........");
        byte[] frame = new byte[5];
        for(int i=0;i<frame.length;i++)
        {
            if(i<bytes.length)frame[i]=bytes[i];
            else frame[i] = 0;
        }
        System.out.print("Created ack frame: ");
        printByteArray(frame);
        return frame;
    }

    public static byte[] createDataFrame(byte[] data, int seqNo, int chunkSize, boolean errorgen)
    {
        System.out.println("Creating Data frame......");
        List<Boolean> boolArr = byteToBoolArr(data);
        int checksum = countChecksum(boolArr);
        printBoolArr(boolArr);
        if(errorgen) {
            System.out.println("Changes for error");
            System.out.println("Before "+ boolArr.get(0));
            boolArr.set(0,!boolArr.get(0));
            System.out.println("After "+ boolArr.get(0));
            printBoolArr(boolArr);
        }

        boolArr.addAll(intTOBoolList(checksum));
        boolArr.addAll(0,  intTOBoolList(seqNo));
        printBoolArr(boolArr);

        boolArr = bitStuffing(boolArr);
        printBoolArr(boolArr);

        List<Boolean> flag = Arrays.asList(false,true,true,true,true,true,true,false);
        printBoolArr(flag);

        boolArr.addAll(0,flag);
        boolArr.addAll(flag);
        printBoolArr(boolArr);

        byte[] bytes = toByteArray(boolArr);
        int rem = chunkSize*2+6 - bytes.length;
        System.out.println("Remaining Length: "+rem+"\n Padding........");
        byte[] frame = new byte[chunkSize*2+6];
        for(int i=0;i<frame.length;i++)
        {
            if(i<bytes.length)frame[i]=bytes[i];
            else frame[i] = 0;
        }
        printByteArray(frame);
        return frame;
    }

    public static byte[] intTOByteArr(int seqNo)
    {
        return new byte[] {
                (byte) ((seqNo >> 8) & 0xFF),
                (byte) (seqNo & 0xFF)
        };
    }
    public static List<Boolean> intTOBoolList(int seqNo)
    {
        byte[] bytes =  intTOByteArr(seqNo);
        return byteToBoolArr(bytes);
    }

    public static int byteArrayToInt(byte[] b)
    {
        return   b[1] & 0xFF |
                (b[0] & 0xFF) << 8;
    }

    public static void printByteArray(byte[] bytes)
    {
        for(byte b:bytes)
        {
            System.out.print(((int)b & 0xFF)+" ");
        }
        System.out.println();
    }
    /*public static byte[] toByteArray(List<Boolean> bools) {
        BitSet bits = new BitSet(bools.size());
        for (int i = 0; i < bools.size(); i++) {
            if (bools.get(i)) {
                bits.set(i);
            }
        }

        byte[] bytes = bits.toByteArray();
        if (bytes.length * 8 >= bools.size()) {
            return bytes;
        } else {
            return Arrays.copyOf(bytes, bools.size() / 8 + (bools.size() % 8 == 0 ? 0 : 1));
        }
    }*/

    public static byte[] toByteArray(List<Boolean> data) {
        System.out.println("Data size: "+data.size()+" Mod % 8 : "+data.size()% 8);
        if(data.size()% 8 !=0)
        {
            for (int extra= 8-data.size()% 8; extra >0; extra--) data.add(0, false);
        }
        printBoolArr(data);

        byte[] bytes = new byte[data.size()/8];
        for (int i = 0; i<data.size()-1 ; i+=8) {
            int b=0;
            for(int j=7; j>=0 ;j--)
            {
                int val = data.get(i+j) ? 1:0;
                b += val*pow(2,(7-j));
                //System.out.println(data.get(i+j)+" "+b);
            }
            //System.out.println();
            bytes[(i/8)] = (byte) b;
        }

        return bytes;
    }

    public static List<Boolean> strToBoolArr(String data)
    {
        List<Boolean> arr = new ArrayList<>();
        for(int i=0;i < data.length();i++)
        {
            if(data.charAt(i)=='1')arr.add(true);
            else arr.add(false);
        }
        return arr;
    }

    public static void printBoolArr(List<Boolean> data)
    {
        for (int i=0;i<data.size();i++) {
            Boolean aBoolean= data.get(i);
            if(aBoolean) System.out.print(1);
            else System.out.print(0);

            if(i%8 ==7)System.out.print(" | ");
        }
        System.out.println();
    }
    public static List<Boolean> byteToBoolArr(byte x) {
        List<Boolean> boolArr = new ArrayList<>();
        for(int i=0;i<8;i++)
            boolArr.add( (x & (byte)(128 / Math.pow(2, i))) != 0 );

        return boolArr;
    }
    public static List<Boolean> byteToBoolArr(byte[] data) {
        List<Boolean> boolArr = new ArrayList<>();
        for ( byte x: data) {
            for(int i=0;i<8;i++)
                boolArr.add( (x & (byte)(128 / Math.pow(2, i))) != 0 );
        }

        return boolArr;
    }

    public static int countChecksum(List<Boolean> data)
    {
        int count =0;
        for (Boolean aBoolean: data) {
            if(aBoolean) count++;
        }
        System.out.println("Checksum: " + count);
        return count;
    }

    public static List<Boolean> bitStuffing(List<Boolean> data)
    {
        List<Boolean> stuffed = new ArrayList<>();
        int consecutive = 0;
        for (Boolean aBoolean: data) {
            if(aBoolean){
                consecutive++;
                stuffed.add(true);
                if(consecutive == 5) {
                    stuffed.add(false);
                    consecutive=0;
                }
            }
            else{
                stuffed.add(false);
                consecutive =0;
            }
        }

        return stuffed;
    }

    public static List<Boolean> bitDeStuffing(List<Boolean> data)
    {
        List<Boolean> deStuffed = new ArrayList<>();
        int consecutive = 0;
        for(int i=0; i < data.size(); i++)
        {
            Boolean aBoolean= data.get(i);
            if(aBoolean){
                consecutive++;
                deStuffed.add(true);
                if(consecutive == 5) {
                    consecutive=0;
                    i++;
                }
            }
            else{
                deStuffed.add(false);
                consecutive =0;
            }
        }

        return deStuffed;
    }
}
