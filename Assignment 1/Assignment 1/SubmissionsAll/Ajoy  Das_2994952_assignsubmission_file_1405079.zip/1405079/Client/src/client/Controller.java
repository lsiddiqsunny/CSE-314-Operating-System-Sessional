package client;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import protocol.Chunk;
import protocol.FileInfo;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.*;

import static java.lang.Math.min;
import static java.lang.Thread.sleep;
import static protocol.Protocol.*;

public class Controller {

    public TextArea textArea;
    public TextField textInput;
    public Button bsend;
    public TextField tFileName;
//    public TextField tFileSize;
    public Label lStudent;
    public Label lFileName;
//    public Label lFileSize;
    public Button bConnect;
    public Button bYes;
    public Button bNo;
    public CheckBox checkError;

    //    DataOutputStream outToServer;
//    BufferedReader inFromServer;
    Socket clientSocket;
    Service<Void> service;
    public static BufferedReader br = null;
    public static PrintWriter pr = null;
    Service<Void> service1;
    public boolean sendRequest= false;
    Thread t;

    public static boolean ERRORGEN = false;
    public Chunk errorChunk;
    public int errorSeq;
    String fileName;
    int fileSize;
    int senderId;
    int clientId;

    @FXML
    public void initialize() throws IOException {
        textArea.setEditable(false);
        textArea.appendText("\n");
        lFileName.setVisible(false);
//        lFileSize.setVisible(false);
        tFileName.setVisible(false);
//        tFileSize.setVisible(false);
        checkError.setVisible(false);
        bsend.setVisible(false);

        bYes.setVisible(false);
        bNo.setVisible(false);
    }

    public void sendButtonClicked(ActionEvent actionEvent) throws InterruptedException{
//        if(clientSocket.isClosed())
//        {
//            clientSocket = new Socket("localhost", 6789);
//            textArea.appendText("Connected\n");
//        }
//
//        try {
//            outToServer = new DataOutputStream(clientSocket.getOutputStream());
//            inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
//            String sentence;
//            String modifiedSentence;
//            sentence = textInput.getText();
//            outToServer.writeBytes(sentence + '\n');
//            modifiedSentence = inFromServer.readLine();
//            textArea.appendText("From Server : " + modifiedSentence + "\n");
//        } catch (Exception e) {
//            clientSocket.close();
//            textArea.appendText("Server Connection Lost\n");
//            e.printStackTrace();
//        }

        sendRequest = true;
        sleep(1000);
        while (t.isAlive()){
            System.out.println(t.isAlive());
        }

        service = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {

                return new Task<Void>() {


                    @Override
                    protected Void call() throws Exception {
//                        while (true)
//                        {
//                            System.out.println(service1.isRunning());
//                            if(service1.isRunning())continue;

                            String fileName = tFileName.getText();
                            File file = new File(fileName);
                            long fileLength = file.length();
                            FileInputStream fis = new FileInputStream(file);
                            BufferedInputStream bis = new BufferedInputStream(fis);
                            OutputStream os = clientSocket.getOutputStream();

                            try {
                                int recvrId = Integer.valueOf(textInput.getText());
                                pr.println(recvrId);
                                pr.flush();
                                pr.println(fileName);
                                pr.flush();
                                pr.println(fileLength);
                                pr.flush();

                                //clientSocket.setSoTimeout(100);
                                System.out.println("Reading #1");
                                String msgRecv = br.readLine();
                                System.out.println("Msg Received : " + msgRecv);
                                //clientSocket.setSoTimeout(0);
                                if (msgRecv.contains("yes")) {
                                    int chunkSize = Integer.valueOf(br.readLine());
                                    int fileId = Integer.valueOf(br.readLine());
                                    System.out.println("ChunkSize : " + chunkSize + " fileId : " + fileId
                                            + "\nStarting file sending");

                                    byte[] contents;
                                    //pr.println(String.valueOf(fileLength));		//These two lines are used
                                    //pr.flush();									//to send the file size in bytes.

                                    ERRORGEN = checkError.isSelected();
                                    Random rand = new Random();
                                    errorSeq = rand.nextInt(2)+3;
                                    long current = 0;
                                    int part = 0;
                                    FileInfo fileInfo = new FileInfo(fileId,fileName, (int)fileLength, clientId, recvrId);
                                    fileInfo.chunkSize = chunkSize;
                                    while (current != fileLength) {
                                        part++;
                                        System.out.println("Converting file part : " + part);
                                        int size = chunkSize;
                                        if (fileLength - current >= size)
                                            current += size;
                                        else {
                                            size = (int) (fileLength - current);
                                            current = fileLength;
                                        }

                                        contents = new byte[size];
                                        int bytesread = bis.read(contents, 0, size);
                                        System.out.println("Size : " + size + " Byte read : " + bytesread);
                                        System.out.println("Implementing protocol---------");
                                        byte[] frame = createDataFrame(contents,part,chunkSize,false);
                                        fileInfo.file.add(new Chunk(frame.length,frame,frame.length));
                                        if(ERRORGEN && errorSeq==part){
                                            frame = createDataFrame(contents,part,chunkSize,true);
                                            errorChunk = new Chunk(frame.length,frame,frame.length);
                                        }
                                    }

                                    int start=0;
                                    int end=min(8,part);
                                    boolean errorFirst = true;
                                    while(start!=end){
                                        for(int i = start;i<end;i++){
                                            System.out.println("Sending file chunk : " + (i+1)+" No.");
                                            printBoolArr(byteToBoolArr(fileInfo.file.get(i).chunk));
                                            if(ERRORGEN && i == errorSeq -1 && errorFirst) {
                                                System.out.println("ErrorSeq: "+errorSeq+" pos: "+(i+1));
                                                printBoolArr(byteToBoolArr(errorChunk.chunk));
                                                os.write(errorChunk.chunk);
                                                errorFirst =false;
                                            }else os.write(fileInfo.file.get(i).chunk);
                                            os.flush();
                                        }
                                        try{
                                            clientSocket.setSoTimeout(3000);
                                            for(int i = start;i<end;i++){
                                                System.out.println("Waiting for ack chunk : " + (i+1));
                                                contents = new byte[5];
                                                int bytesread = clientSocket.getInputStream().read(contents);
                                                System.out.println("Ack Byte read : " + bytesread);
                                                int ackNo = decodeAckFrame(contents);
                                                System.out.println("Decoded ack: " + ackNo);
                                                if(ackNo != start+1){
                                                    System.out.println("Unordered Ack received");
                                                    break;
                                                }
                                                start++;
                                            }
                                        }
                                        catch (SocketTimeoutException e)
                                        {
                                            clientSocket.setSoTimeout(0);
                                            System.out.println("Ack not received. Sending again.");
                                        }
                                        if(start == end)
                                        {
                                            end=min(end+8, part);
                                        }
                                        System.out.println("Start: "+start+" End: "+end);
                                    }
                                    /*while (current != fileLength) {
                                        System.out.println("Sending file part : " + part++);

                                        pr.println(fileId);
                                        pr.flush();

                                        System.out.println("Reading #2");
                                        msgRecv = br.readLine();
                                        System.out.println("Msg Received : " + msgRecv);

                                        int size = chunkSize;
                                        if (fileLength - current >= size)
                                            current += size;
                                        else {
                                            size = (int) (fileLength - current);
                                            current = fileLength;
                                        }

                                        contents = new byte[size];
                                        int bytesread = bis.read(contents, 0, size);
                                        System.out.println("Size : " + size + " Byte read : " + bytesread);
                                        // ------------------------------------------------------------------------//
                                        System.out.println("Implementing protocol");
                                        contents = createDataFrame(contents,part);

                                        os.write(contents);
                                        os.flush();

                                        TimeLimiter timeLimiter = new SimpleTimeLimiter();

                                        try {
                                            System.out.println("Reading #3");
                                            msgRecv = timeLimiter.callWithTimeout(br::readLine, 10, TimeUnit.SECONDS, true);
                                            System.out.println("Msg Received : " + msgRecv);
                                        } catch (TimeoutException | UncheckedTimeoutException e) {
                                            System.out.println("Timed out!");

                                            pr.println("timeout");
                                            pr.flush();
                                            return null;
                                        } catch (Exception e) {
                                            // something bad happened while reading the line
                                            e.printStackTrace();
                                        }

//                                    System.out.println("Reading #2");
//                                    msgRecv = br.readLine();
//                                    System.out.println("Msg Received : "+ msgRecv);
                                        if (!msgRecv.contains("received")) {
                                            textArea.appendText("Connection aborted. FileInfo transfer failed #1.\n");
                                            return null;
                                        }
                                        //System.out.println("Sending file ... "+(current*100)/fileLength+"% complete!");
                                    }*/

                                    pr.println("sent fully");
                                    pr.flush();

                                    System.out.println("Reading #4");
                                    msgRecv = br.readLine();
                                    if (!msgRecv.contains("received fully")) {
                                        System.out.println(msgRecv);
                                        textArea.appendText("Connection aborted. FileInfo transfer failed #2.\n");
                                        return null;
                                    }
                                    System.out.println("File sent successfully!");
                                    textArea.appendText("File sent successfully!\n");
                                } else {
                                    System.out.println("Requested aborted.");
                                    textArea.appendText("Requested rejected.\n");
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                                textArea.appendText("Connection aborted. FileInfo transfer failed #3.\n");
                            }

                            sendRequest = false;
                            runWaitingService();
                            return null;
                        }
//                    }
//
                };
            }


            @Override
            protected void cancelled() {
                super.cancelled();
                textArea.appendText("Service Canceled\n");
            }
        };

        service.start();

    }

    public void connectClicked(ActionEvent actionEvent) {
        try {
//            clientSocket = new Socket(InetAddress.getLocalHost(), 5555,InetAddress.getLocalHost(),5556);
            clientSocket = new Socket(InetAddress.getLocalHost(), 5555);

            br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            pr = new PrintWriter(clientSocket.getOutputStream());

            clientId = Integer.valueOf(textInput.getText());
            pr.println(clientId);
            pr.println("5559");
            pr.flush();

            String msgRecv = br.readLine();
            textArea.appendText(msgRecv + "\n");
            if(msgRecv.contains("Welcome"))
            {
                lStudent.setText("Receiver ID : ");
                textInput.clear();
                lFileName.setVisible(true);
//                lFileSize.setVisible(true);
                tFileName.setVisible(true);
//                tFileSize.setVisible(true);
                checkError.setVisible(true);
                bsend.setVisible(true);
                bConnect.setVisible(false);

                bYes.setVisible(false);
                bNo.setVisible(false);
            }

            runWaitingService();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void bYesClicked(ActionEvent actionEvent) {
//        if(service.isRunning()) System.out.println("Sending is on going... Aborting.");
//        else {
//            System.out.println("Started File Receiving...");
//        }

        service1 = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {

                return new Task<Void>() {

                    @Override
                    protected Void call() throws Exception {
                        System.out.println("Started File Receiving...");
                        System.out.println("Request Accepted.");

                        pr.println("yes");
                        pr.flush();
                        try {
                            System.out.println("Reading #0");
                            int chunkSize = Integer.valueOf(br.readLine());
                            int fileId = Integer.valueOf(br.readLine());
                            System.out.println("ChunkSize : " + chunkSize + " fileId : " + fileId
                                    + "\nStarting file Receiving");

                            int bytesRead = 0, currentSize = 0;
                            Boolean success = true;
                            ArrayList<Chunk> rcvfile = new ArrayList<>();

                            int lastSeq=0;
                            OutputStream os = clientSocket.getOutputStream();
                            while (currentSize != fileSize) {
                                byte[] contents = new byte[chunkSize * 2 + 6];
                                bytesRead = clientSocket.getInputStream().read(contents);
                                System.out.println("Bytes read: " + bytesRead);
                                System.out.println("Implementing protocol.....");
                                //List<Boolean> deStuffedData = getDeStuffedData(contents);
                                List<Boolean> boolArr = byteToBoolArr(contents);
                                printBoolArr(boolArr);

                                List<Boolean> stuffflag = Arrays.asList(false,true,true,true,true,true,true,false);
                                printBoolArr(stuffflag);
                                List<Boolean> lastFlag = boolArr.subList(boolArr.size()-8,boolArr.size());
                                printBoolArr(lastFlag);

                                int firstIndx = flagIndex(boolArr);
                                System.out.println("First Indx:"+firstIndx);
                                for(int j=0;j<firstIndx+8;j++)boolArr.remove(0);
                                printBoolArr(boolArr);

                                int lastIndx = flagIndex(boolArr);
                                System.out.println("Last Indx:"+lastIndx);
                                int boolarrSize = boolArr.size();
                                for(int j=lastIndx;j<boolarrSize;j++)boolArr.remove(lastIndx);
                                printBoolArr(boolArr);
                                boolArr = bitDeStuffing(boolArr);
                                printBoolArr(boolArr);

                                int seqNo = byteArrayToInt(toByteArray(boolArr.subList(0,16)));
                                System.out.println("Seq No.: "+seqNo);
                                int checkSumNo = byteArrayToInt(toByteArray(boolArr.subList(boolArr.size()-16,boolArr.size())));
                                System.out.println("ChecksumNo.: "+checkSumNo);

                                List<Boolean> dataArr = boolArr.subList(16,boolArr.size()-16);
                                System.out.println(checkCheckSum(dataArr,checkSumNo));
                                if(checkCheckSum(dataArr,checkSumNo)==false || seqNo!= lastSeq+1){
                                    System.out.println("Checksum error or Seq no error. Waiting to receive again.\n");
                                }
                                else {
                                    lastSeq = seqNo;
                                    //bytesRead = (lastIndx -firstIndx)/8 - 4;
                                    // ------------------------------------------------------------------------//

                                    byte[] dataBytes = toByteArray(dataArr);
                                    int dataRead = dataBytes.length;
                                    System.out.println("Bytes decoded: " + dataRead);
                                    //                            bos.write(contents, 0, bytesRead);
                                    //                            bos.flush();
                                    System.out.println("Sending ack for SeqNo.: "+seqNo);
                                    byte[] ackFrame = createAckFrame(seqNo);
                                    os.write(ackFrame);
                                    os.flush();

                                    currentSize += dataRead;
                                    rcvfile.add(new Chunk(dataRead, dataBytes,dataRead));

                                    System.out.println("FileSize:"+fileSize+" CurrentSize:"
                                            + currentSize+" DataByte:"+dataRead);
                                    //                            println("Sleeping.....");
                                    //                            sleep(11000);
                                    //                            println("Waking.....");
                                }

                            }

                            if (success == false) {
                                System.out.println("Connection aborted. File transfer failed.\n");
                            } else {

                                System.out.println("Reading #3");
                                String msgRecv = br.readLine();
                                System.out.println("Msg Received : " + msgRecv);
                                if (!msgRecv.contains("sent fully")) {
                                    System.out.println("Connection aborted. File transfer failed.\n");
                                } else {
                                    int fileReceived = 0;
                                    for (Chunk chunks : rcvfile) {
                                        System.out.println("Chunk Size : " + chunks.size);
                                        fileReceived += chunks.size;
                                    }
                                    System.out.println("File Received: " + fileReceived + " Real size: " + fileSize);

                                    if (fileReceived != fileSize) {
                                        System.out.println("File size miss-matched. File transfer failed.\n");
                                    } else {
                                        FileOutputStream fos = new FileOutputStream(clientId+"_"+
                                                fileId+"_"+fileName);
                                        BufferedOutputStream bos = new BufferedOutputStream(fos);

                                        for (Chunk chunks : rcvfile) {
                                            bos.write(chunks.chunk, 0, chunks.size);
                                        }
                                        bos.flush();
                                        bos.close();
                                        fos.close();

                                        System.out.println("File Received : " + fileReceived);
                                        textArea.appendText("File Received Successfully."+"\n");
                                        pr.println("received fully");
                                        pr.flush();
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        sendView();
                        runWaitingService();
                        return null;
                    }
                };
            }


            @Override
            protected void cancelled() {
                super.cancelled();
                textArea.appendText("Service1 Canceled\n");
            }
        };

        service1.start();

    }

    public void sendView()
    {
        textInput.setVisible(true);
        lFileName.setVisible(true);
//        lFileSize.setVisible(true);
        tFileName.setVisible(true);
//        tFileSize.setVisible(true);
        checkError.setVisible(true);
        bsend.setVisible(true);
        bConnect.setVisible(false);

        bYes.setVisible(false);
        bNo.setVisible(false);
    }

    public void receiveView()
    {
        bYes.setVisible(true);
        bNo.setVisible(true);

        textInput.setVisible(false);
        lFileName.setVisible(false);
//        lFileSize.setVisible(false);
        tFileName.setVisible(false);
//        tFileSize.setVisible(false);
        checkError.setVisible(false);
        bsend.setVisible(false);
    }

    public void bNoClicked(ActionEvent actionEvent) {
        pr.println("no");
        pr.flush();

        sendView();
        runWaitingService();
    }


    public void runWaitingService()
    {
        ReceiveThread wt = new ReceiveThread();
        t= new Thread(wt);
        t.start();

    }

    public void createFrame(Chunk chunk, int seqNo)
    {
        Vector<Byte> bytes = new Vector<>();
        //bytes.add(seqNo);
    }


    class ReceiveThread implements Runnable {

        public void run() {
            int i=0;
            while (!sendRequest) {
                    try {
                        clientSocket.setSoTimeout(1000);
                    String msgRecv = "";
                    try {
                        System.out.println("Waiting..... "+(i++));
                        msgRecv = br.readLine();
                        System.out.println("Msg Received : " + msgRecv);
                    } catch (SocketTimeoutException e) {
                        continue;
                    }
                    clientSocket.setSoTimeout(0);
                    fileName = br.readLine();
                    fileSize = Integer.valueOf(br.readLine());
                    senderId = Integer.valueOf(br.readLine());

                    if (msgRecv.equals("acceptance")) {
                        textArea.appendText("Do you want to receive File Name: " + fileName +
                                " of File Size: " + fileSize + " from Sender No. " + senderId + "\n");
                        System.out.println("Do you want to receive File Name: " + fileName +
                                " of File Size: " + fileSize + " from Sender No. " + senderId + "\n");

                        receiveView();
                        break;
                    }

                } catch(IOException e){
                    e.printStackTrace();
                }
            }

            try {
                clientSocket.setSoTimeout(0);
            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
}
