import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by Dipto on 9/22/2017.
 */
public class Server {
    public static void main(String[] args) throws Exception
    {
        int id=1;
        int count=0;
        ServerSocket welcomeSocket = new ServerSocket(5678);

        while(true)
        {
            Socket connectionSocket = welcomeSocket.accept();
            Workerthread wt=new Workerthread(connectionSocket,id);
            Thread t=new Thread(wt);
            t.start();
            count++;
            System.out.println("total thread"+" "+count);
            id++;




        }
        // TODO code application logic here
    }



}
class Workerthread implements Runnable{

    public int id;
    public Socket connectionsocket;
    public boolean  iserror;
   //public DataInputStream dis;
    public Workerthread(Socket connectionsocket,int id) throws IOException {
        this.id=id;
        this.connectionsocket=connectionsocket;

    }
    public int errorcheck(String check,String checksum){

        String bits1 = "";
        String bits2 = "";
        String ans = "";
        int carry = 0;
        for (int j = 0; j <= 7; j++) {
            if (check.charAt(j) == '0') {
                bits1 = bits1 + "0";
            } else {
                bits1 = bits1 + "1";
            }

        }
        for (int i = 8; i < check.length(); i = i + 8) {
            bits2="";
            ans="";
            for (int j = i; j <= i + 7; j++) {
                if (check.charAt(j) == '0') {
                    bits2 = bits2 + "0";
                } else {
                    bits2 = bits2 + "1";
                }

            }
            //System.out.println(bits1);
            //System.out.println(bits2);
            for (int k = 8 - 1; k >= 0; k--) {

                if (bits1.charAt(k) == '0' && bits2.charAt(k) == '0') {
                    if (carry == 0) {
                        ans = "0" + ans;
                    } else {
                        ans = "1" + ans;
                        carry = 0;
                    }
                } else if ((bits1.charAt(k) == '0' && bits2.charAt(k) == '1') || (bits1.charAt(k) == '1' && bits2.charAt(k) == '0')) {
                    if (carry == 0) {
                        ans = "1" + ans;
                    } else {
                        ans = "0" + ans;
                        carry = 1;
                    }
                } else if (bits1.charAt(k) == '1' && bits2.charAt(k) == '1') {
                    if (carry == 0) {
                        ans = "0" + ans;
                        carry=1;
                    } else {
                        ans = "1" + ans;
                        carry = 1;
                    }
                }
            }
            bits1=ans;
            // System.out.println("________");
            //System.out.println(bits1);
            //System.out.println("_______"+carry);




        }
        int temp1=Integer.parseInt(bits1,2);
        temp1=temp1+carry;
        //temp1=~temp1;
        int temp2=Integer.parseInt(checksum,2);
        temp2=temp2+temp1;
        ans=Integer.toBinaryString(temp2 & 255|256).substring(1);
        // System.out.println(ans);

        return temp2;
    }

    public String bitdestaff(String bit){
        int i=0;
        String bitstring="";
        while(bit.charAt(i)=='0'){
            i++;
        }
        bitstring=bit.substring(0,0)+""+bit.substring(i-1);


       // System.out.println("withoutextraxero "+bitstring);

        bitstring=bitstring.replace("01111110","");
        //System.out.println("withoutheadtaill "+bitstring);


        int bitdestafcount=0;
        bit=bitstring;

        for(int k=0;k<bit.length();k++){
            if(bit.charAt(k)=='0'){
                bitdestafcount=0;
            }
            else if(bit.charAt(k)=='1'){
                bitdestafcount++;
            }
            if(bitdestafcount==5){
                bitstring = bit.substring(0, k+1) + "" + bit.substring(k+2);

            }
            bit=bitstring;
        }
        //System.out.println("bitdestafiiinggg "+bitstring);

        int len=bitstring.length();
        bit=bitstring;
        bitstring=bit.substring(0,0)+""+bit.substring(8);
       // System.out.println("withoutseqnooooo "+bitstring);

        len=bitstring.length();
       // System.out.println("length after cuting seqno "+len);
        bit=bitstring;


        String checksm=bitstring.substring(len-8,len);
        bitstring=bit.substring(0,len-8)+""+bit.substring(len);

       // System.out.println("withoutchecksumm "+bitstring);

        int error=errorcheck(bitstring,checksm);
        //System.out.println(error);
        if(error==255) {
            System.out.println("No error in this frame ");
            iserror=false;
        }
        else{
            System.out.println("Error in this frame ");
            iserror=true;
        }





        return bitstring;
    }



    @Override
    public void run() {


        try {



            //Initialize the FileOutputStream to the output file's full path.
            FileOutputStream fos = new FileOutputStream("D:\\level 3  term 2\\computer network sessonal\\offline 1\\out.txt");
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            InputStream is = connectionsocket.getInputStream();
            DataOutputStream dos=new DataOutputStream(connectionsocket.getOutputStream());

            //No of bytes read in one read() call
            int bytesRead = 0;
            String bits="";
            int j=0;
           // String size=dis.readUTF();
            byte[] contents = new byte[29];


            while((bytesRead=is.read(contents))!=-1) {

                for (byte b : contents) {
                    // System.out.println(Integer.toBinaryString(b & 255 | 256).substring(1));
                    bits = bits + Integer.toBinaryString(b & 255 | 256).substring(1);

                }

                j++;

                String temp = "0";
                int flag = 0;//// this is for deleteing extra zero bit from right side
                for (int l = bits.length() - 1; l >= 0; l--) {
                    if (bits.charAt(l) == '1') {
                        flag = 1;
                    }
                    if (flag == 1) {
                        if (bits.charAt(l) == '0') {
                            temp = "0" + temp;
                        } else {
                            temp = "1" + temp;
                        }
                    }

                }
                System.out.println("seq no: "+j+" frame  received from sender : "+temp);
                String afterdestaff = bitdestaff(temp);

                if(!iserror) {
                    dos.writeUTF("Received frame No : " + j);
                }
                else if(iserror){
                    String str="";
                   // dos.writeUTF("Send again frame No: "+j);
                    dos.writeUTF(str);
                }
                System.out.println("seq no: "+j+" frame  after  bitdestaffing : "+ afterdestaff+"\n\n\n");

               // System.out.println(j + " no bits " + bits.length() + " " + bits);
               // System.out.println(j + " no temp " + temp.length() + " " + temp);
                //System.out.println(j + " no bitdesatff   " + afterdestaff);
                bits = "";


                int bitlength = afterdestaff.length();
               // System.out.println("bitlength " + bitlength);
                int bytesize = bitlength / 8;
               // System.out.println("bytesize " + bytesize);
                //System.out.println(bytesize+" size of array in bye of sendbit");
                byte[] receive = new byte[bytesize + 1];

                bits = "";
                int bitcnt = 0;
                int temp2;
                for (int i = 0; i < bitlength; i = i + 8) {
                    /*for (int k = i; k <= i + 7; k++) {
                        if (afterdestaff.charAt(k) == '0') {
                            bits = bits + "0";
                        } else {
                            bits = bits + "1";
                        }

                    }*/
                    bits=afterdestaff.substring(i,i+8);
                    //System.out.println(bitcnt+" this is bit pattern "+bits);
                    temp2 = Integer.parseInt(bits, 2);
                    bits="";
                   // System.out.println(temp2+" this is the integer of first pattern");
                    receive[bitcnt] = (byte) temp2;
                    //System.out.println((byte)temp+" this is the integer of first pattern");
                    bitcnt++;
                    //size=dis.readUTF();
                    //contents=new byte[Integer.parseInt(size)];

                }
                bos.write(receive, 0, bytesize+1);
            }

            bos.flush();
            connectionsocket.close();

            System.out.println("File saved successfully!");


            /*DataInputStream din=new DataInputStream(connectionsocket.getInputStream());
            DataOutputStream dout=new DataOutputStream(connectionsocket.getOutputStream());
            dout.writeUTF(fileinput);
            dout.flush();
            File f=new File((fileinput));
            FileInputStream fin=new FileInputStream(f);
            long siz=(int)f.length();
            byte b[]=new byte[1024];
            dout.writeUTF(Long.toString(siz));
            dout.flush();
            int read;
            while((read = fin.read(b)) != -1){
                dout.write(b, 0, read);
                dout.flush();
            }
           /* DataInputStream dis= new DataInputStream(connectionsocket.getInputStream());
            DataOutputStream dos=new DataOutputStream(connectionsocket.getOutputStream());
            while (true) {
                String s1 = dis.readUTF();
                String s2 = s1.toUpperCase();
                dos.writeUTF(s2);
            }*/
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

