/**
 * Created by Dipto on 9/22/2017.
 */

import java.io.*;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class Client {
    public void stopandwait() throws InterruptedException {
        TimeUnit.SECONDS.sleep(2);

    }
    public String checksumcount(String check) {

        String bits1 = "";
        String bits2 = "";
        String ans = "";
        int carry = 0;
        for (int j = 0; j <= 7; j++) {
            if (check.charAt(j) == '0') {
                bits1 = bits1 + "0";
            } else {
                bits1 = bits1 + "1";
            }

        }
        for (int i = 8; i < check.length(); i = i + 8) {
            bits2="";
            ans="";
            for (int j = i; j <= i + 7; j++) {
                if (check.charAt(j) == '0') {
                    bits2 = bits2 + "0";
                } else {
                    bits2 = bits2 + "1";
                }

            }
            //System.out.println(bits1);
            //System.out.println(bits2);
            for (int k = 8 - 1; k >= 0; k--) {

                if (bits1.charAt(k) == '0' && bits2.charAt(k) == '0') {
                    if (carry == 0) {
                        ans = "0" + ans;
                    } else {
                        ans = "1" + ans;
                        carry = 0;
                    }
                } else if ((bits1.charAt(k) == '0' && bits2.charAt(k) == '1') || (bits1.charAt(k) == '1' && bits2.charAt(k) == '0')) {
                    if (carry == 0) {
                        ans = "1" + ans;
                    } else {
                        ans = "0" + ans;
                        carry = 1;
                    }
                } else if (bits1.charAt(k) == '1' && bits2.charAt(k) == '1') {
                    if (carry == 0) {
                        ans = "0" + ans;
                        carry=1;
                    } else {
                        ans = "1" + ans;
                        carry = 1;
                    }
                }
            }
            bits1=ans;
           // System.out.println("________");
            //System.out.println(bits1);
            //System.out.println("_______"+carry);




        }
        int temp1=Integer.parseInt(bits1,2);
        temp1=temp1+carry;
        temp1=~temp1;
        ans=Integer.toBinaryString(temp1 & 255|256).substring(1);
       // System.out.println(ans);

        return ans;
    }





    public String bitstaff(String bit,int seq)
    {

        String append="";
        String payload=bit;
        //System.out.println("length of given bit "+bit.length());
        System.out.println("seq no: "+seq+" frame     to   send: "+bit);


        String bitseq=Integer.toBinaryString(seq);
        if(bitseq.length()!=8){
            for(int i=1;i<=(8-bitseq.length());i++){
                append=append+"0";
            }
            //System.out.println(bitseq+" before allign");
            bitseq=append+bitseq;
            // System.out.println(bitseq+" after allign");
            bit=bitseq+bit;
        }
        else{
            bit=bitseq+bit;
            //System.out.println(bitseq+" after allign");
        }


        //System.out.println("length of given bit after bitseq "+bit.length());
        String bitcheck=checksumcount(payload);
        //System.out.println("this is checksum "+bitcheck);
        bit=bit+bitcheck;
        //System.out.println("afterchecksumadded "+bit);









       // System.out.println("length of given bit after checksum "+bit.length());
        int bitstafcount=0;
        String savebeforebitstaff=bit;
        //StringBuilder bitflexi = new StringBuilder(bit);
        int extrabit=0;
        for(int i=0;i<bit.length();i++){
            if(bit.charAt(i)=='0'){
                bitstafcount=0;
            }
            else if(bit.charAt(i)=='1'){
                bitstafcount++;
            }
            if(bitstafcount==5){
                bit = bit.substring(0, i+1) + "0" + bit.substring(i+1, bit.length());
                extrabit++;
            }
        }
       // System.out.println("length of given bit after bistaffprev "+bit.length());
        bit="01111110"+bit+"01111110";
        append="";
        if(extrabit%8!=0){
            for(int i=1;i<=(8-(extrabit%8));i++){
                append=append+"0";
            }
        }
        bit=append+bit;
       // System.out.println("length of given bit after bistaffafter "+bit.length());
        //System.out.println("save before staff: "+savebeforebitstaff);
        System.out.println("seq no: "+seq+" frame afterstaffing: "+bit);

        return bit;
    }
    public static void main(String[] args) throws Exception
    {
        String s1;
        String s2;
        Client ob=new Client();

        Socket connectionSocket = new Socket("localhost",5678);
         String acknowledge="Received frame No";
       // String fileoutput="D:\\level 3  term 2\\computer network sessonal\\gohan.mp4";

        File file = new File("D:\\level 3  term 2\\computer network sessonal\\exp.txt");
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);

        //Get socket's output stream
        DataInputStream dis=new DataInputStream(connectionSocket.getInputStream());
        OutputStream os = connectionSocket.getOutputStream();


        //Read File Contents into contents array
        byte[] contents;
        long fileLength = file.length();

        long current = 0;

        long start = System.nanoTime();

        String bits="";
        int seq=1;
        int k=0;
        while(current!=fileLength){
            int size = 24;
            if(fileLength - current >= size)
                current += size;
            else{
                size = (int)(fileLength - current);
                current = fileLength;
            }
            contents = new byte[size];
            //String filePartName = String.format("%s.%03d", file.getName(), partCounter++);
            bis.read(contents, 0, size);


            for (byte b : contents) {
                // System.out.println(Integer.toBinaryString(b & 255 | 256).substring(1));
                bits=bits+Integer.toBinaryString(b & 255 | 256).substring(1);
            }
            String ans=ob.bitstaff(bits,seq);
            k++;
            //System.out.println("no "+k+" fn "+ ans);



            int bitlength=ans.length();
           // System.out.println("bitlength "+bitlength);
            int bytesize=bitlength/8;
            //System.out.println("bytesize "+bytesize);
            //System.out.println(bytesize+" size of array in bye of sendbit");
            byte[] sendbit=new byte[bytesize+1];

            bits="";
            int bitcnt=0;
            int temp;
            for(int i=0;i<ans.length();i=i+8){
                for(int j=i;j<=i+7;j++){
                    if(ans.charAt(j)=='0'){
                        bits=bits+"0";
                    }
                    else{
                        bits=bits+"1";
                    }

                }
                //  System.out.println("this is bit pattern "+bits);
                temp=Integer.parseInt(bits,2);
                // System.out.println(temp+" this is the integer of first pattern");
                sendbit[bitcnt]=(byte)temp;
                //System.out.println((byte)temp+" this is the integer of first pattern");
                bitcnt++;
                //System.out.println("counter "+bitcnt);
                String bitlen=Integer.toString(bitlength);
                //dos.writeUTF(bitlen);


                bits="";
            }

            //System.out.println("arrasize "+ bytesize);
            //dos.writeUTF(Integer.toString(bytesize));
            os.write(sendbit);
            //String str=dis.readUTF();

            bits="";
            bits=dis.readUTF();
            if(bits.length()>5){
                System.out.println(bits);
            }
            else{
                System.out.println("Send again frame No: "+seq);
            }
            bits="";
            //System.out.println(dis.readUTF());

            //System.out.println(acknowledge+" "+seq);


            //dos.writeUTF(filePartName);
            //os.write(contents);
            seq++;
            System.out.print("Sending file ... "+(current*100)/fileLength+"% complete!\n\n\n");
            ob.stopandwait();
        }

        os.flush();
        //File transfer done. Close the socket connection!
        connectionSocket.close();

        System.out.println("File sent succesfully!");



        /*DataInputStream dis=new DataInputStream(connectionSocket.getInputStream());
        DataOutputStream dos=new DataOutputStream(connectionSocket.getOutputStream());

        while(true)
        {
            Scanner sc=new Scanner(System.in);
            s1=sc.nextLine();
            dos.writeUTF(s1);
            s2=dis.readUTF();
            System.out.println("Server Says : "+s2);
        }*/
        // TODO code application logic here
        /*DataInputStream din=new DataInputStream(connectionSocket.getInputStream());
        DataOutputStream dout=new DataOutputStream(connectionSocket.getOutputStream());
        fileoutput=din.readUTF();
        long sz=Long.parseLong(din.readUTF());
        System.out.println ("File Size: "+(sz/(1024*1024))+" MB");

        byte b[]=new byte [1024];
        System.out.println("Receving file..");
        FileOutputStream fos=new FileOutputStream(new File(fileoutput),true);
        long bytesRead;
        do
        {
            bytesRead = din.read(b, 0, b.length);
            fos.write(b,0,b.length);
        }while(!(bytesRead<1024));
        System.out.println("Comleted");*/

    }

}
