public class Obj {
    public int file_id;
    public int std_id_from_get;
    public int file_size;
    public String file_name;

    public Obj(int file_id,int std_id_from_get,int file_size,String file_name){
        this.file_id=file_id;
        this.std_id_from_get=std_id_from_get;
        this.file_size=file_size;
        this.file_name=file_name;
    }
}
