package test;

public class YetAnotherMain {}
