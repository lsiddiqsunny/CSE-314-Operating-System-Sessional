Step 1: Run the physical layer packet switching server by 

    java SimSwitch


Step 2: Run two instances of DataLinkLayer.jar  
    
    java -jar DataLinkLayer.jar


Step 3: Properly input sender and receiver mac address in both of the instance.

Step 4: Select files from one instance and send to another. 
    
Data transfer related logs are visible in sent and received box. 
    
Once transfer is finished in receiving end you will get options to save the received file.
