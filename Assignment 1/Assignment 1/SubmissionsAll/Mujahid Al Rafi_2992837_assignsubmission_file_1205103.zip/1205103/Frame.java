/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datalinklayer;

/**
 *
 * @author rafs
 */
public class Frame {
    byte frameKind;
    byte seqNumber;
    byte ackNumber;
    byte[] payload;

    
}
