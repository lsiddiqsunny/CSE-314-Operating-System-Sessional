/**
 * Created by xyntherys on 10/31/17.
 */
public class FileStufferDestuffer {
    private String string;
}
