/**
 * Created by xyntherys on 10/1/17.
 */

public class NetworkAddress {
    String ipAddress;
    int port;

    NetworkAddress(String ipAddress, int port){
        this.ipAddress = ipAddress;
        this.port = port;
    }
}
