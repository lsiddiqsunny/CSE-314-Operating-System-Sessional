import java.io.*;
import java.net.Socket;

/**
 * Created by xyntherys on 10/1/17.
 */
public class FileSender {
    private Socket socket = null;
    private FileHandler fileHandler = new FileHandler();

    private int receiverStudentID = 0;

    private StringBuffer stringBuffer = null;
    private String fileBits = "";

    private PrintWriter printWriter = null;
    private BufferedReader bufferedReader = null;

    public FileSender(Socket socket, int receiverStudentID, FileHandler fileHandler) {
        this.socket = socket;
        this.receiverStudentID = receiverStudentID;
        this.fileHandler = fileHandler;
    }

    public FileSender(Socket socket, FileHandler fileHandler) throws IOException {
        this.socket = socket;
        this.fileHandler = fileHandler;
    }

    public String getChunkBits(byte[] bytes){
        String chunkString = "";

        for (byte b : bytes) {
            for (int mask = 0x01; mask != 0x100; mask <<= 1) {
                boolean value = (b & mask) != 0;
                int bitValue = (value) ? 1 : 0;

                chunkString = chunkString.concat(Integer.toString(bitValue));
            }
        }

        return chunkString;
    }

    public void sendFile() throws IOException {

        String fileName = fileHandler.getFileName();
        File file = new File(fileHandler.getFileLocation());

        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        printWriter = new PrintWriter(socket.getOutputStream());

//        printWriter.println(receiverStudentID);

        printWriter.println(fileName);
        printWriter.println(file.length());

        printWriter.flush();


        DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
        FileInputStream fileInputStream = new FileInputStream(file);

        dataOutputStream.flush();

        byte[] fileBytes = new byte[4096];
        int fileSize = (int) file.length();
        int read;

        while (fileSize > 4096 ) {

            read = fileInputStream.read(fileBytes);
            fileSize -= read;

            fileBits = fileBits.concat(getChunkBits(fileBytes));

            dataOutputStream.write(fileBytes);
            System.out.println(fileBits);
            System.out.println("Read " + fileSize + " bytes");
        }

        fileInputStream.read(fileBytes, 0, fileSize);

        fileBits = fileBits.concat(getChunkBits(fileBytes));


        dataOutputStream.write(fileBytes, 0, fileSize);

        fileInputStream.close();
        dataOutputStream.close();


        System.out.println(fileBits);

        System.out.println("File: " + fileHandler.getFileLocation() + " sent to Server successfully.");
    }
}
