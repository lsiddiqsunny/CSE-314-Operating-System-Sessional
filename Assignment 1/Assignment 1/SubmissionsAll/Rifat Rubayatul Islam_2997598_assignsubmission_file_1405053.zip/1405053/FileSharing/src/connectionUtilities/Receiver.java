package connectionUtilities;

import clientUtilities.Client;

public class Receiver implements Runnable
{
    private Client client;
    private ConnectionModule connectionModule;

    public Receiver(Client client, ConnectionModule connectionModule)
    {
        this.client = client;
        this.connectionModule = connectionModule;
    }

    @Override
    public void run()
    {
        while(true)
        {
            Object message = connectionModule.receive();
            client.setServerResponse(message);
        }
    }
}

