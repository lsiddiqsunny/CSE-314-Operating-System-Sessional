package connectionUtilities;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ConnectionModule
{
    private Socket socket;
    private ObjectInputStream receiverStream;
    private ObjectOutputStream senderStream;
    private boolean alive;

    public ConnectionModule(Socket socket)
    {
        this.socket = socket;
        try
        {
            senderStream = new ObjectOutputStream(this.socket.getOutputStream());
            receiverStream = new ObjectInputStream(this.socket.getInputStream());
            alive = true;
        }
        catch (IOException e)
        {
            alive = false;
            System.out.println("Error: Connection Failed.");
        }
    }

    public ConnectionModule(String host, int port)
    {
        try
        {
            this.socket = new Socket(host, port);
            senderStream = new ObjectOutputStream(this.socket.getOutputStream());
            receiverStream = new ObjectInputStream(this.socket.getInputStream());
            alive = true;
        }
        catch (IOException e)
        {
            alive = false;
            System.out.println("Error: Connection Failed.");
        }
    }

    public void send(Object object)
    {
        try
        {
            senderStream.flush();
            senderStream.writeObject(object);
        }
        catch (IOException e)
        {
            alive = false;
            System.out.println("Error: Connection Failed.");
        }
    }

    public Object receive()
    {
        try
        {
            Object object = receiverStream.readObject();
            return object;
        }
        catch (IOException e)
        {
            alive = false;
            System.out.println("Error: Connection Failed.");
        }
        catch (ClassNotFoundException e)
        {
            System.out.println("Error: Class Not Found.");
        }
        return null;
    }

    public boolean isAlive()
    {
        return alive;
    }
}

