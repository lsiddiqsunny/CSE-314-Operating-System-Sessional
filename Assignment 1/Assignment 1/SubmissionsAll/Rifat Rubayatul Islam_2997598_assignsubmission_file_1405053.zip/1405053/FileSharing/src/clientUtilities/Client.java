package clientUtilities;

import connectionUtilities.ConnectionModule;
import connectionUtilities.Receiver;
import info.ClientInfo;
import info.SystemMessage;

import java.sql.Timestamp;
import java.util.Scanner;

public class Client {

    private ClientInfo clientInfo;
    private Object serverResponse;
    private boolean readAble;
    private boolean writeAble;
    private boolean receiveAble;
    Thread thread;

    public Client(int userID, ConnectionModule connectionModule)
    {
        clientInfo = new ClientInfo(userID, connectionModule);
        serverResponse = null;
        writeAble = true;
        readAble = false;
        receiveAble = false;
    }

    public boolean login()
    {
        SystemMessage systemMessage= new SystemMessage(clientInfo.getUserID(),"_LOGIN_REQUEST_",
                new Timestamp(System.currentTimeMillis()));
        clientInfo.getConnectionModule().send(systemMessage);
        clientInfo.getConnectionModule().send(clientInfo.getUserID());
        Object message = clientInfo.getConnectionModule().receive();

        if (message instanceof SystemMessage)
        {
            if (((SystemMessage) message).getMessage().equals("_LOGIN_ACKNOWLEDGED_"))
            {
                new Thread(new Receiver(this,clientInfo.getConnectionModule())).start();
                thread = new Thread(new ClientDecisionMaker(this));
                thread.start();
                return true;
            }
            else if (((SystemMessage) message).getMessage().equals("_INVALID_ID_"))
            {
                System.out.println("Error: Invalid User ID.");
                return false;
            }
            else
            {
                System.out.println("Error: User Is Already Logged In.");
                return false;
            }

        }

        return false;
    }

    public void setReceiveAble(boolean receiveAble) {
        this.receiveAble = receiveAble;
    }

    synchronized public void setServerResponse(Object serverResponse)
    {
        if(!writeAble)
        {
            try {
                wait();
            } catch (InterruptedException e) {

            }
        }
        this.serverResponse = serverResponse;
        writeAble = false;
        readAble = true;
        notifyAll();
        if(serverResponse instanceof SystemMessage)
        {
            if(((SystemMessage) serverResponse).getMessage().equals("_FILE_SEND_REQ_"))
            {
                System.out.println("New File Request. Press 'v' to view details.");
                receiveAble = true;
            }
            else if (((SystemMessage) serverResponse).getMessage().equals("_CHUNK_ACKNOWLEDGED_") ||
                     ((SystemMessage) serverResponse).getMessage().equals("_TRANSMISSION_SUCCESSFUL_"))
            {
                thread.interrupt();
            }
        }
    }

    synchronized public Object getServerResponse()
    {
        if (!readAble)
        {
            try {
                wait();
            } catch (InterruptedException e) {

            }
        }
        Object object = serverResponse;
        readAble = false;
        writeAble = true;
        notifyAll();
        return object;
    }

    public boolean isReceiveAble() {
        return receiveAble;
    }

    public ClientInfo getClientInfo()
    {
        return clientInfo;
    }

    public static void main(String[] args)
    {
        boolean loggedIn = false;
        Scanner scanner = new Scanner(System.in);
        String choice;
        int userID;

        ConnectionModule connectionModule = new ConnectionModule("192.168.0.103",22222);
        System.out.println("Connection Established with Server.");

        while (!loggedIn)
        {
            System.out.println("Please enter your student ID to login.");
            System.out.print("Student ID:");

            userID = scanner.nextInt();

            Client client = new Client(userID, connectionModule);

            if (client.login())
            {
                try {
                    client.thread.join();
                } catch (InterruptedException e) {
                }
            }
            else
                System.out.println("Error: Login denied by the server");

            while (true) {
                System.out.print("Would you like to try again?[Y/N]:");
                choice = scanner.next();

                if (choice.equals("y") || choice.equals("Y")) {
                    loggedIn = false;
                    break;
                } else if (choice.equals("n") || choice.equals("N")) {
                    System.out.println("System terminating...");
                    System.exit(0);
                    break;
                } else
                    System.out.println("Invalid Input.");
            }

        }
    }
}
