package clientUtilities;

import info.BitProcess;
import info.DataChunk;
import info.FileInfo;
import info.SystemMessage;

import java.io.*;
import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.ListIterator;
import java.util.Scanner;

public class ClientDecisionMaker implements Runnable
{
    private Client client;
    private boolean loggedIn;
    private Scanner scanner;

    public ClientDecisionMaker(Client client)
    {
        this.client = client;
        loggedIn = true;
        scanner = new Scanner(System.in);
    }

    public boolean sendFile(FileInfo fileInfo)
    {
        int noOfBytes;
        Object serverResponse;
        SystemMessage systemMessage;
        int flag;
        int chunkNo = 0;
        DataChunk dataChunk;
        try {
            FileInputStream fileInputStream = new FileInputStream(fileInfo.getFileName());

            if (fileInputStream != null)
            {
                while (true)
                {
                    try
                    {
                        byte[] bytes = new byte[fileInfo.getMaxChunkSize()];
                        noOfBytes = fileInputStream.read(bytes);
                        chunkNo++;
                        if (noOfBytes == -1)
                        {
                            fileInputStream.close();
                            systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                                    "_TRANSMISSION_COMPLETE_", new Timestamp(System.currentTimeMillis()));
                            flag = 0;
                            client.getClientInfo().getConnectionModule().send(systemMessage);

                            try {
                                Thread.sleep(60000);
                            } catch (InterruptedException e) {
                                flag = 1;
                            }

                            if (flag == 0)
                            {
                                systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                                        "_TIME_OUT_", new Timestamp(System.currentTimeMillis()));
                                client.getClientInfo().getConnectionModule().send(systemMessage);
                                System.out.println("Error: Server Timed Out.");
                                break;
                            }

                            serverResponse = client.getServerResponse();
                            if (serverResponse instanceof SystemMessage)
                            {
                                if (((SystemMessage) serverResponse).getMessage().equals("_TRANSMISSION_SUCCESSFUL_"))
                                {
                                    System.out.println("File sent successfully.");
                                    return true;
                                }
                                else
                                {
                                    System.out.println("File transmission failed");
                                    break;
                                }
                            }
                            break;
                        }

                        flag = 0;

                        dataChunk = new DataChunk(fileInfo.getFileID(), chunkNo, noOfBytes, bytes);
                        BitSet bitSet = BitProcess.bitStuff(dataChunk);
                        client.getClientInfo().getConnectionModule().send(bitSet);

                        try {
                            Thread.sleep(30000);
                        } catch (InterruptedException e) {
                            flag = 1;
                        }

                        if (flag == 0)
                        {
                            systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                                    "_TIME_OUT_", new Timestamp(System.currentTimeMillis()));
                            client.getClientInfo().getConnectionModule().send(systemMessage);
                            System.out.println("Error: Server Timed Out.");
                            break;
                        }

                        serverResponse = client.getServerResponse();
                        if (serverResponse instanceof SystemMessage)
                        {
                            if (((SystemMessage) serverResponse).getMessage().equals("_CHUNK_RECEIVED_")){}
                        }
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error: File Not Found.");
        }
        return false;
    }

    public boolean receiveFile(FileInfo fileInfo)
    {
        SystemMessage systemMessage;
        ArrayList<DataChunk> chunkList = new ArrayList<>();

        while(client.getClientInfo().getConnectionModule().isAlive())
        {
            Object message = client.getServerResponse();
            if (message == null)
            {
                System.out.println("Oops! Something went wrong.");
                chunkList.clear();
                return false;
            }

            if (message instanceof SystemMessage)
            {
                if (((SystemMessage) message).getMessage().equals("_TIME_OUT_"))
                {
                    System.out.println("Error: Transmission cancelled due to time out.");
                    chunkList.clear();
                    return false;
                }

                else if(((SystemMessage) message).getMessage().equals("_TRANSMISSION_COMPLETE_"))
                {
                    System.out.println("File Received from Server ");
                    long checkSum = 0;
                    ListIterator<DataChunk> iterator = chunkList.listIterator();
                    while (iterator.hasNext())
                    {
                        checkSum = checkSum + iterator.next().getChunkSize();
                    }

                    if (checkSum != fileInfo.getFileSize())
                    {
                        System.out.println("Error: File Size doesn't match.");
                        chunkList.clear();
                        return false;
                    }
                    else break;
                }
            }
            else if (message instanceof DataChunk)
            {
                systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                        "_CHUNK_ACKNOWLEDGED_", new Timestamp(System.currentTimeMillis()));
                client.getClientInfo().getConnectionModule().send(systemMessage);
                chunkList.add((DataChunk) message);
            }
        }

        try {
            String file[] = (fileInfo.getFileName()).split("\\.",2);
            FileOutputStream fileOutputStream = new FileOutputStream(file[0]+fileInfo.getFileID()+"."+file[1]);
            DataChunk dataChunk;
            ListIterator<DataChunk> iterator = chunkList.listIterator();
            while (iterator.hasNext())
            {
                dataChunk = iterator.next();
                try {
                    fileOutputStream.write(dataChunk.getData(),0,dataChunk.getChunkSize());
                    fileOutputStream.flush();
                } catch (IOException e) {
                    System.out.println("Error: File Write Error.");
                    chunkList.clear();
                    return false;
                }
            }
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            chunkList.clear();
            return true;

        } catch (FileNotFoundException e) {
            System.out.println("Error: File Creation Failed.");
            chunkList.clear();
            return false;
        }
    }

    @Override
    public void run()
    {
        Object serverResponse;
        String fileName;
        String choice;
        FileInfo fileInfo;
        int receiverID;
        SystemMessage systemMessage;

        while (true)
        {
            while (loggedIn) {
                System.out.println("Press 's' to send file, Press 'l' to logout.");
                choice = scanner.next().toString();

                if (choice.equals("s") || choice.equals("S")) {
                    systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                            "_FILE_SEND_REQ_",new Timestamp(System.currentTimeMillis()));
                    client.getClientInfo().getConnectionModule().send(systemMessage);
                    System.out.print("Please enter the Receiver's Student ID:");
                    receiverID = scanner.nextInt();
                    client.getClientInfo().getConnectionModule().send(receiverID);

                    serverResponse = client.getServerResponse();
                    if (serverResponse instanceof SystemMessage) {
                        if (((SystemMessage) serverResponse).getMessage().equals("_RECEIVER_ONLINE_")) {
                            System.out.println("Receiver is Online.");
                            System.out.print("Please enter File Name:");
                            fileName = scanner.next();
                            File file = new File(fileName);
                            if (file.exists()) {
                                fileInfo = new FileInfo(fileName, file.length(), client.getClientInfo().getUserID(), receiverID);
                                client.getClientInfo().getConnectionModule().send(fileInfo);

                                serverResponse = client.getServerResponse();

                                if (((SystemMessage) serverResponse).getMessage().equals("_SEND_ACCEPTED_")) {
                                    fileInfo = (FileInfo) client.getServerResponse();
                                    sendFile(fileInfo);
                                    break;
                                } else {
                                    System.out.println("Error: File Sending is denied by the server. Please try again later.");
                                }
                            }
                            else
                            {
                                System.out.println("Error: File not found.");
                            }
                        }
                    } else {
                        System.out.println("Error: Receiver is not Online. Please, Try again later");
                    }
                } else if (choice.equals("l") || choice.equals("L")) {
                    loggedIn = false;
//                    systemMessage = new SystemMessage(client.getClientInfo().getUserID(), "_LOGOUT_REQUEST_",
//                            new Timestamp(System.currentTimeMillis()));
//                    System.out.println(systemMessage);
                    System.out.println("Logged out successfully");
                    return;
                }

                else if (choice.equals("v") || choice.equals("V"))
                {
                    serverResponse = client.getServerResponse();
                    if(serverResponse instanceof SystemMessage)
                    {
                        if (((SystemMessage) serverResponse).getMessage().equals("_FILE_SEND_REQ_"))
                        {
                            serverResponse = client.getServerResponse();
                            if(serverResponse instanceof FileInfo)
                            {
                                System.out.println("Name: "+((FileInfo) serverResponse).getFileName());
                                System.out.println("Size: "+((FileInfo) serverResponse).getFileSize());
                                System.out.println("Sender: "+((FileInfo) serverResponse).getSenderID());
                                while (true) {
                                    System.out.println("Press 'a' to accept and 'd' to decline.");
                                    choice = scanner.next().toString();

                                    if (choice.equals("a") || choice.equals("A")) {
                                        systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                                                "_REQUEST_ACCEPTED_",new Timestamp(System.currentTimeMillis()));
                                        client.getClientInfo().getConnectionModule().send(systemMessage);
                                        if(receiveFile((FileInfo) serverResponse))
                                            System.out.println("File Received Successfully");
                                        else
                                            System.out.println("File Transmission Failed");
                                        break;
                                    } else if (choice.equals("d") || choice.equals("D")) {
                                        systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                                                "_REQUEST_DENIED_",new Timestamp(System.currentTimeMillis()));
                                        client.getClientInfo().getConnectionModule().send(systemMessage);
                                        break;
                                    } else {
                                        System.out.println("Invalid Input");
                                    }
                                }
                                client.setReceiveAble(false);
                            }
                        }
                    }
                    systemMessage = new SystemMessage(client.getClientInfo().getUserID(),
                            "_REQUEST_ACCEPTED_", new Timestamp(System.currentTimeMillis()));

                    client.getClientInfo().getConnectionModule().send(systemMessage);
                }
            }
        }
    }
}