package info;

import java.io.Serializable;
import java.sql.Timestamp;

public class SystemMessage implements Serializable
{
    private int messageID;
    private String message;
    private Timestamp timestamp;

    public SystemMessage(int messageID, String message, Timestamp timestamp)
    {
        this.messageID = messageID;
        this.message = message;
        this.timestamp = timestamp;
    }

    public int getMessageID()
    {
        return messageID;
    }

    public String getMessage()
    {
        return message;
    }

    public Timestamp getTimestamp()
    {
        return timestamp;
    }
}
