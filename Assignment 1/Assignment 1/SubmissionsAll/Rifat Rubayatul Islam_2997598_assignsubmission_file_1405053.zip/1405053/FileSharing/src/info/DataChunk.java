package info;

import java.io.Serializable;

public class DataChunk implements Serializable
{
    private int fileID;
    private int chunkNo;
    private int chunkSize;
    private byte[] data;

    public DataChunk(int fileID,int chunkNo, int chunkSize, byte[] data)
    {
        this.fileID = fileID;
        this.chunkNo = chunkNo;
        this.chunkSize = chunkSize;
        this.data = data;
    }

    public int getFileID()
    {
        return fileID;
    }

    public int getChunkNo()
    {
        return chunkNo;
    }

    public int getChunkSize()
    {
        return chunkSize;
    }

    public byte[] getData()
    {
        return data;
    }
}
