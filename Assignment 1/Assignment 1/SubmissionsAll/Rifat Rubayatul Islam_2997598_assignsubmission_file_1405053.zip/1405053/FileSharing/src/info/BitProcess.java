package info;

import java.nio.*;
import java.sql.Timestamp;
import java.util.BitSet;

public class BitProcess {

    public static BitSet bitStuff(Object object)
    {
        byte[] stuffedBytes;
        ByteBuffer byteBuffer;
        BitSet bitSet;
        BitSet stuffedBit;
        int m, n;
        int trunc;

        if (object instanceof DataChunk) {
            DataChunk dataChunk = (DataChunk) object;
            stuffedBytes = new byte[dataChunk.getChunkSize() + 14];
            byteBuffer = ByteBuffer.allocate(12);
            byteBuffer.putInt(dataChunk.getFileID());
            byteBuffer.putInt(dataChunk.getChunkNo());
            byteBuffer.putInt(dataChunk.getChunkSize());
            byte[] temp = byteBuffer.array();

            for (m = 0; m < dataChunk.getChunkSize(); m++) stuffedBytes[m] = dataChunk.getData()[m];

            for (n = 0; n < 12; n++,m++) stuffedBytes[m] = temp[n];

            temp = fletcherChecksum16(stuffedBytes);

            stuffedBytes[dataChunk.getChunkSize() + 12] = temp[0];
            stuffedBytes[dataChunk.getChunkSize() + 13] = temp[1];

            bitSet = BitSet.valueOf(stuffedBytes);
            trunc = stuffedBytes.length*8 - bitSet.length();
            stuffedBit = new BitSet();

            stuffedBit.set(8,11,false);
            stuffedBit.set(11,13,true);
            stuffedBit.set(13,16,false);
        }
        else if(object instanceof SystemMessage)
        {
            SystemMessage systemMessage = (SystemMessage) object;
            byte[] message = systemMessage.getMessage().getBytes();
            stuffedBytes = new byte[message.length+29];

            for (m = 0; m < message.length; m++) stuffedBytes[m] = message[m];

            byteBuffer = ByteBuffer.allocate(4);
            byteBuffer.putInt(systemMessage.getMessageID());
            byte[] id = byteBuffer.array();
            stuffedBytes[m++]=id[0];
            stuffedBytes[m++]=id[1];
            stuffedBytes[m++]=id[2];
            stuffedBytes[m++]=id[3];

            byte[] timeStamp = systemMessage.getTimestamp().toString().getBytes();

            for(n = 0; n < timeStamp.length;n++,m++) stuffedBytes[m] = timeStamp[n];

            id = fletcherChecksum16(stuffedBytes);

            stuffedBytes[m++] = id[0];
            stuffedBytes[m++] = id[1];

            bitSet = BitSet.valueOf(stuffedBytes);
            trunc = stuffedBytes.length*8 - bitSet.length();
            stuffedBit = new BitSet();

            stuffedBit.set(8,16,false);
        }
        else if(object instanceof Integer)
        {
            byteBuffer = ByteBuffer.allocate(4);
            byteBuffer.putInt((Integer) object);
            byte[] bytes = byteBuffer.array();

            byte[] checksum = fletcherChecksum16(bytes);

            stuffedBytes = new byte[6];

            for(int i = 0; i < 4;i++) stuffedBytes[i] = bytes[i];

            stuffedBytes[4] = checksum[0];
            stuffedBytes[5] = checksum[1];

            bitSet = BitSet.valueOf(stuffedBytes);

            trunc = stuffedBytes.length*8 - bitSet.length();

            stuffedBit = new BitSet(72);

            stuffedBit.set(8,10,false);
            stuffedBit.set(10,true);
            stuffedBit.set(11,13,false);
            stuffedBit.set(13,true);
            stuffedBit.set(14,16,false);
        }
        else if (object instanceof String)
        {
            int i;
            byte[] bytes = ((String) object).getBytes();

            stuffedBytes = new byte[bytes.length + 2];

            for (i = 0 ;i < bytes.length;i++) stuffedBytes[i] = bytes[i];

            bytes = fletcherChecksum16(bytes);

            stuffedBytes[i++] = bytes[0];
            stuffedBytes[i++] = bytes[1];

            bitSet = BitSet.valueOf(stuffedBytes);
            trunc = stuffedBytes.length*8 - bitSet.length();

            stuffedBit = new BitSet();

            stuffedBit.set(8,10,false);
            stuffedBit.set(10,14,true);
            stuffedBit.set(14,16,false);
        }
        else
        {
            System.out.println("Invalid Data Type");
            return null;
        }

        int count = 0;
        boolean bit;

        stuffedBit.set(0, false);
        stuffedBit.set(1, 7, true);
        stuffedBit.set(7, false);

        for (m = 0, n = 16; m < bitSet.length(); m++, n++) {
            bit = bitSet.get(m);
            stuffedBit.set(n, bit);
            if (bit == true) count++;
            if (bit == false) count = 0;
            if (count == 5) {
                n++;
                stuffedBit.set(n, false);
                count = 0;
            }
        }
        n = n + trunc;
        stuffedBit.set(n, false);
        stuffedBit.set(n + 1, n + 7, true);
        stuffedBit.set(n + 7, false);

        return stuffedBit;
    }

    public static Object bitDestuff(BitSet stuffedBit)
    {
        byte[] stuffedBytes;
        byte[] bytes;
        byte[] checksum;
        BitSet bitSet = new BitSet();
        boolean bit;
        int count = 0,m,n;

        for(m = 0, n=0;n < 16;n++,m++) bitSet.set(m,stuffedBit.get(n));

        for (m = 16, n = 16; n < stuffedBit.length()- 8; m++, n++) {
            bit = stuffedBit.get(n);
            bitSet.set(m, bit);
            if (bit == true) count++;
            if (bit == false) count = 0;
            if (count == 5) {
                n++;
                count = 0;
            }
        }

        for( ; n < stuffedBit.length();n++,m++) bitSet.set(m,stuffedBit.get(n));

        stuffedBytes = bitSet.toByteArray();

        if (stuffedBytes[0] != 126 || stuffedBytes[stuffedBytes.length-1] != 126)
        {
            System.out.println("Header mismatch");
            return null;
        }

        if (stuffedBytes[1] == 24) {
            bytes = new byte[stuffedBytes.length - 3];
            byte[] data = new byte[stuffedBytes.length-17];
            int i;
            for ( i = 2; i < stuffedBytes.length - 3; i++)
                bytes[i - 2] = stuffedBytes[i];

            for(i = 0;i < data.length;i++) data[i] = bytes[i];

            checksum = fletcherChecksum16(bytes);

            if (checksum[0] != stuffedBytes[stuffedBytes.length - 3] || checksum[1] != stuffedBytes[stuffedBytes.length - 2])
            {
                System.out.println("Checksum Mismatch");
                return null;
            }

            byte[] id = new byte[4];

            id[0] = stuffedBytes[stuffedBytes.length - 15];
            id[1] = stuffedBytes[stuffedBytes.length - 14];
            id[2] = stuffedBytes[stuffedBytes.length - 13];
            id[3] = stuffedBytes[stuffedBytes.length - 12];

            ByteBuffer bb = ByteBuffer.wrap(id);
            int fileID = bb.getInt();

            id[0] = stuffedBytes[stuffedBytes.length - 11];
            id[1] = stuffedBytes[stuffedBytes.length - 10];
            id[2] = stuffedBytes[stuffedBytes.length - 9];
            id[3] = stuffedBytes[stuffedBytes.length - 8];

            bb = ByteBuffer.wrap(id);
            int chunkNo = bb.getInt();

            id[0] = stuffedBytes[stuffedBytes.length - 7];
            id[1] = stuffedBytes[stuffedBytes.length - 6];
            id[2] = stuffedBytes[stuffedBytes.length - 5];
            id[3] = stuffedBytes[stuffedBytes.length - 4];

            bb = ByteBuffer.wrap(id);
            int chunkSize = bb.getInt();
            DataChunk dataChunk = new DataChunk(fileID, chunkNo, chunkSize, data);

            return dataChunk;
        }
        else if (stuffedBytes[1] == 0)
        {
            bytes = new byte[stuffedBytes.length - 3];

            for (int i = 2; i < stuffedBytes.length - 3; i++)
                bytes[i - 2] = stuffedBytes[i];

            checksum = fletcherChecksum16(bytes);

            if (checksum[0] != stuffedBytes[stuffedBytes.length - 3] || checksum[1] != stuffedBytes[stuffedBytes.length - 2])
            {
                System.out.println("Checksum Mismatch");
                return null;
            }


            String message = new String(bytes,0,bytes.length-29);
            ByteBuffer idBuffer = ByteBuffer.wrap(bytes,bytes.length-29,4);

            int messageID = idBuffer.getInt();
            String time = new String(bytes,bytes.length-25,23);
            Timestamp timestamp = Timestamp.valueOf(time);

            SystemMessage systemMessage = new SystemMessage(messageID,message,timestamp);
            return systemMessage;
        }
        else if(stuffedBytes[1] == 36)
        {
            ByteBuffer byteBuffer = ByteBuffer.wrap(stuffedBytes,2,4);
            int id = byteBuffer.getInt();

            byteBuffer = ByteBuffer.allocate(4);
            byteBuffer.putInt(id);

            checksum = fletcherChecksum16(byteBuffer.array());

            if (checksum[0] != stuffedBytes[6] || checksum[1] != stuffedBytes[7])
            {
                System.out.println("Checksum Mismatch");
                return null;
            }
            return id;
        }
        else if(stuffedBytes[1] == 60)
        {
            String message = new String(stuffedBytes,2,stuffedBytes.length-4);
            bytes = message.getBytes();

            checksum = fletcherChecksum16(bytes);

            if (checksum[0] != stuffedBytes[stuffedBytes.length-3] || checksum[1] != stuffedBytes[stuffedBytes.length-2])
            {
                System.out.println("Checksum Mismatch");
                return null;
            }

            return message;
        }
        System.out.println("Invalid Data Type");
        return null;
    }

    public static byte[] fletcherChecksum16(byte[] bytes)
    {
        int sum0 = 0,sum1 = 0;
        for (int i = 0;i < bytes.length; i++)
        {
            sum0 = sum0 + bytes[i];
            if (sum0 > 255) sum0 -= 255;
            sum1 = sum0 + sum1;
            if (sum1 > 255) sum1 -= 255;
        }
        ByteBuffer byteBuffer = ByteBuffer.allocate(8);
        byteBuffer.putInt(sum0);
        byteBuffer.putInt(sum1);
        byte[] checksum = new byte[2];
        checksum[0] = byteBuffer.get(3);
        checksum[1] = byteBuffer.get(7);
        return checksum;
    }
}
