package info;

import java.io.Serializable;
import connectionUtilities.ConnectionModule;
import serverUtilities.ServiceStation;

public class ClientInfo implements Serializable
{
    private int userID;
    private ConnectionModule connectionModule;
    private ServiceStation serviceStation;

    public ClientInfo(int userID, ConnectionModule connectionModule)
    {
        this.userID = userID;
        this.connectionModule = connectionModule;
    }

    public ClientInfo(int userID, ConnectionModule connectionModule, ServiceStation serviceStation)
    {
        this.userID = userID;
        this.connectionModule = connectionModule;
        this.serviceStation = serviceStation;
    }

    public ServiceStation getServiceStation() {
        return serviceStation;
    }

    public int getUserID()
    {
        return userID;
    }

    public ConnectionModule getConnectionModule()
    {
        return connectionModule;
    }
}

