package info;

import java.io.Serializable;

public class FileInfo implements Serializable
{
    private int fileID;
    private long fileSize;
    private String fileName;
    private int senderID;
    private int receiverID;
    private int indexOfFile;
    private int maxChunkSize;

    public FileInfo(int fileID, long fileSize, String fileName, int senderID, int receiverID,
                    int indexOfFile, int maxChunkSize)
    {
        this.fileID = fileID;
        this.fileSize = fileSize;
        this.fileName = fileName;
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.indexOfFile = indexOfFile;
        this.maxChunkSize = maxChunkSize;
    }

    public FileInfo(String fileName, long fileSize, int senderID, int receiverID)
    {
        this.fileSize = fileSize;
        this.fileName = fileName;
        this.senderID = senderID;
        this.receiverID = receiverID;
    }

    public void setFileID(int fileID)
    {
        this.fileID = fileID;
    }

    public void setIndexOfFile(int indexOfFile)
    {
        this.indexOfFile = indexOfFile;
    }

    public void setMaxChunkSize(int maxChunkSize)
    {
        this.maxChunkSize = maxChunkSize;
    }

    public int getFileID()
    {
        return fileID;
    }

    public long getFileSize()
    {
        return fileSize;
    }

    public String getFileName()
    {
        return fileName;
    }

    public int getSenderID()
    {
        return senderID;
    }

    public int getReceiverID()
    {
        return receiverID;
    }

    public int getIndexOfFile()
    {
        return indexOfFile;
    }

    public int getMaxChunkSize() {
        return maxChunkSize;
    }
}

