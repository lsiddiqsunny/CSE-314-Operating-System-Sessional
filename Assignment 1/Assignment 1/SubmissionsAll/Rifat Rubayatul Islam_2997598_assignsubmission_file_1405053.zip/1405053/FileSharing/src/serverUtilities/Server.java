package serverUtilities;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import connectionUtilities.ConnectionModule;
import info.ClientInfo;
import info.DataChunk;
import info.FileInfo;
import info.SystemMessage;

public class Server
{
    private static HashMap<String, ClientInfo> clientTable;
    private List<ArrayList<DataChunk>> fileList;
    private ServerSocket serverSocket;
    private static int fileID;
    private static long emptySpace;
    private static final long bufferSize = 1073741824;

    public Server(int port)
    {
        clientTable = new HashMap<>();
        fileList = Collections.synchronizedList(new ArrayList<ArrayList<DataChunk>>());
        fileID = 0;
        emptySpace = bufferSize;
        try
        {
            serverSocket = new ServerSocket(port);
            System.out.println("Server Initiated.");

            while(true)
            {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connection Established with Client at Port " + clientSocket.getPort());
                ConnectionModule connectionModule = new ConnectionModule(clientSocket);
                new Thread(new ServiceStation(clientTable, fileList, connectionModule)).start();
            }
        }
        catch (IOException e)
        {
            System.out.println("Error: Connection Failed.");
        }
    }

    public static void sendFile(FileInfo fileInfo)
    {
        SystemMessage systemMessage;

        if (clientTable.containsKey(Integer.toString(fileInfo.getReceiverID()))) {

            ClientInfo receiverInfo = clientTable.get(Integer.toString(fileInfo.getReceiverID()));
            systemMessage = new SystemMessage(receiverInfo.getUserID(), "_FILE_SEND_REQ_", new Timestamp(System.currentTimeMillis()));
            receiverInfo.getConnectionModule().send(systemMessage);
            receiverInfo.getConnectionModule().send(fileInfo);
            clientTable.get(Integer.toString(fileInfo.getReceiverID())).getServiceStation().setReceivedFileInfo(fileInfo);
        }
    }

    public static void occupySpace(long space)
    {
        emptySpace = emptySpace - space;
    }

    public static void freeSpace(long space)
    {
        emptySpace = emptySpace + space;
    }

    public static int getFileID()
    {
        fileID++;
        return fileID;
    }

    public static long getEmptySpace()
    {
        return emptySpace;
    }

    public static void main(String[] args)
    {
        new Server(22222);
    }

}
