package serverUtilities;

import info.*;

import java.sql.Timestamp;
import java.util.*;

public class ServerTransmissionController implements Runnable {

    private HashMap<String, ClientInfo> clientTable;
    private List<ArrayList<DataChunk>> fileList;
    private FileInfo fileInfo;
    private ClientInfo senderInfo;
    private ClientInfo receiverInfo;

    public ServerTransmissionController(HashMap<String, ClientInfo> clientTable, List<ArrayList<DataChunk>> fileList, FileInfo fileInfo)
    {
        this.clientTable = clientTable;
        this.fileList = fileList;
        this.fileInfo = fileInfo;

        this.senderInfo = clientTable.get(Integer.toString(fileInfo.getSenderID()));
        this.receiverInfo = clientTable.get(Integer.toString(fileInfo.getReceiverID()));
    }

    @Override
    public void run()
    {
        ArrayList<DataChunk> chunkList = fileList.get(fileInfo.getIndexOfFile());
        SystemMessage systemMessage;

        while(senderInfo.getConnectionModule().isAlive())
        {
            Object message = senderInfo.getConnectionModule().receive();

            if (message == null)
            {
                System.out.println("Oops! Something went wrong.");
                chunkList.clear();
                return;
            }

            if (message instanceof SystemMessage)
            {
                if (((SystemMessage) message).getMessage().equals("_TIME_OUT_"))
                {
                    System.out.println("Error: Transmission cancelled due to time out.");
                    chunkList.clear();
                    return;
                }

                else if(((SystemMessage) message).getMessage().equals("_TRANSMISSION_COMPLETE_"))
                {
                    System.out.println("File Received from Client "+ senderInfo.getUserID());
                    long checkSum = 0;
                    ListIterator<DataChunk> iterator = chunkList.listIterator();
                    while (iterator.hasNext())
                    {
                        checkSum = checkSum + iterator.next().getChunkSize();
                    }

                    if (checkSum != fileInfo.getFileSize())
                    {
                        systemMessage = new SystemMessage(((SystemMessage) message).getMessageID(),
                                "_TRANSMISSION_FAILED_", new Timestamp(System.currentTimeMillis()));
                        senderInfo.getConnectionModule().send(systemMessage);
                        System.out.println("Error: File Size doesn't match.");
                        chunkList.clear();
                        return;
                    }
                    else
                    {
                        systemMessage = new SystemMessage(((SystemMessage) message).getMessageID(),
                                "_TRANSMISSION_SUCCESSFUL_", new Timestamp(System.currentTimeMillis()));
                        senderInfo.getConnectionModule().send(systemMessage);
                        Server.sendFile(fileInfo);
                    }
                }
            }
            else if (message instanceof BitSet)
            {
                DataChunk dataChunk = (DataChunk) BitProcess.bitDestuff((BitSet) message);
                systemMessage = new SystemMessage(senderInfo.getUserID(),
                        "_CHUNK_ACKNOWLEDGED_", new Timestamp(System.currentTimeMillis()));
                senderInfo.getConnectionModule().send(systemMessage);
                chunkList.add(dataChunk);
            }
        }
    }
}
