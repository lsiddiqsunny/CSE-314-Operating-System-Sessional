package serverUtilities;

import connectionUtilities.ConnectionModule;
import info.ClientInfo;
import info.DataChunk;
import info.FileInfo;
import info.SystemMessage;

import java.sql.Timestamp;
import java.util.*;

public class ServiceStation implements Runnable
{
    private HashMap<String, ClientInfo> clientTable;
    private List<ArrayList<DataChunk>> fileList;
    private ConnectionModule connectionModule;
    private Random random;
    private FileInfo receivedFileInfo;

    public ServiceStation(HashMap<String, ClientInfo> clientTable, List<ArrayList<DataChunk>> fileList,
                          ConnectionModule connectionModule)
    {
        this.clientTable = clientTable;
        this.fileList = fileList;
        this.connectionModule = connectionModule;
        random = new Random();
        receivedFileInfo = null;
    }

    public void setReceivedFileInfo(FileInfo receivedFileInfo) {
        this.receivedFileInfo = receivedFileInfo;
    }

    public boolean sendFile(FileInfo fileInfo)
    {
        ArrayList<DataChunk> chunkList = fileList.get(fileInfo.getIndexOfFile());
        receivedFileInfo = fileInfo;
        SystemMessage systemMessage;
        Object message;
        ClientInfo receiverInfo = clientTable.get(Integer.toString(fileInfo.getReceiverID()));
        int flag = 0;

        ListIterator<DataChunk> iterator = chunkList.listIterator();
        while (iterator.hasNext())
        {
            flag = 1;
            receiverInfo.getConnectionModule().send(iterator.next());

            if (flag == 0)
            {
                systemMessage = new SystemMessage(receiverInfo.getUserID(),
                        "_TIME_OUT_", new Timestamp(System.currentTimeMillis()));
                receiverInfo.getConnectionModule().send(systemMessage);
                System.out.println("Error: Receiver Timed Out.");
                return false;
            }
            message = receiverInfo.getConnectionModule().receive();
            if (message instanceof SystemMessage)
            {
                if (((SystemMessage) message).getMessage().equals("_CHUNK_ACKNOWLEDGED_"))
                    continue;
                else
                    System.out.println(((SystemMessage) message).getMessage());
            }
        }
        systemMessage = new SystemMessage(receiverInfo.getUserID(),
                "_TRANSMISSION_COMPLETE_", new Timestamp(System.currentTimeMillis()));
        receiverInfo.getConnectionModule().send(systemMessage);
        chunkList.clear();
        return true;
    }

    @Override
    public void run()
    {
        String userID;
        FileInfo fileInfo;
        boolean loggedIn = false;
        ClientInfo senderInfo;
        Object receivedMessage;
        SystemMessage systemMessage;

        while(!loggedIn && connectionModule.isAlive())
        {
            receivedMessage = connectionModule.receive();
            if (receivedMessage instanceof SystemMessage)
            {
                if(((SystemMessage) receivedMessage).getMessage().equals("_LOGIN_REQUEST_"))
                {
                    userID = connectionModule.receive().toString();

                    if (clientTable.containsKey(userID))
                    {
                        systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                "_LOGIN_DENIED_",new Timestamp(System.currentTimeMillis()));
                        connectionModule.send(systemMessage);
                    }
                    else
                    {
                        senderInfo = new ClientInfo(new Integer(userID), connectionModule, this);
                        clientTable.put(userID, senderInfo);
                        systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                "_LOGIN_ACKNOWLEDGED_",new Timestamp(System.currentTimeMillis()));
                        connectionModule.send(systemMessage);
                        loggedIn = true;
                    }
                }
            }

        }

        while (loggedIn && connectionModule.isAlive())
        {
            receivedMessage = connectionModule.receive();

            if (receivedMessage instanceof SystemMessage)
            {
                if (((SystemMessage) receivedMessage).getMessage().equals("_FILE_SEND_REQ_"))
                {
                    userID = connectionModule.receive().toString();

                    if (clientTable.containsKey(userID))
                    {
                        systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                "_RECEIVER_ONLINE_", new Timestamp(System.currentTimeMillis()));
                        connectionModule.send(systemMessage);
                        fileInfo = (FileInfo) connectionModule.receive();
                        if (fileInfo.getFileSize() > Server.getEmptySpace())
                        {
                            systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                    "_SEND_DENIED_", new Timestamp(System.currentTimeMillis()));
                            connectionModule.send(systemMessage);
                        }
                        else
                        {
                            Server.occupySpace(fileInfo.getFileID());
                            fileInfo.setFileID(Server.getFileID());
                            fileInfo.setMaxChunkSize(random.nextInt(500));

                            ArrayList<DataChunk> chunkList = new ArrayList<>();
                            fileList.add(chunkList);
                            fileInfo.setIndexOfFile(fileList.indexOf(chunkList));
                            //system.out.println(fileInfo.getSenderID());
                            systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                    "_SEND_ACCEPTED_", new Timestamp(System.currentTimeMillis()));
                            connectionModule.send(systemMessage);
                            connectionModule.send(fileInfo);
                            Thread thread = new Thread(new ServerTransmissionController(clientTable, fileList, fileInfo));
                            thread.start();

                            try {
                                thread.join();
                            } catch (InterruptedException e) {
                            }
                        }
                    }
                    else
                    {
                        systemMessage = new SystemMessage(((SystemMessage) receivedMessage).getMessageID(),
                                "_RECEIVER_OFFLINE_", new Timestamp(System.currentTimeMillis()));
                        connectionModule.send(systemMessage);
                    }
                }

                else if (((SystemMessage) receivedMessage).getMessage().equals("_REQUEST_ACCEPTED_"))
                {
                    if(sendFile(receivedFileInfo))
                    {
                        System.out.println("File sent Successfully");
                    }
                    else
                        System.out.println("File Transmission Failed");

                    Server.freeSpace(receivedFileInfo.getFileSize());
                }
            }
        }
    }
}
