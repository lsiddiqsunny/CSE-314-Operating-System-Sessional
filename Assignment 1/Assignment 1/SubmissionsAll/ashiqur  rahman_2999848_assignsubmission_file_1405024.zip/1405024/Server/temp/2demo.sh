#!/bin/bash
echo $(ls -s)
d=man
echo $d
for  variable in $d
do
echo $variable
done
