# print("Allah is the most gracious and the Most Ma
