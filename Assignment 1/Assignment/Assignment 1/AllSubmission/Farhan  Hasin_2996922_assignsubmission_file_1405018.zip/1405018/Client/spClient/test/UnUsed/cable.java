public class cable {
    public static void main() {
        System.out.println( "Hello World!" );
    }
}
