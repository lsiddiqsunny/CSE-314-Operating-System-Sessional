package tcpclient;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class TCPClientForm2 {
    public JButton browseFileButton;
    public JTextField textField1;
    public JTextField textField2;
    public JButton exitButton;
    public JButton sendFileButton;
    public JTabbedPane tabbedpane;
    public JPanel SEND;
    public JList list1;
    public JTable table1;
    public JScrollPane jScrollPane;
    public JScrollPane jScrollPaneList;


}
