package tcpclient;

import javax.swing.*;

public class TCPClientForm extends TCPClientForm2{

    public JPanel panel1;
    public JTextField textField1;
    public JButton submitButton;
    public JButton exitButton;


}

