package tcpclient;

import javax.swing.*;

public class TCPClientForm3 {
    public JTabbedPane tab;
    public JPanel send;
}
