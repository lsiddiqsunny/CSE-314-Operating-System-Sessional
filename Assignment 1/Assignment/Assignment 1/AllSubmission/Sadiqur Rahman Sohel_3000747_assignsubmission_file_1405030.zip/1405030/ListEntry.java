package Model;


public class ListEntry
{
   private String value;

  
   public ListEntry(String value) {
      this.value = value;
   }
  
   public String getValue() {
      return value;
   }

}