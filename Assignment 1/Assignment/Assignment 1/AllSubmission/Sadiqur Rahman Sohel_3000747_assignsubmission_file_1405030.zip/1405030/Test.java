package Model;

public class Test {


    public static void main(String args[]) {
        byte []b=new byte[21];
        b[0]=(byte) 255;
        b[1]=(byte) 255;
        b[2]=(byte) 255;
        b[3]=(byte) 255;
        b[4]=(byte) 255;
        b[5]=(byte) 255;
        b[6]=(byte) 255;
        b[7]=(byte) 255;
        b[8]=(byte) 255;
        b[9]=(byte) 0;
        b[10]=(byte) 23;
        b[11]=(byte) 255;
        b[12]=(byte) 255;
        b[13]=(byte) 255;
        b[14]=(byte) 255;
        b[15]=(byte) 255;
        b[16]=(byte) 255;
        b[17]=(byte) 255;
        b[18]=(byte) 255;
        b[19]=(byte) 255;
        b[20]=(byte) 255;



       /* Frame f=new Frame(b,(byte) 126);
        f.printBit(b,cgui.);
        f.printBitFromArray(f.getStuffedBit());

        Frame f1=new Frame(f.getStuffedBit());

        System.out.println(f1.getStatus());
        System.out.println(f1.getSeqNum());
        System.out.println(f1.getCheckSum());
        f1.printBit(f1.getDeStuffedBit());*/



    }

}
