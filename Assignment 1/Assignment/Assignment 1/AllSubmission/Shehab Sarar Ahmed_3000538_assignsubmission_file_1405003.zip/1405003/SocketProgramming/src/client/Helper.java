package client;

/**
 * Created by user on 10/18/2017.
 */
public class Helper {
    public boolean helper = false;
}
