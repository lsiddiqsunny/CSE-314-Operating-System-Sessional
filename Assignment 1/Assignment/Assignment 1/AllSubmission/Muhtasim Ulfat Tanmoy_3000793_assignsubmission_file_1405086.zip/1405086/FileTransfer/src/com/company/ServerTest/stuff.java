//package com.company.ServerTest;
//
///**
// * Created by t on 10/31/17.
// */
//public class stuff {
//
//    String stuffedPayload = new String();
//    stuffedPayload = "";
//    int countOne = 0;
//    int fixer = 0;
//
//        for (int i = 0; i < payload.length(); i++) {
//        if (payload.charAt(i) == '0') {
//            countOne = 0;
//            fixer = 0;
//            stuffedPayload += 0;
//        } else {
//            countOne++;
//            if (countOne == (6 + fixer)) {
//                fixer = -1;
//                countOne = 0;
//                stuffedPayload += "01";
//                extraLength++;
//
//            } else {
//                stuffedPayload += "1";
//            }
//
//        }
//    }
//
//}
