package Server;

import Utilities.Frame;
import Utilities.NetworkUtility;
import org.omg.CORBA.FREE_MEM;

import java.io.*;
import java.util.Random;

public class ServerThread implements Runnable{
    NetworkUtility networkUtility;
    private String StudentID, RecipientID, filePath, fileName;
    private int fileSize, chunkSize, currentFileSize, chunkError = 0;
    int i = 0;

    public ServerThread(NetworkUtility networkUtility){
        this.networkUtility = networkUtility;
        new Thread(this).start();
    }
    @Override
    public void run() {
        networkUtility.write("Please enter your student ID: ");
        while (true){
            String s = (String) networkUtility.read();
            if(s.equals("Close")){

                if(i > 0){
                    NetworkUtility networkUtility1 = Server.hashtable.remove(StudentID);
                    if(Server.hashtable2.containsKey(StudentID)){
                        NetworkUtility networkUtility2 = Server.hashtable2.remove(StudentID);
                        networkUtility2.closeConnection();
                    }
                    networkUtility1.closeConnection();
                    System.out.println("Student ID " + StudentID + " has logged out");
                    //networkUtility.write("You are logged out. New login ID: ");
                    i = 0;
                }
                //networkUtility.closeConnection();
               //break;
                continue;
            }
            if(i == 0){
                 if(s.startsWith("1405")) {
                    if(Server.hashtable.containsKey(s)){
                        if(!Server.hashtable.get(s).getInetAddress().toString().equals(networkUtility.getInetAddress().toString())) {
                            networkUtility.write("You have already logged in.\n");
                            Server.hashtable.get(s).print();
                            networkUtility.print();
                            continue;
                        }
                        else{
                            StudentID = s;
                            System.out.println("Student ID: " + s + " has logged in again.");
                            networkUtility.write("You have successfully logged in again\nEnter your recipient ID");
                            i++;
                        }
                    }
                    else {
                        StudentID = s;
                        Server.hashtable.put(s, networkUtility);
                        System.out.println("Student ID: " + s + " has logged in");
                        networkUtility.write("You have successfully logged in\nEnter your recipient ID");
                        i++;
                    }
                }
                else{
                    networkUtility.write("ID invalid, bro. Enter a valid ID: ");
                }
            }
            else if (i == 1) {
                if (s.startsWith("1405")) {
                    if (Server.hashtable.containsKey(s)) {
                        RecipientID = s;
                        i++;
                        networkUtility.write("Enter your filepath: ");
                    } else {
                        networkUtility.write("Recipient is offline. Enter another student iD:");
                    }
                }
                else {
                    networkUtility.write("ID invalid. Enter a valid ID: ");
                }
            }
            else if (i == 2){
                filePath = s;
                int n = filePath.lastIndexOf(File.separator);
                fileName = filePath.substring(n + 1);
                System.out.println("File name is: " + fileName);
                networkUtility.write("Enter filesize (In Bytes): ");
                i++;
            }
            else if (i == 3){
                fileSize = Integer.parseInt((String) s);
                if(fileSize > Server.bufferSize){
                    networkUtility.write("File too large!!!\nEnter another file name: ");
                    i = 2;

                }
                else{
                    System.out.println("File size is: " + fileSize + " bytes.");
                    Server.bufferSize -= fileSize;
                    currentFileSize = 0;
                    Random random = new Random(System.currentTimeMillis());
                    chunkSize = (40 + random.nextInt(11)) * 1024;
                    networkUtility.write("Start sending file. FileID is " + Server.i + ". Chunk size(Bytes) is " + chunkSize);

                    int flag = 0;
                    int k = (int) Math.floor(fileSize / chunkSize);
                    System.out.println("###" + fileSize + "###" + chunkSize + "###" + k);
                    byte arr[][] = new byte[k + 1][];


                    int waiting = 0;

                    while (waiting != arr.length) {
                        Object object = networkUtility.read();
                        if(object.getClass() == byte[].class) {
                            byte[] bytes = (byte[]) object;
                            bytes = Frame.unwrapHT(bytes);
                            bytes = Frame.bitDestuff(bytes);
                            if (!Frame.checkError(bytes)) {
                                int n = (int) bytes[1];
                                bytes = Frame.extractpayload(bytes);
                                if (n == waiting) {
                                    arr[waiting] = bytes;
                                    Frame frame = new Frame(2, waiting, 1, new byte[0]);
                                    try {
                                        Thread.sleep(1000 * random.nextInt(7));
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }

                                    /*
                                    int r = random.nextInt(frame.wrappedframe.length);
                                    int r1 = random.nextInt(8);
                                    if(r > 90) {
                                        Frame.writeBit(frame.wrappedframe[r], r1);
                                    }*/





                                    networkUtility.write(frame.wrappedframe);
                                    System.out.println("Frame " + waiting + " received. Acknowledgement sent.");
                                    waiting++;
                                } else {
                                    System.out.println("Wanted frame: " + waiting + ". Got frame: " + n + ". Discarding frame.");
                                }
                            }
                            else {
                                System.out.println("Error in byte array. Discarding frame.");
                            }
                            //}
                        }
                    }






                    /*for (int j = 0; j < k; j++) {

                        Object object = networkUtility.read();
                        if(object.getClass() == String.class && object.toString().startsWith("Error: Timeout")){
                            System.out.println("Server has timed out. End transmission.");
                            for (int l = 0; l < j; l++) {
                                arr[l] = null;
                            }
                            arr = null;
                            flag = 1;
                            break;
                        }
                        else{
                            arr[j] = (byte[]) object;
                        }



                        try {
                            long ll = 1000 * random.nextInt(3);
                            System.out.println("Sleeping for " + (ll/1000) + " seconds.");
                            Thread.sleep(ll);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }



                        networkUtility.write("Chunk #" + (j + 1) + " received.");
                        System.out.println("Chunk #" + (j + 1) + " received.");
                        currentFileSize += chunkSize;
                    }
                    if(flag == 1){
                        Server.bufferSize += fileSize;
                        networkUtility.write("File transmission terminated. Start another transmission? Enter new recipient ID: ");
                        i = 1;
                        continue;
                    }


                    byte[] b;

                    Object object = networkUtility.read();

                    if(object.getClass() == String.class && object.toString().startsWith("Error: Timeout")){
                        System.out.println("Server has timed out. End transmission.");
                        for (int j = 0; j < k; j++) {
                            arr[j] = null;
                        }
                        arr = null;
                        flag = 1;
                        networkUtility.write("File transmission terminated. Start another transmission? [Press Yes]");
                        Server.bufferSize += fileSize;
                        i = 1;
                        continue;
                    }
                    else{
                        b = (byte[]) object;
                        currentFileSize += b.length;
                        System.out.println(currentFileSize + "###" + fileSize);
                    }
                    networkUtility.write("Final chunk received.");
                    System.out.println("Final chunk received.");
                    String s1 = (String) networkUtility.read();
                    if(s1.startsWith("Start adding chunks")){
                        System.out.println("Started adding chucks");
                        if(fileSize == currentFileSize){
                            networkUtility.write("Chunks add perfectly.");
                            System.out.println("Chunks add perfectly.");
                        }
                        else{
                            networkUtility.write("Chunks don't add up.");
                            System.out.println("Chucks don't add up. Deleting chucks from buffer.");
                            for (int j = 0; j < k; j++) {
                                arr[j] = null;
                            }
                            arr = null;
                            chunkError = 1;
                        }
                    }*/














                    if(chunkError == 0) {
                        /*byte[][] arr2 = new byte[arr.length + 1][];
                        for (int j = 0; j < arr.length; j++) {
                            arr2[j] = arr[j];
                        }*/
                        //arr2[arr.length] = b;

                        Integer integer = new Integer(Server.i);
                        Server.i++;

                        Server.hashtable3.put(integer, arr);

                        new ServerRecipientThread(Server.hashtable2.get(RecipientID), integer, StudentID);

                        try {
                            OutputStream outputStream = new FileOutputStream(fileName);
                            for (int j = 0; j < arr.length; j++) {
                                outputStream.write(arr[j]);
                            }
                            outputStream.close();

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("Session ended.");
                    return;
                    //networkUtility.write("Enter new recipient ID: ");
                }
            }
        }
    }
}
