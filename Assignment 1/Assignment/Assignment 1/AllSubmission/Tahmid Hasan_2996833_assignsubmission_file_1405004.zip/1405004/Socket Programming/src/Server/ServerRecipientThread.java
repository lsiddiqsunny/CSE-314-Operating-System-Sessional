package Server;

import Utilities.NetworkUtility;

public class ServerRecipientThread implements Runnable{

    NetworkUtility networkUtility;
    int fileID, fileSize = 0;
    String sender;
    byte[][] arr;

    public ServerRecipientThread(NetworkUtility networkUtility, int fileID, String sender){
        this.networkUtility = networkUtility;
        this.fileID = fileID;
        this.sender = sender;
        new Thread(this).start();
    }

    @Override
    public void run() {
        networkUtility.write("Student ID: " + sender + " wants to send you a file. [Y/N]?");
        while (true){
            String s = (String) networkUtility.read();
            if(s.startsWith("Y")){
                networkUtility.write("Enter filepath where you want to receive:\n");
                byte[][] arr = Server.hashtable3.remove(new Integer(fileID));
                String s1 = (String) networkUtility.read();
                networkUtility.write("Number of chunks: " + arr.length);
                for (int i = 0; i < arr.length; i++) {
                    fileSize += arr[i].length;
                    networkUtility.write(arr[i]);
                    arr[i] = null;
                }
                arr = null;
                Server.bufferSize += fileSize;
                networkUtility.write("You have received your file.");
            }
            else if (s.startsWith("N")){
                byte[][] arr = Server.hashtable3.remove(new Integer(fileID));
                for (int i = 0; i < arr.length; i++) {
                    fileSize += arr[i].length;
                    arr[i] = null;
                }
                arr = null;
                Server.bufferSize += fileSize;
                networkUtility.write("Request denied.");
            }
        }
    }
}
