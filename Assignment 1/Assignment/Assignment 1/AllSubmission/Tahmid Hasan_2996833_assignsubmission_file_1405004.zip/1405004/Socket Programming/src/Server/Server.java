package Server;

import Threads.ReadThread;
import Threads.WriteThread;
import Utilities.NetworkUtility;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Hashtable;

public class Server {
    private ServerSocket serverSocket;
    static Hashtable<String, NetworkUtility> hashtable;
    static Hashtable<String, NetworkUtility> hashtable2;
    static Hashtable<Integer, byte[][]> hashtable3;
    public static int i = 0;
    static int bufferSize = 100 * 1024 * 1024;
    public static int fileID = 0;
    public Server(){
        hashtable = new Hashtable<>();
        hashtable2 = new Hashtable<>();
        hashtable3 = new Hashtable<Integer, byte[][]>();
        try {
            this.serverSocket = new ServerSocket(33333);
            new ReceiverServer();
            while(true){
                Socket socket = serverSocket.accept();
                SocketAddress socketAddress = socket.getRemoteSocketAddress();
                NetworkUtility networkUtility = new NetworkUtility(socket);
                new ServerThread(networkUtility);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class ReceiverServer implements Runnable{

        ServerSocket serverSocket;

        public ReceiverServer(){
            new Thread(this).start();
        }

        @Override
        public void run() {
            try {
                this.serverSocket = new ServerSocket(44444);
                while (true){
                    Socket socket = serverSocket.accept();
                    NetworkUtility networkUtility = new NetworkUtility(socket);
                    String s = (String) networkUtility.read();
                    if(!hashtable2.containsKey(s)) {
                        hashtable2.put(s, networkUtility);
                    }
                   //new ServerRecipientThread(networkUtility);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new Server();
    }
}
