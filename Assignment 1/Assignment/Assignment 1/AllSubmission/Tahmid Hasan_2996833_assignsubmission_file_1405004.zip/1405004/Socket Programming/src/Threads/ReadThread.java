package Threads;

import Utilities.NetworkUtility;

public class ReadThread implements Runnable{
    private NetworkUtility networkUtility;

    public ReadThread(NetworkUtility networkUtility){
        this.networkUtility = networkUtility;
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                String s = (String) networkUtility.read();
                System.out.println(s);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        networkUtility.closeConnection();
    }
}
