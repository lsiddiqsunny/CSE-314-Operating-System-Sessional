package Utilities;

import java.io.*;

public class Frame {
    int kind, seqno, transno;
    public byte[] payload, frame, stuffedframe, wrappedframe, unwrappedframe, destuffedframe, receivedchunk;


    public Frame(int kind, int seqno, int transno, byte[] payload){
        this.kind = kind;
        this.seqno = seqno;
        this.transno = transno;
        this.payload = payload;
        this.frame = new byte[payload.length + 4];
        frame[0] = (byte) kind;
        frame[1] = (byte) seqno;
        frame[2] = (byte) transno;
        for (int i = 0; i < payload.length; i++) {
            frame[i + 3] = payload[i];
        }
        byte checksum = getChecksum(frame);
        frame[frame.length - 1] = checksum;
        stuffedframe = stuffBits(frame);
        wrappedframe = wrapHT(stuffedframe);
        unwrappedframe = unwrapHT(wrappedframe);
        destuffedframe = bitDestuff(unwrappedframe);
        if(!checkError(destuffedframe)) {
            receivedchunk = new byte[destuffedframe.length - 4];
            for (int i = 0; i < receivedchunk.length; i++) {
                receivedchunk[i] = destuffedframe[i + 3];
            }
        }
    }

    public static boolean getBit(byte b, int i){
        if(((1<<i) & b) == 0){
            return false;
        }
        return true;
    }

    public static void printBits(byte[] bytes){
        for(byte b: bytes){
            for(int i = 7; i > -1; i--){
                if(getBit(b, i)){
                    System.out.print(1);
                }
                else{
                    System.out.print(0);
                }
            }
            System.out.print(" ");
        }
        System.out.println();
    }

    public static int count11111(byte[] bytes){
        int count = 0, tempcount = 0;
        for(byte b : bytes){
            for (int i = 7; i > -1; i--) {
                if(getBit(b, i)){
                    tempcount++;
                    if(tempcount == 5){
                        count++;
                        tempcount = 0;
                    }
                }
                else{
                    tempcount = 0;
                }
            }
        }
        return count;
    }

    public static byte writeBit(byte b, int i){
        return (byte) (b | (1 << i));
    }

    public static byte[] stuffBits(byte[] srcBytes){
        int count = 0;
        byte[] destBytes = new byte[srcBytes.length + (count11111(srcBytes) + 7) / 8];
        for (int i = 0, j = 0; i < srcBytes.length * 8; i++, j++) {
            int srcidx = i / 8, srcpos = 7 - i % 8, destidx = j / 8, destpos = 7 - j % 8;
            if(getBit(srcBytes[srcidx], srcpos)){
                destBytes[destidx] = writeBit(destBytes[destidx], destpos);
                count++;
            }
            else {
                count = 0;
            }
            if(count == 5){
                j++;
                count = 0;
            }
        }
        return destBytes;

    }

    public static byte[] bitDestuff(byte[] srcBytes) {
        int count = 0;
        byte[] destBytes = new byte[(8 * srcBytes.length - count11111(srcBytes)) / 8];
        for (int i = 0, j = 0; j < destBytes.length * 8; i++, j++) {
            int srcidx = i / 8, srcpos = 7 - i % 8, destidx = j / 8, destpos = 7 - j % 8;
            if (getBit(srcBytes[srcidx], srcpos)) {
                destBytes[destidx] = writeBit(destBytes[destidx], destpos);
                count++;
            } else {
                count = 0;
            }
            if (count == 5) {
                i++;
                count = 0;
            }
        }
        return destBytes;
    }

    public static byte[] wrapHT(byte[] srcBytes) {
        byte[] destBytes = new byte[srcBytes.length + 2];
        destBytes[0] = 126;
        for (int i = 0; i < srcBytes.length; i++) {
            destBytes[i + 1] = srcBytes[i];
        }
        int badbits = 8 - count11111(srcBytes) % 8;
        if (badbits == 8) { badbits = 0; }
        destBytes[destBytes.length - 2] = (byte) (destBytes[destBytes.length - 2] | destBytes[0] >> (8 - badbits));
        destBytes[destBytes.length - 1] = (byte) (destBytes[0] << badbits);

        return destBytes;
    }

    public static byte[] unwrapHT(byte[] srcBytes) {
        byte[] destBytes = new byte[srcBytes.length - 2];
        int badbits = 8 - (count11111(srcBytes) - 2) % 8;
        if (badbits == 8) { badbits  = 0; }
        for (int i = 0; i < srcBytes.length - 2; i++) {
            destBytes[i] = srcBytes[i + 1];
        }
        destBytes[destBytes.length - 1] = (byte) (srcBytes[srcBytes.length - 2] & (-1 << badbits));
        return destBytes;
    }

    public static byte getChecksum(byte[] bytes) {
        byte b = bytes[0];
        for (int i = 1; i < bytes.length; i++) {
            b = (byte) (b ^ bytes[i]);
        }
        return b;
    }

    public static byte[] addmetadata(int kind, int seqno, int transno, byte[] bytes) {
        byte[] newbytes = new byte[bytes.length + 4];
        for (int i = 0; i < bytes.length; i++) {
            newbytes[i + 3] = bytes[i];
        }
        newbytes[0] = (byte) kind;
        newbytes[1] = (byte) seqno;
        newbytes[2] = (byte) transno;
        newbytes[newbytes.length - 1] = getChecksum(newbytes);
        return newbytes;
    }

    public static byte[] extractpayload(byte[] bytes) {
        byte[] newbytes = new byte[bytes.length - 4];
        for (int j = 0; j < newbytes.length; j++) {
            newbytes[j] = bytes[j + 3];
        }
        return newbytes;
    }

    public static boolean checkError(byte[] bytes) {
        byte b = bytes[0];
        for (int i = 1; i < bytes.length; i++) {
            b = (byte) (b ^ bytes[i]);
        }
        if(b == 0) { return false; }
        return true;
    }

    public static void main(String[] args) {
        InputStream inputStream = null;
        int currentFileSize = 886261;
        try {
            inputStream = new FileInputStream("/home/tahmid/Downloads/Adib.jpg");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int k = (int) Math.floor(886261 / 5120);
        byte arr[][] = new byte[k][5120];
        //byte ara[][] = new byte[k + 1][];
        for (int j = 0; j < k; j++) {
            try {
                byte[] temp = new byte[5120];
                inputStream.read(temp);
                Frame f = new Frame(j, j, j, temp);
                arr[j] = f.receivedchunk;
            } catch (IOException e) {
                e.printStackTrace();
            }
            currentFileSize -= 5120;
        }
        byte b[] = new byte[currentFileSize];
        int m = 0;
        try {
            m = inputStream.read(b);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("array size " + m);
        byte b2[], b3[];
        if(m < 1){
            b2 = new byte[0];
            //b3 = new byte[0];
        }
        else {
            b2 = new byte[m];
        }
        for (int j = 0; j < m; j++) {
            b2[j] = b[j];
            Frame f = new Frame(1,1,1, b2);
            b2 = f.receivedchunk;
        }
        //System.out.println(new String(b, 0, m));
        try {
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //byte[] b = { 1, 2, 3, 4, 5};

        //Frame frame = new Frame(1, 2,3, b);
        //printBits(frame.payload);
        //printBits(frame.frame);
        //printBits(frame.stuffedframe);
        //printBits(frame.wrappedframe);
        //printBits(frame.unwrappedframe);
        //printBits(frame.destuffedframe);
        //printBits(frame.receivedchunk);

        try {
            OutputStream outputStream = new FileOutputStream("dll.jpg");
            for (int j = 0; j < arr.length; j++) {
                outputStream.write(arr[j]);
            }
            outputStream.write(b2);
            outputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String s = "heloo";
        System.out.println(s);

    }
}
