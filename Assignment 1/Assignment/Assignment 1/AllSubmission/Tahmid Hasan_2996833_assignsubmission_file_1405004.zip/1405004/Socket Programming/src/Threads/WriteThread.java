package Threads;

import Utilities.NetworkUtility;

import java.util.Scanner;

public class WriteThread implements Runnable{
    private NetworkUtility networkUtility;

    public WriteThread(NetworkUtility networkUtility){
        this.networkUtility = networkUtility;
        new Thread(this).start();
    }

    @Override
    public void run() {
        try{
            Scanner scanner = new Scanner(System.in);
            String s = scanner.nextLine();
            networkUtility.write(s);

        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
