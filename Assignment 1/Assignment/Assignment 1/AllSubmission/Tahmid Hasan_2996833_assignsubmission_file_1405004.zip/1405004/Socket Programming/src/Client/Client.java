package Client;

import Threads.ReadThread;
import Threads.WriteThread;
import Utilities.NetworkUtility;

public class Client {
    public static void main(String[] args) {
        try{
            String s = "127.0.0.1";
            int port1 = 33333, port2 = 44444;
            NetworkUtility networkUtility = new NetworkUtility(s, port1);
            //System.out.print("Please enter your student ID: ");
            new ClientThread(networkUtility);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
