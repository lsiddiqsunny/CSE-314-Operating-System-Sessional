package Client;

import Utilities.NetworkUtility;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

public class ClientRecipientThread implements Runnable {
    NetworkUtility networkUtility;
    private int i = 0, chunkNo;
    String filePath;

    public ClientRecipientThread(NetworkUtility networkUtility){
        this.networkUtility = networkUtility;
        new Thread(this).start();
    }

    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);
        while (true){
            if(ClientThread.flag == 1){
                networkUtility.closeConnection();
                networkUtility = null;
                break;
            }
            if(i == 0 && ClientThread.flag == 0 && networkUtility!= null) {
                String s = (String) networkUtility.read();
                System.out.println(s);
                s = scanner.nextLine();
                networkUtility.write(s);
                if(s.startsWith("Y")){
                    s = (String) networkUtility.read();
                    System.out.println(s);
                    s = scanner.nextLine();
                    networkUtility.write(s);
                    filePath = s;
                    s = (String) networkUtility.read();
                    if(s.startsWith("Number of chunks")){
                        int j = s.lastIndexOf(" ");
                        String s1 = s.substring(j + 1);
                        chunkNo = Integer.parseInt(s1);
                        byte[][] arr = new byte[chunkNo][];
                        for (int k = 0; k < chunkNo; k++) {
                            arr[k] = (byte[]) networkUtility.read();
                        }
                        try {
                            OutputStream outputStream = new FileOutputStream(filePath);
                            for (int k = 0; k < chunkNo; k++) {
                                outputStream.write(arr[k]);
                            }
                            outputStream.close();

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        System.out.println(networkUtility.read());
                    }

                } else if (s.startsWith("N")){
                    System.out.println(networkUtility.read());
                } else{
                    System.out.println("Race condition in console.");
                }
            }
        }
    }
}
