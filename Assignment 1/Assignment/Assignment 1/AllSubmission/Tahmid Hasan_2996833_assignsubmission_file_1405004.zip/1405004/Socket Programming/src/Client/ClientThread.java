package Client;

import Utilities.Frame;
import Utilities.NetworkUtility;
import org.omg.CORBA.FREE_MEM;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class ClientThread implements Runnable {
    NetworkUtility networkUtility;
    private int i = 0;
    private int chunkSize, fileSize, currentFileSize;
    private String filePath, studentID;
    static int flag = 0;

    public ClientThread(NetworkUtility networkUtility){
        this.networkUtility = networkUtility;
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            Scanner scanner = new Scanner(System.in);
            while (true) {
                if(i == 0) {
                    String s;
                    s = (String) networkUtility.read();
                    System.out.println(s);
                    if(s.startsWith("Start sending file")){
                        int j = s.lastIndexOf(" ");
                        chunkSize = Integer.parseInt(s.substring(j+1));
                        i++;
                        //System.out.println("hfhd " + size + " etw");
                        continue;
                    }
                    if(s.startsWith("You have successfully logged in")){
                        if(!s.startsWith("You have successfully logged in again")) {
                            NetworkUtility networkUtility = new NetworkUtility("127.0.0.1", 44444);
                            networkUtility.write(studentID);
                            //new ClientRecipientThread(networkUtility);
                        }
                    }
                    String s1 = scanner.nextLine();
                    if(s.startsWith("Enter your filepath")){
                        filePath = s1;
                    }
                    if (s.startsWith("Enter filesize")){
                        fileSize = Integer.parseInt(s1);
                        currentFileSize = fileSize;
                    }
                    if(s.startsWith("Please enter your student ID") || s.startsWith("Invalid ID")){
                        studentID = s1;
                    }
                    if(s1.equals("Close")){
                        networkUtility.write(s1);
                        networkUtility.closeConnection();
                        flag = 1;
                        System.out.println("You have logged out.");
                        break;
                    }
                    networkUtility.write(s1);

                }
                else if(i == 1){
                    //System.out.println("Have ");
                    InputStream inputStream = new FileInputStream(filePath);
                    int k = (int) Math.floor(fileSize / chunkSize);
                    byte arr[][] = new byte[k + 1][];
                    for (int j = 0; j < k; j++) {
                        arr[j] = new byte[chunkSize];
                        inputStream.read(arr[j]);
                        currentFileSize -= chunkSize;
                    }
                    System.out.println("Current filesize " + currentFileSize);
                    byte b[] = new byte[currentFileSize];
                    int m = inputStream.read(b);
                    //System.out.println("array size " + m);
                    byte b2[];
                    if(m < 1){ b2 = new byte[0]; }
                    else { b2 = new byte[m]; }
                    for (int j = 0; j < m; j++) { b2[j] = b[j]; }
                    arr[k] = b2;
                    inputStream.close();

                    System.out.println("Number of chunks: " + arr.length);

                    int l = 8, kind = 1, seqno = 0, transno = 1, waiting = 0;
                    //int count = 0;
                    while (true) {
                        if (waiting == arr.length) {
                            System.out.println("File sent");
                            break;
                        }
                        for (int j = 0; j < l && seqno < arr.length; j++) {
                            byte[] bytes = arr[seqno];
                            bytes = Frame.addmetadata(kind, seqno, transno, bytes);
                            bytes = Frame.stuffBits(bytes);
                            bytes = Frame.wrapHT(bytes);
                            Random random = new Random(System.currentTimeMillis());
                            int n = random.nextInt(100);
                            if (n < 90) {
                                networkUtility.write(bytes);
                                System.out.println("Frame: " + seqno + " sent. Transmission number: " + transno);
                            }
                            else {
                                System.out.println("Frame: " + seqno + " lost during transmission.");
                            }
                            Thread.sleep(500);
                            seqno++;
                        }

                        while (true) {
                            if (waiting >= arr.length) {
                                break;
                            }
                            Object object = networkUtility.read();
                            if(object.getClass() == byte[].class) {
                                byte[] bytes = (byte[]) object;
                                bytes = Frame.unwrapHT(bytes);
                                bytes = Frame.bitDestuff(bytes);
                                if (!Frame.checkError(bytes)) {
                                    if ((int) bytes[1] != waiting) {
                                        //count = waiting;
                                        seqno = waiting;
                                        transno++;
                                        System.out.println("Acknowledgement for frame: " + waiting + " not received. Sending frame again.");
                                        Thread.sleep(1000);
                                        break;
                                    } else {
                                        l--;
                                        System.out.println("Acknowledgement for frame: " + waiting + " received.");
                                        Thread.sleep(1000);
                                        if (waiting == arr.length) { break; }
                                        waiting++;
                                        if (l == 0) {
                                            l = 8;
                                            transno = 1;
                                            break;
                                        }
                                    }
                                }
                                else {
                                    System.out.println("Error in byte array. Checksum doesn't match.");
                                    seqno = waiting;
                                    transno++;
                                    Thread.sleep(1000);
                                    break;
                                }
                            } else {
                                //count = waiting;
                                seqno = waiting;
                                transno++;
                                System.out.println("Acknowledgement for frame: " + waiting + " not received. Sending frame again.");
                                break;
                            }
                        }
                    }


                    break;
                    //i = 0;


                    /*int j;
                    for (j = 0; j < k; j++) {
                        networkUtility.write(arr[j]);
                        System.out.println("Chunk #" + (j+1) + " sent.");
                        //Thread.sleep(1000);
                        //long l = System.currentTimeMillis();
                        String string = (String) networkUtility.read();
                        if(string.equals("Chunk #" + (j + 1) + " received.")){
                            continue;
                        }
                        else if (string.equals("Timed out")){
                            networkUtility.write("Error: Timeout");
                            for (int n = 0; n <= j; n++) {
                                arr[n] = null;
                            }
                            arr = null;
                            break;
                        }
                    }
                    if(j == k) {
                        networkUtility.write(b2);
                        System.out.println("Final chunk sent.");
                        String s = (String) networkUtility.read();
                        System.out.println(s + "sfabubi");
                        if(s.startsWith("Final chunk received.")){
                            networkUtility.write("Start adding chunks.");
                        }
                        String s1 = (String) networkUtility.read();
                        System.out.println(s1);
                    }
                    //System.out.println("Hoiche :D");
                    i = 0;
                    */
                }

            }
        } catch(Exception e){
            e.printStackTrace();
        }

    }
}
