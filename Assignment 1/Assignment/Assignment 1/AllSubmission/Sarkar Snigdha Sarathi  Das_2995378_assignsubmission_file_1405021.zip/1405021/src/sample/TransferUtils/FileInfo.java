package sample.TransferUtils;

import java.io.Serializable;

public class FileInfo implements Serializable{

    int fileId;
    long fileSize;
    String filename;
    String senderId;
    String receiverId;

    public FileInfo(int fileId, long fileSize, String filename, String senderId, String receiverId) {
        this.fileId = fileId;
        this.fileSize = fileSize;
        this.filename = filename;
        this.senderId = senderId;
        this.receiverId = receiverId;
    }

    @Override
    public int hashCode() {
        return fileId;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof FileInfo)) {
            return false;
        }
        FileInfo o = (FileInfo)obj;
        return o.getFileId() == this.getFileId() ;
    }

    public FileInfo(long fileSize, String filename, String senderId, String receiverId) {
        this.fileSize = fileSize;
        this.filename = filename;
        this.senderId = senderId;
        this.receiverId = receiverId;
    }

    public int getFileId() {
        return fileId;
    }

    public long getFileSize() {
        return fileSize;
    }

    public String getFilename() {
        return filename;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setFileId(int fileId) {
        this.fileId = fileId;
    }
}
