package sample.Server;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    private TextArea log_Area_tracker;

    @FXML
    private Label ipLabel;

    @FXML
    private Button serverInit;

    @FXML
    private TextField bufferSize;

    @FXML
    private TextField ipField;

    @FXML
    private TextField portField;

    @FXML
    void serv_init_Action() {

        serverInit.setVisible(false);
        try {
            new ServerManipulator(new Integer(portField.getText()),log_Area_tracker,new Long(bufferSize.getText()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            ipField.setText(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            log_Area_tracker.setText("Could not find localhost address");
        }
    }
}