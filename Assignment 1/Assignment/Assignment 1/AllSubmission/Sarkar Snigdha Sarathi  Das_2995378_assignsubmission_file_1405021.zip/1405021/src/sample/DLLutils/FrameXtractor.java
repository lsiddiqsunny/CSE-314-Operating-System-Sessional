package sample.DLLutils;

public class FrameXtractor {
    int calculatedChecksum = 0;
    int foundChecksum =0;
    int type;
    int seqno;
    int ackno;
    FrameHandler frameHandler;

    public FrameXtractor(){
        frameHandler = new FrameHandler();
    }

    public int getSeqno(byte[] b) {
        return b[2];
    }


    public byte[] getDataFromFrame(byte[] b){
        //remove stuffing
        byte br[] = frameHandler.bitDeStuff(b);
        System.out.println("Before Destuffing: ");
        frameHandler.printBinary(b);
        System.out.println("After DeStuffing: ");
        frameHandler.printBinary(br);
        System.out.println(" ");
        type = br[1];
        if(type == 0)
            seqno = br[2];
        else
            ackno = br[3];

       // calculate the checksum here
        calculatedChecksum = calculateChecksum(br);


        foundChecksum = br[br.length-2];
        System.out.println("calculateChecksum:" + calculatedChecksum);
        if(calculatedChecksum != foundChecksum) {
            System.out.println("Checksum mismatch --  Requires retransmisssion , Size = "+b.length);
            return null;
        }
        br = frameHandler.extractData(br);
        System.out.println("Actual Data: ");
        frameHandler.printBinary(br);
        return br;


    }

    public int calculateChecksum(byte[] b){
        int endmarker=1,last,sum =0;

        for(int i=0;i<b.length;i++){
            if(b[i] == '~')
                endmarker=i;
        }

        last = endmarker -1;

        for(int i=0;i<last ;i++){
            int index = i;
            for(int j=0;j<8;j++){
                if( (b[index]>>j & 1 ) != 0 )
                    sum++;
            }
        }

        sum = sum%256;

        byte bb = (byte) sum;
        sum =bb;

        return sum;

    }


}
