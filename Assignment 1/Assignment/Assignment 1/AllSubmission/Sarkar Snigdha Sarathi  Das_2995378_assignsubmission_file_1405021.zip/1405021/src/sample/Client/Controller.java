

package sample.Client;

        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.fxml.Initializable;
        import javafx.scene.Parent;
        import javafx.scene.control.Button;
        import javafx.scene.control.Label;
        import javafx.scene.control.TextField;
        import sample.ServerUtilities.ServerUtils;

        import java.io.IOException;
        import java.net.URL;
        import java.util.ResourceBundle;

public class Controller implements Initializable {

    ServerUtils serverUtils;
    String userId;
    static boolean continuePolling;

    @FXML
    private Button pendingButton;

    @FXML
    private TextField idNonChangeable;

    @FXML
    private Button logout;

    @FXML
    private Label idLabel;

    @FXML
    private TextField alertNewRequest;

    @FXML
    private Button sendButton;

    @FXML
    void pendingButtonAction(ActionEvent event) {
        continuePolling = false;
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("pendingList.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Main.changeScene(root);

    }

    @FXML
    void sendButtonAction(ActionEvent event) {
        continuePolling = false;
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("sendfiles.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Main.changeScene(root);

    }

    @FXML
    void logoutButtonAction(ActionEvent event) {
        continuePolling = false;
        try {
            serverUtils.oos.writeObject("/cmnd_LOGOUT");
            serverUtils.s.close();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("page0.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Main.changeScene(root);

        } catch (IOException e) {
            alertNewRequest.setText("Error in connection.");
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        serverUtils = ClientSocketDriver.getInstance().getUtil();
        userId = ClientSocketDriver.getInstance().getId();
        idNonChangeable.setText(userId);
        continuePolling = true;
        alertNewRequest.setVisible(false);
        new PollInboxChange(serverUtils,userId,alertNewRequest);
    }
}
