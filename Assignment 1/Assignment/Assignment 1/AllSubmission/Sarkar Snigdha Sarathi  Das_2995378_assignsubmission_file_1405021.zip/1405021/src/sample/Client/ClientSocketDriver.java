package sample.Client;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import sample.ServerUtilities.ServerUtils;

import java.io.IOException;
import java.net.Socket;

public class ClientSocketDriver {
    private static ClientSocketDriver instance = null;
    private Socket socket;
    ServerUtils util;
    private String id;
    Controller0 c0;


    ClientSocketDriver(String targetIp,Controller0 c, int port,String userId){
        c0 = c;


        try {

            socket = new Socket(targetIp,port);
            id = userId;
            util = new ServerUtils(socket);
            util.oos.writeObject(userId);
            String response = util.ois.readObject().toString();
            // .out.println(response);
            if(response.equals("/cmnd_ALREADY_ONLINE")){
                c0.setErrorAlert("Sorry ,you are already logged in.");
                socket.close();
            }

            else{
                setContext(this);
                Parent root = FXMLLoader.load(getClass().getResource("page1.fxml"));
                Main.changeScene(root);
            }


        } catch (IOException e) {
            c0.setErrorAlert("Ip / Port Invalid. Please try again.");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }


    private static void setContext(ClientSocketDriver csd){
        instance = csd;

    }

    public static ClientSocketDriver getInstance(){
        return instance;
    }

    public ServerUtils getUtil() {
        return util;
    }

    public String getId() {
        return id;
    }
}
