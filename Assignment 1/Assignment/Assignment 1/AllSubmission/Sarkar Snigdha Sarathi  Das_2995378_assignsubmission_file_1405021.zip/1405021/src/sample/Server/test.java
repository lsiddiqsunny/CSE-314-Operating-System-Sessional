package sample.Server;

/*import sample.TransferUtils.FileReceiver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class test {
    static Socket s1=null;

    test() {
        try {
            ServerSocket socket = new ServerSocket(38888);

            {
                s1 = socket.accept();
                System.out.println("found a receiver");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        test t = new test();
        FileReceiver fileReceiver = new FileReceiver(s1,"F:\\Movies\\The.Bridge.on.the.River.Kwai.1957.720p.BluRay.x264.YIFY\\dd.mp4",8192*2);

        boolean b = fileReceiver.receive();

    }

}*/


