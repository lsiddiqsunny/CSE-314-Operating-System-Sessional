package sample.Client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller0 implements Initializable {

    @FXML
    private TextField userIdField;

    @FXML
    private Button loginButton;

    @FXML
    private TextField ipField;

    @FXML
    private TextField portField;

    @FXML
    private Label errorAlert;

    @FXML
    void loginAction(ActionEvent event) {

        new ClientSocketDriver(ipField.getText(),this,Integer.parseInt(portField.getText()),userIdField.getText());
       /* Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("page1.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Main.changeScene(root);*/
    }

    public void setErrorAlert(String s){
        errorAlert.setText(s);
        errorAlert.setVisible(true);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        errorAlert.setVisible(false);
    }
}
