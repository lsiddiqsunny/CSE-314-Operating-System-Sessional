package sample.Server;


/*
COMMAND CHAIN:
 | /cmnd_REFRESH_PENDING_LIST
 | /cmnd_VIEW_ALL_PENDING_DOWNLOADS
 | /cmnd_SEND_FILE
 |--| /cmnd_USER_OFFLINE
    | /cmnd_BUFFER_SIZE_UNAVAILABLE
    | /cmnd_CHUNK_SIZE


 */

import sample.ServerUtilities.ServerUtils;
import sample.TransferUtils.FileInfo;
import sample.TransferUtils.FileReceiver;
import sample.TransferUtils.FileSender;

import java.io.File;
import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SingleSocketDriver implements Runnable {

    ServerUtils serverUtils;
    boolean isAlive;
    String id;
    ServerManipulator sManipulator;

    SingleSocketDriver(ServerUtils s,String i,ServerManipulator ss){
        isAlive = true;
        serverUtils = s;
        id = i;
        sManipulator = ss;
        Thread t=new Thread(this);
        t.setDaemon(true);
        t.start();

    }


    @Override
    public void run() {
        String response="";
        while(isAlive == true){
            try {
                response = serverUtils.ois.readObject().toString();
            } catch (IOException e) {
                e.printStackTrace();
                sManipulator.appendInServer("Error in reading response from id "+ id );
                isAlive = false;
                break;
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                sManipulator.appendInServer("Error in reading response from id "+ id );
                isAlive = false;
                break;
            }

            if(response.equals("/cmnd_REFRESH_PENDING_LIST")){
                ArrayList list=sManipulator.getFileList(id);
                Integer integer;
                if (list== null)
                    integer = 0;
                else
                    integer= list.size();

                try {
                    serverUtils.oos.writeObject(integer);
                    serverUtils.oos.flush();
                } catch (IOException e) {
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                }
            }

            else if(response.equals("/cmnd_VIEW_ALL_PENDING_DOWNLOADS")){

                try {
                    ArrayList list=sManipulator.getFileList(id);
                    int a =0;
                    if(list!=null)
                        a=list.size();
                    else
                        a=0;



                    serverUtils.oos.writeObject(a);
                    for(int k=0;k<a;k++){
                        serverUtils.oos.writeObject(list.get(k));
                    }


                    serverUtils.oos.flush();
                } catch (IOException e) {
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                    break;
                }
            }

            else if(response.equals("/cmnd_SEND_FILE")){
                FileInfo finfo=null;
                try {
                    finfo = (FileInfo) serverUtils.ois.readObject();
                } catch (IOException e) {
                    e.printStackTrace();
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                }
                String targetId = finfo.getReceiverId();
                ServerUtils sut=sManipulator.getSocket(targetId);
                if(sut==null){
                    try {
                        serverUtils.oos.writeObject("/cmnd_USER_OFFLINE");
                        serverUtils.oos.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                        sManipulator.appendInServer("Error in writing response to id "+ id );
                        isAlive = false;
                    }
                }
                else{
                    try {
                        String filename = finfo.getFilename();
                        long siz = finfo.getFileSize();
                        boolean bool=sManipulator.increaseBufferUse(siz);
                        if(bool==false){
                            serverUtils.oos.writeObject("/cmnd_BUFFER_SIZE_UNAVAILABLE");
                            serverUtils.oos.flush();
                            //continue;
                        }
                        else{
                            Long modd = Math.min(siz,(new Integer(16384)).longValue());
                            int modder = modd.intValue()%2048+1024;
                            Random rand = new Random();
                            int chunk = (rand.nextInt((8192*4 - 8192*2) + 1) + 8192*2)%modder+2048;
                            serverUtils.oos.writeObject("/cmnd_CHUNK_SIZE");
                            serverUtils.oos.flush();
                            serverUtils.oos.writeObject(chunk);
                            serverUtils.oos.flush();
                            //
                            int fileId = sManipulator.createFileId();
                            finfo.setFileId(fileId);

                            serverUtils.oos.writeObject(fileId);

                            FileReceiver fileReceiver = new FileReceiver(serverUtils,"data\\"+fileId+".dat",chunk);
                            boolean isReceived=fileReceiver.receive();
                            if(isReceived){
                                sManipulator.addInFileList(finfo);
                                sManipulator.appendInServer("Receieved a file from "+id);
                            }
                            else {
                                sManipulator.appendInServer("Receiving failed from id" + id);
                                sManipulator.decreaseBufferUsage(finfo.getFileSize());
                                //sManipulator.deleteFromFileList(targetId,finfo);
                            }
                        }




                    } catch (IOException e) {
                        e.printStackTrace();
                        sManipulator.appendInServer("Error in reading response from id "+ id );
                        isAlive = false;
                    }

                }

            }

            else if(response.equals("/cmnd_DOWNLOAD_PARTICULAR_FILE")){
               //List list=sManipulator.getFileList(id);

                try {
                    FileInfo finf=(FileInfo)serverUtils.ois.readObject();
                    int finfFileId = finf.getFileId();
                    Long modd = Math.min(finf.getFileSize(),(new Integer(16384)).longValue());
                    int modder = modd.intValue()%4096+1024;
                    Random rand = new Random();
                    int chunk = (rand.nextInt((8192*4 - 8192*2) + 1) + 8192*2)%modder+2048;
                   // serverUtils.oos.writeObject("/cmnd_CHUNK_SIZE");
                    //serverUtils.oos.flush();
                    serverUtils.oos.writeObject(chunk);
                    serverUtils.oos.flush();

                    //int fileId=sManipulator.addInFileList(finfo);
                    FileSender fileSender = new FileSender(serverUtils,"data\\"+finf.getFileId()+".dat",chunk,false,false);
                    boolean isSent=fileSender.send();

                    if(isSent){
                        sManipulator.appendInServer("Sent a file to "+id);
                        sManipulator.deleteFromFileList(id,finf);
                        boolean b =  new File("data\\"+finf.getFileId()+".dat").delete();
                        sManipulator.appendInServer("Removed file from server with id "+finf.getFileId()+ " b");
                    }
                    else {
                        sManipulator.appendInServer("Sending failed to id" + id);

                    }


                } catch (IOException e) {
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                    isAlive= false;
                }
            }

            else if(response.equals( "/cmnd_REMOVE_PARTICULAR_FILE")){
                FileInfo finf= null;
                try {
                    finf = (FileInfo)serverUtils.ois.readObject();
                    int finfFileId = finf.getFileId();

                    sManipulator.deleteFromFileList(id,finf);
                    new File("data\\"+finf.getFileId()+".dat").delete();
                    sManipulator.appendInServer("Removed file from server with id "+finf.getFileId()+" as requested.\n");


                } catch (IOException e) {
                    e.printStackTrace();
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                    sManipulator.appendInServer("Error in reading response from id "+ id );
                    isAlive = false;
                }



            }

            else if(response.equals("/cmnd_LOGOUT")){
                sManipulator.appendInServer("\nUser " +id+" logging out.\n");
                isAlive = false;
                try {
                    serverUtils.s.close();
                } catch (IOException e) {
                    System.out.println("It already stopped");
                    e.printStackTrace();
                }
                break;
            }

        }


        sManipulator.delete_from_server(id);
    }
}
