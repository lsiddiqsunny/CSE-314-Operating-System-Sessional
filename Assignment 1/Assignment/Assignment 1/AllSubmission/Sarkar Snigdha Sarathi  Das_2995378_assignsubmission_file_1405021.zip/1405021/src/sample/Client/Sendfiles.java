package sample.Client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import sample.ServerUtilities.ServerUtils;
import sample.TransferUtils.FileInfo;
import sample.TransferUtils.FileReceiver;
import sample.TransferUtils.FileSender;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Sendfiles implements Initializable{

    private ServerUtils serverUtils;
    private String userId;

    @FXML
    private TextField filePathField;

    @FXML
    private Button browseButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField recipientField;

    @FXML
    private CheckBox frameLoss;

    @FXML
    private CheckBox checkSumError;

    @FXML
    private TextField errorAlertBox;

    @FXML
    private Button sendButton;


    @FXML
    void sendButtonAction(ActionEvent event) {
        try {

            String filePath = filePathField.getText();
            File f = new File(filePath);
            if(!f.exists()){
                errorAlertBox.setVisible(true);
                errorAlertBox.setText("File not found");
            }
            else{

                serverUtils.oos.writeObject("/cmnd_SEND_FILE");
                FileInfo fileInfo = new FileInfo(f.length(),f.getName(),userId,recipientField.getText());
                serverUtils.oos.writeObject(fileInfo);
                String response =  serverUtils.ois.readObject().toString();
                if(response.equals("/cmnd_USER_OFFLINE")){
                    errorAlertBox.setVisible(true);
                    errorAlertBox.setText("This recipient is not online right now.");
                }

                else if(response.equals("/cmnd_BUFFER_SIZE_UNAVAILABLE")){
                    errorAlertBox.setVisible(true);
                    errorAlertBox.setText("File too big to transfer.");
                }

                else if(response.equals("/cmnd_CHUNK_SIZE")){
                    errorAlertBox.setVisible(true);
                    errorAlertBox.setText("Please Wait...");
                    sendButton.setDisable(true);
                    backButton.setDisable(true);
                    browseButton.setDisable(true);
                    checkSumError.setDisable(true);
                    frameLoss.setDisable(true);



                    int chunksize = (int) serverUtils.ois.readObject();
                    int file_id = (int) serverUtils.ois.readObject();
                    FileSender fileSender = new FileSender(serverUtils,filePathField.getText(),chunksize,frameLoss.isSelected(),checkSumError.isSelected());

                    Thread t =new Thread(()-> {
                        boolean isSent = fileSender.send();
                        sendButton.setDisable(false);
                        backButton.setDisable(false);
                        browseButton.setDisable(false);
                        checkSumError.setDisable(false);
                        frameLoss.setDisable(false);


                        if (!isSent) {
                            errorAlertBox.setVisible(true);
                            errorAlertBox.setText("File could not be sent.");
                        } else {
                            errorAlertBox.setVisible(true);
                            errorAlertBox.setText("File sent successfully.");
                        }
                    });

                    t.setDaemon(true);
                    t.start();



                }


            }


        } catch (IOException e) {
            Controller.continuePolling=false;
            errorAlertBox.setVisible(true);
            errorAlertBox.setText("Error in connection");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            Controller.continuePolling=false;
        }

    }

    @FXML
    void frameLossTicked(ActionEvent event) {
        checkSumError.setSelected(false);
    }

    @FXML
    void checksumErrorTicked(ActionEvent event) {
        frameLoss.setSelected(false);
    }

    @FXML
    void backButtonAction(ActionEvent event) {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("page1.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Main.changeScene(root);
    }

    @FXML
    void browseButtonAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        File f= fileChooser.showOpenDialog(null);
        filePathField.setText(f.getAbsolutePath());
    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        serverUtils = ClientSocketDriver.getInstance().getUtil();
        userId = ClientSocketDriver.getInstance().getId();
       // System.out.println(userId);
    }
}
