public class FrameExtractor {
    public static boolean matchedChecksum=true;

    public static byte[] bitDeStaff(byte[] bufferIn,int mode,int frameAckNo){
        int start = 2,end=0;

        for (int i=1;i<bufferIn.length;i++){
            if(bufferIn[i]=='~')
                end = i;
        }

        int srcChksum = bufferIn[end-1];

        final byte[] bufferNew = new byte[end+1000];

        int i,j=0,onecounter=0;
        int checksum=0;

        for (i=0;i<(end-3)*8;i++){
            int indexprev = 2+i/8;
            int bitposprev = 7-(i%8);

            int indexnew = j/8;
            int bitposnew = 7-(j%8);

            byte mask = (byte) (1<<bitposprev);
            mask = (byte)(mask & bufferIn[indexprev]);

            if(mask == 0){
                if(onecounter == 5) {

                }

                else{
                    mask = (byte) ~(1 << bitposnew);
                    bufferNew[indexnew] = (byte) (bufferNew[indexnew] & mask);
                    j++;
                }

                onecounter = 0;

            }

            else{
                mask = (byte) (1<<bitposnew);
                bufferNew[indexnew] = (byte)(bufferNew[indexnew] | mask);
                j++;
               // System.out.println(bufferIn[indexprev]);
                checksum++;
                onecounter++;

            }

        }
        final byte[] retbuffer;
        //System.out.println(j);
        retbuffer =  new byte[j/8];

        if(srcChksum == (checksum % 256))
            matchedChecksum= true;
        else
            matchedChecksum = false;

        // System.out.println( srcChksum);
        // System.out.println(checksum);



        for(int k=0;k<retbuffer.length;k++){
            retbuffer[k] = bufferNew[k];
        }


        return retbuffer;



    }
}
