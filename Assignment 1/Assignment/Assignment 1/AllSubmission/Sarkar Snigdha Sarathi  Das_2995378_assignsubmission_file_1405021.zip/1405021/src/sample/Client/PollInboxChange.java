package sample.Client;

import javafx.scene.control.TextField;
import sample.ServerUtilities.ServerUtils;


import java.io.IOException;
import java.util.Random;

public class PollInboxChange implements Runnable {
    static int no_of_files=0;
    ServerUtils serverUtils;
    String userid;
    TextField tx;

    PollInboxChange(ServerUtils sutil, String id, TextField alert){
        tx = alert;
        serverUtils = sutil;
        userid = id;

        Thread t=new Thread(this);
        t.setDaemon(true);
        t.start();
    }

    @Override
    public void run() {

        Integer listSize=0;
        while(Controller.continuePolling){
            try {
                serverUtils.oos.writeObject("/cmnd_REFRESH_PENDING_LIST");
                listSize = (Integer) serverUtils.ois.readObject();
                if(listSize > no_of_files){
                    tx.setText(listSize-no_of_files+" new pending download requests.");
                    tx.setVisible(true);
                }

                Thread.sleep(2000);

            } catch (IOException e) {
                Controller.continuePolling=false;
                tx.setText("Cant connect to server");
                tx.setVisible(true);
                try {
                    serverUtils.s.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                Controller.continuePolling=false;
                e.printStackTrace();
            }
        }
        no_of_files = listSize;

    }
}
