package sample.DLLutils;

public class FrameBuilder {

    int type;
    int seqno;
    int ackno;
    FrameHandler frameHandler;

    public FrameBuilder(){

        frameHandler = new FrameHandler();

    }

    public byte[] createFrame(byte[] b,int type,int no,int no2){
        this.type = type;
        //if(type == 0){
            seqno = no;
            ackno = no2;
        //}
        //else{
        //    seqno = 0;
        //    ackno = no;
       // }

        System.out.print("Before Stuffing: ");
        frameHandler.printBinary(b);
        System.out.println(" ");

        b= frameHandler.bitStuff(frameHandler.makeFrame(b,type,no,no2));

        System.out.print("After Stuffing: ");
        frameHandler.printBinary(b);
        System.out.println(" ");
        return b;
    }



}
