package sample.Client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sample.ServerUtilities.ServerUtils;
import sample.TransferUtils.FileInfo;
import sample.TransferUtils.FileReceiver;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PendingListController implements Initializable {
    ServerUtils serverUtils;
    String userId;
    ArrayList<FileInfo> alist;

    @FXML
    private TextField errorField;

    @FXML
    private Button downloadButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField serialInList;

    @FXML
    private TextArea fileListShow;

    @FXML
    private Button removeButton;

    @FXML
    void downloadButtonAction(ActionEvent event) {
        downloadButton.setDisable(true);
        int serial = -1;

            try {
                serial = Integer.parseInt(serialInList.getText());
                if(serial<=-1 || serial >alist.size()){
                    System.out.println("Wrong input");
                    //if possible, an alertbox warning
                    errorField.setText("Invalid serial no.");
                    errorField.setVisible(true);
                }
                else{
                    serverUtils.oos.writeObject("/cmnd_DOWNLOAD_PARTICULAR_FILE");
                    serverUtils.oos.flush();
                    System.out.println(serial);
                    System.out.println(alist.get(serial-1));
                    serverUtils.oos.writeObject(alist.get(serial-1));
                    serverUtils.oos.flush();
                    int chunk= (int) serverUtils.ois.readObject();
                    int fileId=alist.get(serial-1).getFileId();



                    FileReceiver fileReceiver = new FileReceiver(serverUtils,"Received Files\\"+alist.get(serial-1).getFilename(),chunk);
                    errorField.setText("Please wait.");
                    errorField.setVisible(true);
                    downloadButton.setDisable(true);
                    removeButton.setDisable(true);
                    backButton.setDisable(true);
                    Thread t=
                    new Thread(()->
                    {
                        boolean isReceived = fileReceiver.receive();

                        if (isReceived == false) {
                            //show some error box

                            errorField.setText("File couldn't be downloaded properly");
                            errorField.setVisible(true);


                        } else {
                            //show true
                            errorField.setText("1 File Received successfully.");
                            errorField.setVisible(true);
                            //System.out.println("it went in");
                        }



                        downloadButton.setDisable(false);
                        removeButton.setDisable(false);
                        backButton.setDisable(false);
                        try {
                            refreshList();
                        } catch (IOException e) {
                            e.printStackTrace();
                            errorField.setText("Error in connection.");
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                            errorField.setText("Error in connection.");
                        }

                    });
                    t.setDaemon(true);
                    t.start();


                }


            }catch (NumberFormatException e){
                serial=-1;
                //if possible, an alertbox warning
                errorField.setText("Not a serial no.");
                errorField.setVisible(true);
                downloadButton.setDisable(false);

                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
                //if possible, an alertbox warning
                errorField.setText("Network error");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                errorField.setText("Error in connection.");
            }



    }

    @FXML
    void eee9e9(ActionEvent event) {

    }

    @FXML
    void removeButtonAction(ActionEvent event) {
        removeButton.setDisable(true);
        int serial = -1;
        try {
            serial = Integer.parseInt(serialInList.getText());
            if(serial<=-1 || serial >alist.size()){
                System.out.println("Wrong input");
                //if possible, an alertbox warning
                errorField.setText("Invalid Sl. no");
                errorField.setVisible(true);
                removeButton.setDisable(false);
            }

            else {

                serverUtils.oos.writeObject("/cmnd_REMOVE_PARTICULAR_FILE");
                serverUtils.oos.flush();
                serverUtils.oos.writeObject(alist.get(serial - 1));
                serverUtils.oos.flush();
                Thread.sleep(200);
                refreshList();
                removeButton.setDisable(false);
            }


            refreshList();

        } catch (IOException e) {
            errorField.setText("Connection error");
            errorField.setVisible(true);
            e.printStackTrace();
        }

        catch (NumberFormatException e){
            serial=-1;
            //if possible, an alertbox warning
            errorField.setText("Invalid Sl. no");
            errorField.setVisible(true);
            e.printStackTrace();
            removeButton.setDisable(false);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    @FXML
    void backButtonAction(ActionEvent event) {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("page1.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Main.changeScene(root);
    }

    void refreshList() throws IOException, ClassNotFoundException {
        downloadButton.setDisable(false);
        removeButton.setDisable(false);
        backButton.setDisable(false);
        fileListShow.clear();
        serverUtils.oos.writeObject("/cmnd_VIEW_ALL_PENDING_DOWNLOADS");
        serverUtils.oos.flush();
        //alist.clear();
        int track = (int) serverUtils.ois.readObject();
        PollInboxChange.no_of_files=track;
        //System.out.println("track "+ track);
        alist = new ArrayList<>();
       // System.out.println("ffffdf "+alist.size());
        //alist.addAll ((ArrayList<FileInfo>) serverUtils.ois.readObject());
        for(int k=0;k<track;k++){
            alist.add((FileInfo) serverUtils.ois.readObject());
        }

        int i=0;
       // System.out.println("filelist size a"+alist.size());
        if(alist != null) {
            for (FileInfo a : alist) {
                String text = "Sl. no: " + (i + 1) + "\nFile Name: " + a.getFilename() + "\nFile Size: " + a.getFileSize()
                        + "\nSender Id: " + a.getSenderId() + "\n\n";

                fileListShow.appendText(text);
                i++;

            }
        }

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // .println("initialized");
        serverUtils = ClientSocketDriver.getInstance().getUtil();
        userId = ClientSocketDriver.getInstance().getId();
        try {
            int raceCheck = serverUtils.ois.available();
            if(raceCheck != 0){
                raceCheck = (int) serverUtils.ois.readObject();
            }

            refreshList();


        } catch (IOException e) {
            e.printStackTrace();
            Controller.continuePolling=false;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            Controller.continuePolling=false;
        }
    }
}
