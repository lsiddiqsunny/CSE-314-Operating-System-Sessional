package sample.TransferUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

public class HashUtils {

    public static String getSHA(byte[] byteArray, int s) throws NoSuchAlgorithmException{
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
        Formatter f1 = new Formatter();
        byte[] newArray = new byte[s];
        for(int i= 0;i<s;i++)
            newArray[i] = byteArray[i];

        for (byte b : messageDigest.digest(newArray)) {
            f1.format("%02x", b);
        }
        String str = f1.toString();
        return str;
    }

}
