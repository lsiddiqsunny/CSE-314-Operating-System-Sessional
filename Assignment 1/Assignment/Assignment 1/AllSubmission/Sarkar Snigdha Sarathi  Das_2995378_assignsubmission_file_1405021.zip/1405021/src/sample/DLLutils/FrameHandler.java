package sample.DLLutils;

import java.util.Arrays;

public class FrameHandler {

    byte[] bufnew=new byte[25000];


    public static byte[]  makeFrame(byte[] buf,int kind,int seqAck,int ack){
        byte[] newbuf = null;
        newbuf=new byte[buf.length+6];
        newbuf[0]='~';
        newbuf[1] = (byte)kind;
        //if(kind==0)
            newbuf[2]= (byte)seqAck;
        //else
            newbuf[3] = (byte)ack;
        int i=0;

        for(i=0;i<buf.length;i++){
            newbuf[i+4]=buf[i];

        }

        newbuf[i+5] = '~';
        return newbuf;

    }

    public byte[] bitStuff(byte[] buf){
        int start = 1;
        int end = buf.length-2;
        Arrays.fill(bufnew,(byte) 0);
        //bufnew=new byte[buf.length+5000];
        bufnew[0]=buf[0];

        start*=8;
        end*=8;
        int i, j, indexprev, bitposprev, indexnew, bitposnew, onecounter=0, checksum=0;
        j = start;

        for(i=start;i<end;i++){
            indexprev = i/8;
            bitposprev = 7-(i%8);

            indexnew = j/8;
            bitposnew = 7-(j%8);

            byte mask = (byte) (1<<bitposprev);
            mask = (byte)(mask & buf[indexprev]);

            if(mask == 0){
                onecounter = 0;
                mask = (byte) ~(1<<bitposnew);
                bufnew[indexnew] = (byte)(bufnew[indexnew] & mask);
                j++;
            }
            else{
                mask = (byte) (1<<bitposnew);
                bufnew[indexnew] = (byte)(bufnew[indexnew] | mask);
                j++;
                checksum++;

                if(onecounter==4){
                    indexnew = j/8;
                    bitposnew = 7-(j%8);
                    mask = (byte) ~(1<<bitposnew);
                    bufnew[indexnew] = (byte)(bufnew[indexnew] & mask);
                    j++;
                    onecounter=0;

                }

                else{
                    onecounter++;

                }
            }

            if(i == ((buf.length-2)*8 -1) ){
               //System.out.println(i);
                //System.out.println(j);
                end = (buf.length -1)*8;
               // System.out.println(buf[end/8]);
                checksum+=6;
                checksum%=256;
                buf[buf.length - 2]=(byte)checksum;
               //System.out.println(buf[end/8]);
                System.out.println(checksum);
            }

        }

       // System.out.println(j);
        if(j%8==0) {
            bufnew[j / 8] = '~';
            return Arrays.copyOf(bufnew,j/8+1);

        }
        else {
            bufnew[j / 8 + 1] = '~';
            return Arrays.copyOf(bufnew,j/8+2);

        }


    }



    public byte[] bitDeStuff(byte[] buf){
        int start = 1;
        int end = buf.length-1;
        Arrays.fill(bufnew,(byte) 0);
        //bufnew=new byte[buf.length];
        bufnew[0]=buf[0];

        start*=8;
        end*=8;
        int i, j, indexprev, bitposprev, indexnew, bitposnew, onecounter=0, checksum=0;
        j = start;

        for(i=start;i<end;i++){
            indexprev = i/8;
            bitposprev = 7-(i%8);

            indexnew = j/8;
            bitposnew = 7-(j%8);

            byte mask = (byte) (1<<bitposprev);
            mask = (byte)(mask & buf[indexprev]);

            if(mask == 0){
                if(onecounter == 5) {

                }

                else{
                    mask = (byte) ~(1 << bitposnew);
                    bufnew[indexnew] = (byte) (bufnew[indexnew] & mask);
                    //System.out.println(j);
                    j++;
                }

                onecounter = 0;
            }
            else{
                mask = (byte) (1<<bitposnew);
                //System.out.println(j);
                bufnew[indexnew] = (byte)(bufnew[indexnew] | mask);
                j++;
                //System.out.println(bufnew[indexprev]);
                checksum++;
                onecounter++;
            }

        }

         //System.out.println(j);

            bufnew[j / 8] = '~';
            return Arrays.copyOf(bufnew,j/8+1);
    }



    public static byte[] extractData(byte[] buf){
            return Arrays.copyOfRange(buf,4,buf.length-2);
    }

    /*
    public static int calculateCheckSum(byte[] buf){


    }

    */

    public static void printBinary(byte[] b){
        for(int i=0;i<b.length;i++){
            String s1 = String.format("%8s", Integer.toBinaryString(b[i] & 0xFF)).replace(' ', '0');
            System.out.print(s1+" ");
        }

    }



}
