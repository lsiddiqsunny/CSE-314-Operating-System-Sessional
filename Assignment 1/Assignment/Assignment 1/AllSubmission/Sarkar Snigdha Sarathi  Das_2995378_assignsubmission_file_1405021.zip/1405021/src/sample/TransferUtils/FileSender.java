package sample.TransferUtils;

import sample.DLLutils.FrameBuilder;
import sample.DLLutils.FrameXtractor;
import sample.ServerUtilities.ServerUtils;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeoutException;

public class FileSender {
    private ServerUtils src;
    private File file;
    private int maxSize;
    BufferedInputStream bin;
    ObjectInputStream confirmation;
    OutputStream o;
    BufferedOutputStream out;
    ObjectOutputStream oos;
    InputStream in;
    int calculatedSHA,foundSHA;
    FrameBuilder frameBuilder;
    FrameXtractor frameXtractor;
    boolean frameError;
    boolean checkSumError;



    public FileSender(ServerUtils s, String filePath, int size,boolean frameErr,boolean checkSumErr){
        src = s;

        file = new File(filePath);
        frameBuilder = new FrameBuilder();
        frameXtractor = new FrameXtractor();
        frameError = frameErr;
        checkSumError = checkSumErr;
        maxSize = size;
        bin = null;
        out = null;

        try {

            src.s.setSoTimeout(30000);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        try {
            bin = new BufferedInputStream(new FileInputStream(file));
            in = src.in;


        } catch (FileNotFoundException e) {
            try {
                src.s.setSoTimeout(0);
            } catch (SocketException e1) {
                e1.printStackTrace();
            }
            System.out.println("File not found !");
        }

        try{
            o = src.out;
            out = src.bout;
            confirmation = src.ois;
            oos = src.oos;
        }catch (Exception e){
            System.out.println("stream exception");
            try {
                src.s.setSoTimeout(0);
            } catch (SocketException e1) {
                e1.printStackTrace();
            }
        }


    }

    public boolean send(){

        Random random = new Random();
        int counter=0, ackCounter=0,resend=0;
        int status=0,limit = 0;
        int randFrame=Math.abs(random.nextInt())%8;
        int randChecksum = Math.abs(random.nextInt())%8;
        //randFrame=0;
        //randChecksum=0;
        /*
        * status=0 -> read from file
        *
        * status =1 -> get acknowledgement
        *
        * status = 2 -> re transmit
        *
        * status = 3 -> no more read
        *
        * */

        byte[][] frameArray=new byte[8][];
        byte[] buffer = new byte[maxSize],tempBuf;
        int n = 0,j=0;
        byte[] x;

        try {

            while (true) {

                if (status == 0) {
                    //System.out.println(counter+" check");
                    resend= 0;
                    n = bin.read(buffer);
                    //System.out.println("n after reading from file: "+n);
                    if (n == -1) {
                       // System.out.println("special state");
                        //out.flush();
                        status = 3;
                        ackCounter=0;
                        //continue;
                    } else {
                        //buffer = frameBuilder.createFrame(Arrays.copyOfRange(buffer, 0, n), 0, counter,);

                       // System.out.println("at sender 113: "+n);
                        frameArray[counter]=null;
                        frameArray[counter] = Arrays.copyOfRange(buffer,0,n);
                        //System.out.println("and"+frameArray[counter].length);
                    }

                    j++;
                }
                //System.out.println(n);
                if (status != 1 && status != 3) {
                   // System.out.println("detail of sender: status = "+status+ "counter = "+ counter);
                    //System.out.println("framererror; "+frameError +" checksum error: "+checkSumError);
                    tempBuf=null;
                    tempBuf = frameBuilder.createFrame(frameArray[counter], 0, counter,resend);
                    if((frameError!=true) || (randFrame!=counter)) {

                        if(checkSumError==true && randChecksum==counter){
                            int tmp=tempBuf[tempBuf.length-2];
                            tmp = Math.abs((tmp+ 7)%29)%128;
                            tempBuf[tempBuf.length-2]=(byte)tmp;
                            checkSumError=false;
                        }

                        oos.writeObject("/cmnd_BUFFER_TRANSMISSION");
                        oos.flush();
                        n = tempBuf.length;
                        oos.writeObject(n);
                        oos.flush();
                        oos.writeUnshared(tempBuf);
                        oos.flush();
                    }

                    else {
                        System.out.println("randframe: "+randFrame);
                        frameError = false;
                    }

                    //System.out.println("the val of n is " + n);
                    counter++;

                    if(counter == 8){

                        if(status != 2)
                            ackCounter= 0;

                        status = 1;
                    }

                    else if(counter == limit && status == 2){
                        status = 1;

                    }
                }


                if(status == 1 || status == 3){ //acknowledgement or acknowledgement for the last chunk
                    //System.out.println("Check  "+ ackCounter);
                    if(counter == 0)
                        break;
                    //out.flush();
                    try {

                        x =  (byte[])confirmation.readUnshared();
                        foundSHA = frameXtractor.getSeqno(x);

                        if(foundSHA == ackCounter)
                            ackCounter++;

                    } catch (SocketTimeoutException e) {
                        System.out.println("No acknowledgement for frame "+ackCounter+" found ");
                        limit  = counter;
                        counter = ackCounter;
                        resend = 1;
                        status = 2;

                        continue;

                    } catch (Exception e) {
                        e.printStackTrace();
                        bin.close();
                        return false;
                    }


                    if(ackCounter==counter && status==3){
                        break;
                    }

                    if(ackCounter == counter){
                        counter = 0;
                        status = 0;
                    }
                }

            }
            //WHENEVER FINISHED SENDING WHOLE FILE, IT GIVES THE FOLLOWING COMMAND
            oos.writeObject("/cmnd_COMPLETED_TRANSMISSION");
            oos.flush();
            System.out.println("Transmission complete, Final checks ongoing...");
            long sentSize = (Long)confirmation.readUnshared();
            if(sentSize==file.length()){
                oos.writeObject("/cmnd_SUCCESS");
                oos.flush();
                bin.close();
                System.out.println("Successfully completed");
                try {
                    src.s.setSoTimeout(0);
                } catch (SocketException e1) {
                    e1.printStackTrace();
                }
                return true;
            }
            else {
                oos.writeObject("/cmnd_FAILED");
                System.out.println("size mismatch. expected: "+file.length()+" found: "+sentSize );
            }

            try {
                src.s.setSoTimeout(0);
            } catch (SocketException e1) {
                e1.printStackTrace();
            }
            oos.flush();
            bin.close();
            return false;



        }catch (IOException e) {
            System.out.println("Connection Error.");
            e.printStackTrace();
            return false;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }

    }
}
