package sample.ServerUtilities;

import java.io.*;
import java.net.Socket;

public class ServerUtils {
    public ObjectInputStream ois;
    public ObjectOutputStream oos;
    public Socket s;
    public InputStream in;
    public OutputStream out;
    public BufferedInputStream bin;
    public BufferedOutputStream bout;

    public ServerUtils(Socket ss){
        s = ss;
        try {
            out = s.getOutputStream();
            in = s.getInputStream();
            oos = new ObjectOutputStream(out);
            ois = new ObjectInputStream(in);
            bout = new BufferedOutputStream(out);
            bin = new BufferedInputStream(in);


        }catch(IOException e){
            e.printStackTrace();;
        }

    }

}
