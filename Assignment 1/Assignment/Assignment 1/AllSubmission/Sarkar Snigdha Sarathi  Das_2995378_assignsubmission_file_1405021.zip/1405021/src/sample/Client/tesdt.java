package sample.Client;

/*import sample.TransferUtils.FileSender;

import java.io.IOException;
import java.net.Socket;

public class tesdt {
    public static void main(String[] args) {
        try {
            Socket s1 = new Socket("localhost",38888);
            FileSender fs = new FileSender(s1,"F:\\Movies\\The.Bridge.on.the.River.Kwai.1957.720p.BluRay.x264.YIFY\\The.Bridge.on.the.River.Kwai.1957.720p.BluRay.x264.YIFY.mp4",8192*2);
            fs.send();
        } catch (IOException e) {
            System.out.println("not possible");
        }
    }
}*/
