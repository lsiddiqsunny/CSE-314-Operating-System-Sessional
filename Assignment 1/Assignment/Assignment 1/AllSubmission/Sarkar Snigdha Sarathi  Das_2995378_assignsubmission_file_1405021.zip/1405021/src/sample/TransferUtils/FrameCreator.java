package sample.TransferUtils;

public class FrameCreator {

    /*
    mode = 0 ---> data
    mode = 1 ---> acknowledge

     */

    public static byte[] bitStaffer(byte[] bufferIn,int mode,int frameAckNo){
        int size= bufferIn.length;
        byte a;
        final byte[] bufferNew = new byte[size+1000];
        bufferNew[0]='~';
        bufferNew[1]= new Integer(mode).byteValue();

        if(mode == 0){
            bufferNew[2]= new Integer(frameAckNo).byteValue();
            bufferNew[3]=new Integer(0).byteValue();

        }

        else{
            bufferNew[3]= new Integer(frameAckNo).byteValue();
            bufferNew[2]=new Integer(0).byteValue();

        }

        int i=0,j=0;
        int onecounter = 0,checksum=0;

        for(i=0;i<size*8;i++){
            int indexprev = i/8;
            int bitposprev = 7-(i%8);

            int indexnew = 2+j/8;
            int bitposnew = 7-(j%8);

            byte mask = (byte) (1<<bitposprev);
            mask = (byte)(mask & bufferIn[indexprev]);

            if(mask == 0){
                onecounter = 0;
                mask = (byte) ~(1<<bitposnew);
                bufferNew[indexnew] = (byte)(bufferNew[indexnew] & mask);
                j++;
            }
            else{
                mask = (byte) (1<<bitposnew);
                bufferNew[indexnew] = (byte)(bufferNew[indexnew] | mask);
                j++;
                checksum++;

                if(onecounter==4){
                    indexnew = 2+j/8;
                    bitposnew = 7-(j%8);
                    mask = (byte) ~(1<<bitposnew);
                    bufferNew[indexnew] = (byte)(bufferNew[indexnew] & mask);
                    j++;
                    onecounter=0;

                }

                else{
                    onecounter++;

                }
            }

        }

        int indexnew = 2+j/8;
        int bitposnew = 7-(j%8);
        checksum%=256;

        if(bitposnew==0){

            bufferNew[indexnew]=(byte)checksum;
            bufferNew[indexnew+1]='~';
        }

        else{
            bufferNew[indexnew+1]=(byte)checksum;
            bufferNew[indexnew+2]='~';
        }


        return bufferNew;


    }

}
