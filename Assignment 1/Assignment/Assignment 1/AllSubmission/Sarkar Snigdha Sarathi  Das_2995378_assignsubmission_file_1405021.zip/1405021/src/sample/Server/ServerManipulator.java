package sample.Server;

import javafx.scene.control.TextArea;
import sample.ServerUtilities.ServerUtils;
import sample.TransferUtils.FileInfo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

public class ServerManipulator implements Runnable {
    Hashtable<String,ServerUtils> socketHashtable;
    ServerSocket serverSocket;
    Hashtable <String,ArrayList<FileInfo>> fileList;
    //Hashtable<Integer,String> senderList;
    Hashtable<Integer,String> filenameList;
    static Integer fileId=0;
    TextArea textArea;
    Long bufferSize;
    Long usedBuffer;


    ServerManipulator(int portVal, TextArea ta, Long size) throws IOException {
        socketHashtable = new Hashtable<>();
        fileList = new Hashtable<>();
       // senderList = new Hashtable<>();
        serverSocket = new ServerSocket(portVal);
        ta.appendText("Opened server at port "+portVal+"\n");

        textArea = ta;
        bufferSize = size;
        usedBuffer = (new Integer(0)).longValue();
        Thread t=new Thread(this);
        t.setDaemon(true);
        t.start();
    }

    @Override
    public void run() {
        while(true){
            try {
                Socket socket =  serverSocket.accept();
                ServerUtils sutil = new ServerUtils(socket);
                String id =  sutil.ois.readObject().toString();
                if(socketHashtable.containsKey(id)){
                    System.out.println("Already online from other address");
                    textArea.appendText("Id "+ id +" already online, connection refused.\n" );
                    sutil.oos.writeObject("/cmnd_ALREADY_ONLINE");
                    sutil.oos.flush();
                    socket.close();
                }

                else{
                    textArea.appendText("Id "+ id +" connected ");
                    socketHashtable.put(id,sutil);
                    sutil.oos.writeObject("/cmnd_LOGIN_ACCEPTED");
                    //start a new singlesocket driver here
                    sutil.oos.flush();
                    new SingleSocketDriver(sutil,id,this);
                }

            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        }
    }

    public ArrayList getFileList(String id){
        return fileList.get(id);
    }

    public ServerUtils getSocket(String id){
        return socketHashtable.get(id);
    }

    /*public String getFileName(int fileid){
        return filenameList.get(fileid);
    }*/

   /* public String senderId(Integer id){
        return senderList.get(id);
    }*/

    public void appendInServer(String text){
        textArea.appendText(text);
        textArea.appendText("\n");

    }

    public boolean increaseBufferUse(Long value){
        if(usedBuffer+value<bufferSize){
            usedBuffer+=value;
            return true;
        }
        else return false;
    }

    public void decreaseBufferUsage(Long value){
        usedBuffer-=value;
    }

    public int addInFileList(FileInfo fileInfo ){
        //int fileid = createFileId();
       // fileInfo.setFileId(fileid);
        ArrayList<FileInfo> a = fileList.get(fileInfo.getReceiverId());
        if(a==null){
            a = new ArrayList<>();
            a.add(fileInfo);
            fileList.put(fileInfo.getReceiverId(),a);
        }

        else{
            a.add(fileInfo);
        }

        return  fileInfo.getFileId();

    }

    synchronized public void deleteFromFileList(String recipient,FileInfo fileid){
        int ind = fileList.get(recipient).indexOf(fileid);
      //  System.out.println(ind);
        Long s = fileList.get(recipient).get(ind).getFileSize();
        decreaseBufferUsage(s);
       // System.out.println("before removal from list "+fileList.get(recipient).size());
        fileList.get(recipient).remove(ind);
      //  System.out.println("after"+fileList.get(recipient).size());
       // senderList.remove(fileid);
      //  filenameList.remove(fileid);


    }

   public static int createFileId(){
        fileId++;
        return fileId;
    }

    public void delete_from_server(String id){
       socketHashtable.remove(id);

    }



}
