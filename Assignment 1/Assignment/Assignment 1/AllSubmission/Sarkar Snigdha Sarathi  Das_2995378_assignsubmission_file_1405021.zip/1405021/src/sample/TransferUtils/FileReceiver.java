package sample.TransferUtils;

import jdk.internal.util.xml.impl.Input;
import sample.DLLutils.FrameBuilder;
import sample.DLLutils.FrameXtractor;
import sample.ServerUtilities.ServerUtils;

import java.io.*;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/*
TRANSMISSION COMMANDS

/cmnd_TIMEOUT_ERROR_DETECTED
/cmnd_BUFFER_TRANSMISSION
/cmnd_CHECKSUM_ERROR_DETECTED
/cmnd_COMPLETED_TRANSMISSION
/cmnd_SUCCESS
/cmnd_FAILED

 */

public class FileReceiver {
    ServerUtils s;
    InputStream i;
    BufferedInputStream in;
    ObjectInputStream ois;
    ObjectOutputStream out;
    BufferedOutputStream writeInFile;
    String filePath;
    int size_of_Buffer;
    FrameBuilder frameBuilder;
    FrameXtractor frameXtractor;

    public FileReceiver(ServerUtils socket, String filepath, int size){
        frameBuilder = new FrameBuilder();
        frameXtractor = new FrameXtractor();
        s = socket;
        size_of_Buffer= size;


        filePath = filepath;
        try {
            writeInFile = new BufferedOutputStream(new FileOutputStream(filepath));
        } catch (FileNotFoundException e) {
            System.out.println("File Output Stream creation failed");
        }


        i = socket.in;
        in = socket.bin;
        out = socket.oos;
        ois = socket.ois;


    }

    public boolean receive() {
        byte[] buffer = new byte[size_of_Buffer+3000];
        int n = 0,j=0;
        String string = "";
        int countertrack=0;

        while (true) {
            j++;
            try {

                string = ois.readObject().toString();

            } catch (ClassNotFoundException e) {
                System.out.println("Read from network error");
                e.printStackTrace();
                try {
                    writeInFile.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                new File(filePath).delete();
                return false;
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    writeInFile.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                    return false;
                }
                new File(filePath).delete();
                return false;

            } catch (Exception e){
                try {
                    writeInFile.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                    return false;
                }
                new File(filePath).delete();
                return false;

            }

            //unnecessary

            if(string.equals("/cmnd_TIMEOUT_ERROR_DETECTED") ||string.equals("/cmnd_CHECKSUM_ERROR_DETECTED")){
                System.out.println("Error in Transmission");
                try {
                    writeInFile.close();
                    //return false;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;

                }

                /*try {
                    writeInFile.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }*/

                new File(filePath).delete();
                return false;

            }

            //unnecessary_cmplt

            else if(string.equals("/cmnd_BUFFER_TRANSMISSION")) {
                try {
                    try {

                        n = (int) ois.readObject();
                    } catch (ClassNotFoundException e) {
                        System.out.println("read object error");
                        e.printStackTrace();
                        try {
                            writeInFile.close();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }

                        new File(filePath).delete();
                        return false;
                    }


                    buffer =(byte[])ois.readUnshared();


                    byte[] buf = frameXtractor.getDataFromFrame(buffer);
                    int gotseq = frameXtractor.getSeqno(buffer);
                    System.out.println("Frame no this series: "+countertrack);
                    if(gotseq == countertrack && buf!=null){
                        n = buf.length;
                        //System.out.println("notable: "+gotseq);
                        writeInFile.write(buf, 0, n);
                        try {

                            buf = frameBuilder.createFrame("a".getBytes(), 1, countertrack, 0);
                            String strrr= new String(buf);
                            //System.out.println("track strrrr"+strrr);
                            countertrack=(countertrack+1)%8;
                            out.writeUnshared(buf);

                            out.flush();
                            out.reset();
                            buf = null;

                        } catch (Exception e) {

                            e.printStackTrace();

                            try {
                                writeInFile.close();
                            } catch (IOException e1) {
                                e1.printStackTrace();

                            }

                            new File(filePath).delete();
                            return false;
                        }
                    }
                    else{
                        System.out.println("Unexpected frame found "+gotseq+" where expected frame "+ countertrack);
                    }
                } catch (IOException e) {
                    System.out.println("Other errors in transmission");
                    //e.printStackTrace();

                    try {
                        writeInFile.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                    new File(filePath).delete();
                    return false;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }


            }

            else if(string.equals("/cmnd_COMPLETED_TRANSMISSION")){
                System.out.println("great!");
                try{writeInFile.close();
                    long siz = new File(filePath).length();
                    out.writeUnshared(siz);
                    System.out.println("size is : "+siz);
                    out.flush();}catch(IOException e){
                    System.out.println("Error in sending size");
                    e.printStackTrace();

                    try {
                        writeInFile.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }

                    new File(filePath).delete();
                    return false;
                }

            }

            else if(string.equals("/cmnd_SUCCESS")){
                System.out.println("finished downloading.");
                return true;
            }

            else
            {
                System.out.println("Size doesnt match");
                try {
                    writeInFile.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

                new File(filePath).delete();
                return false;
            }

        }


    }

}
