gcc -D_REENTRANT 1405050.c -o test -lpthread
./test
