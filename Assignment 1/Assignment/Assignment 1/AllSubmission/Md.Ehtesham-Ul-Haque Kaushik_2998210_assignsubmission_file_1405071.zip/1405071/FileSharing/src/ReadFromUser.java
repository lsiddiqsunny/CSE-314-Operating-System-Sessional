import java.io.*;
import java.util.Scanner;

class FileInfo implements Serializable
{
    String filename;
    long filesize;
    FileInfo(String filename, long filesize)
    {
        this.filename = filename;
        this.filesize = filesize;
    }
}

public class ReadFromUser implements Runnable {

	private Thread thr;
    public static String path;
    public static FileOutputStream fout;
	private ConnectionBuilder connectionBuilder;
	public File file;
    public static ReceiverFileInfo receiverFileInfo;

	public ReadFromUser(ConnectionBuilder connectionBuilder) {
		this.connectionBuilder = connectionBuilder;
		this.thr = new Thread(this);
		thr.start();
	}
	
	public void run() {
		try {
			Scanner input=new Scanner(System.in);

			while(true) {
				String s =input.nextLine();
				action(s);
			}
		} catch(Exception e) {
			System.out.println (e);
		}			
		connectionBuilder.closeConnection();
	}

	private void action(String s) {
		if(ReadFromServer.message.equals("Please Enter Your Student Id : "))
		{
			connectionBuilder.write("ownStudentId:" + s);
		}
		if(s.equals("s"))
		{
			connectionBuilder.write("request:send");
		}
        if(s.equals("c"))
        {
            System.out.println("Logging Out");
            connectionBuilder.closeConnection();
        }
		if (ReadFromServer.message.equals("Please Enter Receiver Student Id"))
		{
			connectionBuilder.write("receiver:" + s);
		}
        if (ReadFromServer.message.equals("You Can Not Send A File To You, Give Another Id"))
        {
            connectionBuilder.write("receiver:" + s);
        }

        if(ReadFromServer.message.equals("Please Enter File Path : "))
        {
            path = s;
            try {
                fout = new FileOutputStream(path);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            connectionBuilder.write("path:msg");
        }
        if (ReadFromServer.message.equals("y/n"))
        {
            if (s.equals("y"))
            {
                receiverFileInfo.name = "y";
                connectionBuilder.write(receiverFileInfo);
            }
            else if(s.equals("n"))
            {
                receiverFileInfo.name = "n";
                connectionBuilder.write(receiverFileInfo);
            }
        }
		if(ReadFromServer.message.equals("Please enter File Name : "))
		{
			try
			{
				file = new File(s);
                ReadFromServer.file = file;
				long length = file.length();
                FileInfo fileInfo = new FileInfo(s, length);
                connectionBuilder.write(fileInfo);
			}
			catch (Exception e)
			{
				System.out.println("File not found");
			}
		}
	}
}



