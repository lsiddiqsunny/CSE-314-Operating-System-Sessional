import java.io.*;

class FileChunk implements Serializable
{
    int fileId;
    int chunkSize;
    byte[] chunk;

    FileChunk()
    {

    }
    FileChunk(int fileId, int chunkSize, byte[] chunk)
    {
        this.fileId = fileId;
        this.chunkSize = chunkSize;
        this.chunk = chunk;
    }
}

public class FileTransfer implements Runnable{
    public static Thread transferThread;
    FileInputStream fin;
    int bytesToRead;
    long length;
    int noOfChunk;
    int fileId;
    static int acknowledgedCounter;
    File file;
    public static ConnectionBuilder connectionBuilder;
    public FileTransfer(File file, ConnectionBuilder connectionBuilder, int bytesToRead, int fileId){
        try {
            this.file = file;
            fin = new FileInputStream(file);
            this.connectionBuilder = connectionBuilder;
            this.bytesToRead = bytesToRead;
            this.fileId = fileId;
            this.length = file.length();
            this.noOfChunk = (int) Math.ceil((double) length/ (double) bytesToRead);
            this.transferThread = new Thread(this);
            transferThread.start();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        int totalRead;
        int i = 0, time;
        try {
            while (true){
                int j;
                if(noOfChunk-i >= 5)
                    j = 5;
                else j = noOfChunk-i;
                FileChunk [] buffer = new FileChunk[j];
                for(int k = 0; k < j; k++)
                {
                    byte[] readByte = new byte[bytesToRead];
                    totalRead = fin.read(readByte);
                    FileChunk fileChunk = new FileChunk(fileId, totalRead, readByte);
                    FileChunk fileChunk1 = new FramingManager().getFrame(fileChunk, (byte) 1,  (byte) (i+k), (byte) 1, (byte) 0,
                            (byte) 0);
                    buffer[k] = fileChunk1;
                }

                for(int k = 0; k < j; k++)
                {
                    /*if(k == 2)
                    {
                        continue;
                    }
                    if (k == 3)
                    {
                        FramingManager framingManager = new FramingManager();
                        FileChunk temp = framingManager.bitDestuff(buffer[k]);
                        byte chksm = temp.chunk[temp.chunkSize];
                        temp = framingManager.getPayLoad(temp);
                        if(temp.chunk[temp.chunkSize-10] == 0)
                            temp.chunk[temp.chunkSize-10] = 1;
                        else
                            temp.chunk[temp.chunkSize-10] = 0;
                        temp = framingManager.getFrame(temp, (byte) 1, (byte) (i+k), (byte)1, (byte)1,chksm);
                        System.out.println("Sending Chunk " + (i + k));
                        System.out.println("Seq no : " + 1);
                        connectionBuilder.write(temp);
                        System.out.println("Chunk Sent");

                    }
                    else {*/
                        System.out.println("Sending Chunk " + (i + k));
                        System.out.println("Seq no : " + 1);
                        connectionBuilder.write(buffer[k]);
                        System.out.println("Chunk Sent");
                    //}
                }
               // ReadFromServer.message = " ";

                time = 0;
                while (acknowledgedCounter != j){
                    try {
                        if ((time % 1000) == 0) {
                            System.out.println("Time Elapsed : " + (time / 1000) + " sec");
                        }
                        Thread.sleep(100);
                        time += 100;
                        if (time == 30000) {
                            for (int k = acknowledgedCounter; k < j; k++) {
                                /*if(k == 2)
                                {
                                    continue;
                                }*/
                                FramingManager framingManager = new FramingManager();
                                FileChunk temp = framingManager.bitDestuff(buffer[k]);
                                byte currSeqNo = temp.chunk[temp.chunkSize+1];
                                byte chunkNo = temp.chunk[temp.chunkSize+2];
                                byte typeNo = temp.chunk[temp.chunkSize+3];
                                currSeqNo++;
                                temp = framingManager.getPayLoad(temp);
                                buffer[k] = framingManager.getFrame(temp, typeNo, chunkNo, currSeqNo, (byte) 0,(byte) 0);
                                System.out.println("Resending Chunk " + (i+k));
                                System.out.println("Seq no : " + currSeqNo);
                                connectionBuilder.write(buffer[k]);
                                System.out.println("Chunk Sent");
                                time = 0;
                            }
                        }
                    } catch (InterruptedException e) {
                        System.out.println("Here");
                        e.printStackTrace();
                    }
                }
                i = i + (j);
                if(i == noOfChunk)
                {
                    fin.close();
                    file = null;
                    connectionBuilder.write("Successful:message");
                    break;
                }
                else
                {
                    System.out.println("5 Chunks Sent");
                    acknowledgedCounter = 0;
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
        }
    }
}


