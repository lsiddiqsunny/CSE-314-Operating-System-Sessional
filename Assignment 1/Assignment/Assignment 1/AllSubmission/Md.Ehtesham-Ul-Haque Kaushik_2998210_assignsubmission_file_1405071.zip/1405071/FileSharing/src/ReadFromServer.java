import java.io.File;
import java.io.IOException;

import static com.sun.xml.internal.messaging.saaj.packaging.mime.util.ASCIIUtility.getBytes;

/**
 * Created by Kaushik on 9/24/2017.
 */
public class ReadFromServer implements Runnable{
    private Thread thr;
    private ConnectionBuilder connectionBuilder;
    public static String message;

    int bytesToRead = 100;
    public static File file;
    int fileId;
    static byte seenChunkNo = 0;
    static FramingManager fm = new FramingManager();


    public ReadFromServer(ConnectionBuilder connectionBuilder) {
        this.connectionBuilder= connectionBuilder;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            while(true) {
                Object o = connectionBuilder.read();
                if (o instanceof FileInfo)
                {
                    FileInfo f = (FileInfo)o;
                    ClientAction(f);
                }
                else if (o instanceof ReceiverFileInfo){
                    ReceiverFileInfo receiverFileInfo = (ReceiverFileInfo)o;
                    ReadFromUser.receiverFileInfo = receiverFileInfo;
                    ClientAction(receiverFileInfo);
                }
                else if (o instanceof FileChunk)
                {
                    FileChunk fileChunk = (FileChunk)o;
                    if(fileChunk.chunk.length != fileChunk.chunkSize)
                    {
                        countAcknowledge(fileChunk);
                    }
                    else
                        SaveFile(fileChunk);
                }
                else {
                    String s = (String) o;
                    message = s;
                    ClientAction(s);
                }
            }
        } catch(Exception e) {
            System.out.println("Disconnected");
            connectionBuilder.closeConnection();
        }

    }

    private static void countAcknowledge(FileChunk fileChunk) {
        FileChunk acknowledgedChunk = fm.bitDestuff(fileChunk);
        byte ackNo = acknowledgedChunk.chunk[fileChunk.chunkSize+2];
        System.out.println("Got Ack No : " + ackNo);
        if(ackNo-seenChunkNo > 1)
        {

        }
        else
        {
            seenChunkNo = (byte) (seenChunkNo + 1);
            FileTransfer.acknowledgedCounter++;
            System.out.println("Acknowledge Count : " + FileTransfer.acknowledgedCounter);
        }
    }

    private void SaveFile(FileChunk fileChunk) {
        try {
            System.out.println("Chunk Size : " + fileChunk.chunkSize);
            ReadFromUser.fout.write(fileChunk.chunk, 0, fileChunk.chunkSize);
            System.out.println("File Saved");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void ClientAction(ReceiverFileInfo receiverFileInfo) {
        System.out.println("Sender : " + receiverFileInfo.sender);
        System.out.println("File : " + receiverFileInfo.name);
        System.out.println("Size : " + receiverFileInfo.size);
    }

    private void ClientAction(String s) {
        if(s.equals("Please Enter Your Student Id : "))
        {
            System.out.println(s);
        }
        if(s.equals("Acknowledged"))
        {

        }
        if(s.equals("Already Connected From This Student ID"))
        {
            System.out.println(s);
            System.out.println("Please Enter Your Student Id : ");
            message = "Please Enter Your Student Id : ";
        }
        if(s.equals("You Are Now Connected, press 's' to send file, press 'c' To Close Connection."))
        {
            System.out.println(s);
        }
        if(s.equals("Please Enter Receiver Student Id"))
        {
            System.out.println(s);
        }
        if(s.equals("You Can Not Send A File To You, Give Another Id"))
        {
            System.out.println(s);
        }
        if(s.equals("Receiver Not Online, Press 's' to try again"))
        {
            System.out.println(s);
        }
        if(s.equals("Please enter File Name : "))
        {
            System.out.println(s);
        }
        if(s.equals("Not Enough Memory In Server, Press 's' To Try Again"))
        {
            System.out.println(s);
        }
        if(s.equals("File Transfer Failed, Press 's' To try Again"))
        {
            System.out.println(s);
        }
        if(s.equals("Do You Want To Receive A File?"))
        {
            System.out.println(s);
        }
        if(s.equals("y/n"))
        {
            System.out.println(s);
        }
        if(s.equals("Receiver Do Not Want To Receive File"))
        {
            System.out.println(s);
            System.out.println("Press 's' To Send File Again");
        }
        if(s.equals("File Size Matched"))
        {
            System.out.println(s);
        }
        if(s.equals("Please Enter File Path : "))
        {
            System.out.println(s);
        }
        if(s.equals("File Successfully Sent"))
        {
            System.out.println(s);
            System.out.println("Press 's' To Send Another File");
        }

        if(s.equals("Receiver Offline, File Transfer Unsuccessful"))
        {
            System.out.println(s);
            System.out.println("Press 's' To Send File Again");
        }
        if(s.equals("File Received"))
        {
            try {
                ReadFromUser.fout.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                ReadFromUser.fout.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println();
            System.out.println(s);
            System.out.println("Press 's' To Send File");

        }

    }
    private void ClientAction(FileInfo s) {
        if (s.filename.equals("chunkSize"))
        {
            bytesToRead = (int)s.filesize;
        }
        if (s.filename.equals("fileId"))
        {
            fileId = (int)s.filesize;
            message = "";
            System.out.println("Sending File...");
            new FileTransfer(file, connectionBuilder, bytesToRead, fileId);
        }
    }
}
