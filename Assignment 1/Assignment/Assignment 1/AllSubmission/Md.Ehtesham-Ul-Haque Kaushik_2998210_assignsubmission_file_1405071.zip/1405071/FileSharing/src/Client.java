/**
 * Created by Kaushik on 9/24/2017.
 */
public class Client {
    public static void main(String args[]) {
        try {
            String serverAddress="127.0.0.1";
            int serverPort=10000;
            ConnectionBuilder connectionBuilder = new ConnectionBuilder(serverAddress,serverPort);
            new ReadFromServer(connectionBuilder);
            new ReadFromUser(connectionBuilder);
        } catch(Exception e) {
            System.out.println(e);
        }
    }
}
