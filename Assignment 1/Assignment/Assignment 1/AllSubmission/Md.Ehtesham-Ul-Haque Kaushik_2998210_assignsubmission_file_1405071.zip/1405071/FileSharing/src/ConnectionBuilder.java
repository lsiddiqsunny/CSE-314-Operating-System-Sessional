import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ConnectionBuilder
{
	private String name;
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;



	public ConnectionBuilder(String s, int port) {
		try {
			this.socket=new Socket(s,port);
			oos=new ObjectOutputStream(socket.getOutputStream());
			ois=new ObjectInputStream(socket.getInputStream());
		} catch (Exception e) {

		}
	}

	public ConnectionBuilder(Socket s) {
		try {
			this.socket = s;
			oos=new ObjectOutputStream(socket.getOutputStream());
			ois=new ObjectInputStream(socket.getInputStream());
		} catch (Exception e) {
		}
	}

    public void setName(String name)
    {
        this.name = name;
    }

	public String getName()
	{
		return name;
	}

    public Socket getSocket() {
        return socket;
    }

    public Object read() {
		Object o = null;
		try {
			o=ois.readObject();
		} catch (Exception e) {
		}
		return o;
	}
	
	public void write(Object o) {
		try {
			oos.writeObject(o);
            oos.flush();
		} catch (IOException e) {
		}
	}

	public void closeConnection() {
		try {
			ois.close();
			oos.close();
		} catch (Exception e) {
		}
	}
}

