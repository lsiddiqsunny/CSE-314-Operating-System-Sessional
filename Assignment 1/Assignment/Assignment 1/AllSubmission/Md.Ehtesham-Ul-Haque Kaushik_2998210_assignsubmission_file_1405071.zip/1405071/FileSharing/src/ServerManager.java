import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

class ReceiverFileInfo implements Serializable
{
    String name;
    int size;
    String sender;
    int fileId;
    ReceiverFileInfo(String name, int size, String sender, int fileId)
    {
        this.name = name;
        this.size = size;
        this.sender = sender;
        this.fileId = fileId;
    }
}

public class ServerManager implements Runnable {
	private Thread thr;
	private ConnectionBuilder senderConnection, receiverConnection;
    public static int fileId;
    String sender;
    String fileName;
    public Hashtable<String, ConnectionBuilder> onlineUsers;
    Random random = new Random();
    public static List<ArrayList<FileChunk>> allSavedChunks;
    ArrayList<FileChunk> aChunk = new ArrayList<>();
    int fileSize;
    int sendingFlag = 0;
    ReceiverFileInfo preparedFile;
    byte seenChunk = 0;


	public ServerManager(Hashtable<String, ConnectionBuilder> onlineUsers, ConnectionBuilder senderConnection,
                         List<ArrayList<FileChunk>> allSavedChunks) {
        this.onlineUsers = onlineUsers;
		this.senderConnection = senderConnection;
        this.allSavedChunks = allSavedChunks;
        System.out.println("Server started with Maximum size = " + Server.serverMemory + " bytes");
        this.thr = new Thread(this);
		thr.start();
	}
	
	public void run() {
		try {
            senderConnection.write("Please Enter Your Student Id : ");
			while(true) {
				Object s = senderConnection.read();
                if(s instanceof FileInfo) {
                    FileInfo f = (FileInfo)s;
                    ServerAction(f);
                }
                else if(s instanceof FileChunk)
                {
                    FileChunk fileChunk = (FileChunk)s;
                    ServerAction(fileChunk);
                }
                else if (s instanceof ReceiverFileInfo)
                {
                    ReceiverFileInfo receiverFileInfo = (ReceiverFileInfo)s;
                    if (receiverFileInfo.name.equals("y")) {
                        preparedFile = receiverFileInfo;
                        //WriteToReceiver(receiverFileInfo);
                        senderConnection.write("Please Enter File Path : ");
                    }
                    else if (receiverFileInfo.name.equals("n"))
                    {
                        RemoveFile(receiverFileInfo);
                    }
                }
                else
                {
                    String s1 = (String)s;
                    ServerAction(s1);
                }
			}
		} catch(Exception e) {
            System.out.println("User : " + sender + " is Offline");
            onlineUsers.remove(sender);
            if (sendingFlag == 1)
            {
                System.out.println("Sender Disconnected, Deleting All Chunks");
                allSavedChunks.remove(fileId);
                allSavedChunks.add(fileId, new ArrayList<>());
                Server.serverMemory = Server.serverMemory + fileSize;
                System.out.println("Available Memory : " + Server.serverMemory);
            }
		}
		senderConnection.closeConnection();
	}

    private void RemoveFile(ReceiverFileInfo receiverFileInfo) {
        allSavedChunks.remove(receiverFileInfo.fileId);
        allSavedChunks.add(fileId, new ArrayList<>());
        Server.serverMemory = Server.serverMemory + receiverFileInfo.size;
        onlineUsers.get(receiverFileInfo.sender).write("Receiver Do Not Want To Receive File");
        System.out.println("User " + sender + " Do Not Want To Receive File From User " + receiverFileInfo.sender);
        System.out.println("Deleting All Chunks Of File Id : " + receiverFileInfo.fileId);
        System.out.println("Available Memory : " + Server.serverMemory);
    }

    private void WriteToReceiver(ReceiverFileInfo receiverFileInfo) {
        if(senderConnection != null) {
            for (int i = 0; i < allSavedChunks.get(receiverFileInfo.fileId).size(); i++) {
                senderConnection.write(allSavedChunks.get(receiverFileInfo.fileId).get(i));
            }
            senderConnection.write("File Received");
            onlineUsers.get(receiverFileInfo.sender).write("File Successfully Sent");
            System.out.println("File Successfully Sent From User " + receiverFileInfo.sender + " To User " + sender);
        }
        else
        {
            System.out.println("Receiver Offline, File Transfer Unsuccessful");
            onlineUsers.get(receiverFileInfo.sender).write("Receiver Offline, File Transfer Unsuccessful");
        }
        System.out.println("Deleting All Chunks");
        allSavedChunks.remove(fileId);
        allSavedChunks.add(fileId, new ArrayList<>());
        Server.serverMemory = Server.serverMemory + receiverFileInfo.size;
        System.out.println("Available Memory : " + Server.serverMemory);
    }

    private void ServerAction(String s) {
        String s1[] = s.split(":");
		if(s1[0].equals("ownStudentId"))
		{
            sender = s1[1].toString();
            if (onlineUsers.get(sender) == null) {
                senderConnection.setName(s1[1].toString());
                onlineUsers.put(s1[1].toString(), senderConnection);
                System.out.println("New User Online : " + s1[1].toString());
                senderConnection.write("You Are Now Connected, press 's' to send file, press 'c' To Close Connection.");
            }
            else
            {
                senderConnection.write("Already Connected From This Student ID");
            }
		}
        if (s1[0].equals("request"))
        {
            System.out.println("File Transfer Requested By User " + sender);
            System.out.println("Asking For Receiver Id");
            sendingFlag = 0;
            senderConnection.write("Please Enter Receiver Student Id");
            aChunk.clear();
        }
        if (s1[0].equals("Timeout"))
        {
            System.out.println("Timeout For User " + sender);
            System.out.println("Deleting All Chunks");
            sendingFlag = 0;
            allSavedChunks.remove(fileId);
            allSavedChunks.add(fileId, new ArrayList<>());
            Server.serverMemory = Server.serverMemory + fileSize;
            System.out.println("Available Memory : " + Server.serverMemory);
        }

        if (s1[0].equals("Successful"))
        {
            System.out.println("All Chunks Received From User " + sender);
            System.out.println("Checking File Size");
            sendingFlag = 0;
            int size = 0;
            System.out.println("file id : " + fileId);
            for (int i = 0; i < allSavedChunks.get(fileId).size(); i++)
            {
                FileChunk s2 = allSavedChunks.get(fileId).get(i);
                System.out.println("Checking Size : " + s2.chunkSize);
                size += s2.chunkSize;
            }
            System.out.println("Size : " + size);
            if(size == fileSize)
            {
                System.out.println("File Size Matched From User " + sender);
                System.out.println("Asking File Transfer Permission From User " + receiverConnection.getName());
                senderConnection.write("File Size Matched");
                receiverConnection.write("Do You Want To Receive A File?");
                receiverConnection.write(new ReceiverFileInfo(fileName, fileSize, sender, fileId));
                receiverConnection.write("y/n");
            }
            else {
                System.out.println("File Size Does Not Match From User " + sender);
                System.out.println("Deleting All Chunks");
                Server.serverMemory = Server.serverMemory + fileSize;
                System.out.println("Available Memory : " + Server.serverMemory);
                allSavedChunks.remove(fileId);
                allSavedChunks.add(fileId, new ArrayList<>());
                senderConnection.write("File Transfer Failed, Press 's' To try Again");

            }
        }
        if (s1[0].equals("receiver"))
        {
            receiverConnection = onlineUsers.get(s1[1].toString());
            if (sender.equals(s1[1].toString()))
            {
                senderConnection.write("You Can Not Send A File To You, Give Another Id");
            }
            else {
                System.out.println("User " + sender + " Wants To Send A File To User " + s1[1].toString());
                System.out.println("Checking Receiver Status");
                if (receiverConnection != null) {
                    System.out.println("User " + receiverConnection.getName() + " is Online, Asking File Name");
                    senderConnection.write("Please enter File Name : ");
                } else {
                    System.out.println("Receiver Is Offline.");
                    senderConnection.write("Receiver Not Online, Press 's' to try again");
                }
            }
        }

        if (s1[0].equals("path"))
        {
            WriteToReceiver(preparedFile);
        }
	}

    private void ServerAction(FileInfo fileInfo)
    {
        System.out.println("Requested Filename : " + fileInfo.filename + " Size : " + fileInfo.filesize );
        fileName = fileInfo.filename;
        fileSize = (int)fileInfo.filesize;
        if(Server.serverMemory - fileInfo.filesize < 0)
        {
            System.out.println("Not Enough Space in the Buffer");
            senderConnection.write("Not Enough Memory In Server, Press 's' To Try Again");
        }
        else
        {
            System.out.println("Enough Space In Buffer, Sending Chunk Size and File Id");
            Server.serverMemory = Server.serverMemory - fileSize;
            System.out.println("Available Memory : " + Server.serverMemory);
            int chunkSize = random.nextInt(100*1024) + (100*1024);
            senderConnection.write(new FileInfo("chunkSize", chunkSize));
            senderConnection.write(new FileInfo("fileId", Server.fileId));
            allSavedChunks.add(Server.fileId, aChunk);
            fileId = Server.fileId;
            Server.fileId++;
        }
    }
    private void ServerAction(FileChunk fileChunk)
    {
        /*try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        FramingManager framingManager = new FramingManager();
        int cs = 0;
        System.out.println("Chunk Received From User " + sender);
        System.out.println("Chunk Size : " + fileChunk.chunkSize);
        cs+= fileChunk.chunkSize;
        FileChunk deStuffedChunk = framingManager.bitDestuff(fileChunk);

        byte ack = deStuffedChunk.chunk[fileChunk.chunkSize+2];
        byte checksum = deStuffedChunk.chunk[fileChunk.chunkSize];
        boolean hasChecksumError = framingManager.hasChecksumError(deStuffedChunk, checksum);
        System.out.println("Error : " + hasChecksumError);
        System.out.println("Chunk No : " + ack);
        if(ack == seenChunk && (!hasChecksumError))
        {
            seenChunk++;
            //System.out.println("Total Received : " + cs);
            //System.out.println(new String(fileChunk.chunk));
            //this.fileId = fileChunk.fileId;
            FileChunk originalChunk = framingManager.getPayLoad(deStuffedChunk);
            System.out.println("Sending Acknowledgement " + ack);
            FileChunk ackChunk = new FileChunk();
            ackChunk.fileId = fileChunk.fileId;
            ackChunk.chunkSize = 1;
            byte [] dummy = new byte[1];
            dummy[0] = 0;
            ackChunk.chunk = dummy;
            FileChunk stuffedAckChunk = framingManager.getFrame(ackChunk, (byte)0 ,ack , (byte) 1, (byte) 0, (byte) 0);
            sendingFlag = 1;
            allSavedChunks.get(fileChunk.fileId).add(originalChunk);
            senderConnection.write(stuffedAckChunk);
        }
        else if(hasChecksumError)
            System.out.println("Error on chunk : " + ack);
    }
}


