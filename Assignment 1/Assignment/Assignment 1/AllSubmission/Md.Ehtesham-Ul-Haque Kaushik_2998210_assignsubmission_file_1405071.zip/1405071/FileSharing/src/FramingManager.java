import java.io.File;

import static java.lang.Math.ceil;

/**
 * Created by Kaushik on 11/4/2017.
 */
public class FramingManager {
    FramingManager()
    {

    }
    static byte findChecksum(byte[] bytes, int length)
    {
        byte checkSum = bytes[0];
        for(int j = 1; j < length; j++)
        {
            checkSum = (byte) (checkSum ^ bytes[j]);
        }
        return checkSum;
    }
    static void printBits(byte[] bytes)
    {
        int mask = 0b10000000;
        for (int i = bytes.length - 1; i >= 0; i--)
        {
            byte aByte = bytes[i];
            for (int j = 0; j < 8; j++)
            {
                int b = aByte & mask;
                aByte = (byte) (aByte << 1);
                if (b == 0)
                {
                    System.out.print(0);
                }
                else {
                    System.out.print(1);
                }
            }
            System.out.print("  ");
        }
        System.out.println();
    }

    static byte[] getStuffedFrame(byte[] unstuffedFrame, int totalSize)
    {
        //System.out.println("Total Size Needed : " + totalSize);
        byte[] stuffedFrame = new byte[totalSize];
        byte mask = 1;
        byte temp = 0;
        int pos = 0, count = 0;

        int k = 1;
        for (int i = 0; i < unstuffedFrame.length; i++)
        {
            byte aByte = unstuffedFrame[i];
            for (int j = 0; j < 8; j++)
            {
                int b = aByte & mask;
                aByte = (byte) (aByte >> 1);
                if (b == 0)
                {
                    count = 0;
                    pos++;
                }
                else {
                    temp = (byte) (temp | (1 << pos));
                    pos++;
                    count++;
                }
                if (pos == 8)
                {
                    stuffedFrame[k] = temp;
                    pos = 0;
                    k++;
                    temp = 0;
                }
                if (count == 5)
                {
                    count = 0;
                    pos++;
                    if (pos == 8)
                    {
                        stuffedFrame[k] = temp;
                        pos = 0;
                        k++;
                        temp = 0;
                    }
                }

            }
        }
        stuffedFrame[0] = 126;
        stuffedFrame[totalSize-1] = 126;
        return stuffedFrame;
    }
    public FileChunk getFrame(FileChunk givenChunk, byte type, byte chunkNo, byte seqNo, byte chkType, byte chksm)
    {
        System.out.println("Actual Payload Before Extending");
        printBits(givenChunk.chunk);
        byte mask = 00000001;
        int count = 0, bitCount = 0;
        double extra;


        FileChunk preparedChunk = new FileChunk();
        preparedChunk.chunkSize = givenChunk.chunkSize;
        preparedChunk.fileId = givenChunk.fileId;


        byte[] extendedByte = new byte[givenChunk.chunkSize+4];
        for (int j = 0; j < givenChunk.chunkSize; j++)
        {
            extendedByte[j] = givenChunk.chunk[j];
        }
        extendedByte[givenChunk.chunkSize+3] = type;
        extendedByte[givenChunk.chunkSize+2] = chunkNo;
        extendedByte[givenChunk.chunkSize+1] = seqNo;
        if (chkType == 0) {
            byte checkSum = findChecksum(givenChunk.chunk, givenChunk.chunkSize);
            extendedByte[givenChunk.chunkSize] = checkSum;
        }
        else
        {
            extendedByte[givenChunk.chunkSize] = chksm;
        }
        System.out.println("Check Sum of Chunk " + chunkNo + " is : " + extendedByte[givenChunk.chunkSize]);



        byte[] temp = extendedByte;


        for (int i = 0; i < extendedByte.length; i++)
        {
            byte aByte = temp[i];
            for (int j = 0; j < 8; j++)
            {
                int b = aByte & mask;
                aByte = (byte) (aByte >> 1);
                if (b == 0)
                {
                    count = 0;
                }
                else {
                    count++;
                }
                if (count == 5)
                {
                    bitCount++;
                    count = 0;
                }
            }
        }
        //System.out.println(bitCount);

        extra = ceil((double) bitCount /8);
        extra+=2;

        System.out.println("After Extension : ");
        printBits(extendedByte);

        preparedChunk.chunk = getStuffedFrame(extendedByte, extendedByte.length+(int) extra);

        System.out.println("After Stuffing : ");
        printBits(preparedChunk.chunk);

        return preparedChunk;
    }

    boolean hasChecksumError(FileChunk fileChunk, byte checksumValue)
    {
        boolean error = false;
        try {
            byte checkSum = findChecksum(fileChunk.chunk, fileChunk.chunkSize);
            System.out.println("CheckSum of Chunk " + checkSum);
            if(checkSum == checksumValue)
                error = false;
            else
                error = true;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return error;
    }

    FileChunk bitDestuff(FileChunk givenChunk)
    {
        System.out.println("Stuffed Chunk : ");
        printBits(givenChunk.chunk);
        FileChunk destuffedChunk = new FileChunk();
        destuffedChunk.chunkSize = givenChunk.chunkSize;
        destuffedChunk.fileId = givenChunk.fileId;
        byte[] t = new byte[1];
        byte temp = 0;
        byte mask = 1;
        int pos = 0, count = 0, k = 0, flag = 1, shiftflag = 0;
        byte[] deStuffedByte = new byte[givenChunk.chunkSize+4];
        try {
            for (int i = 1; (i < givenChunk.chunk.length - 1) && (flag == 1); i++) {
                byte aByte = givenChunk.chunk[i];
                for (int j = 0; j < 8; j++) {
                    if(shiftflag == 1)
                    {
                        aByte = (byte) (aByte >> 1);
                        j++;
                        shiftflag = 0;
                    }
                    int b = aByte & mask;
                    aByte = (byte) (aByte >> 1);

                    if (b == 0) {
                        count = 0;
                        pos++;
                    } else {
                        temp = (byte) (temp | (1 << pos));
                        pos++;
                        count++;
                    }
                    if (pos == 8) {
                        //System.out.println("Found A Byte : " + temp);
                        deStuffedByte[k] = temp;
                        pos = 0;
                        k++;
                        if (k == givenChunk.chunkSize + 4) {
                            flag = 0;
                            break;
                        }
                        temp = 0;
                    }
                    if (count == 5) {
                        count = 0;
                        if(j == 7)
                        {
                            shiftflag = 1;
                        }
                        else {
                            aByte = (byte) (aByte >> 1);
                            j++;
                        }
                    }
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Destuffed Chunk : ");
        printBits(deStuffedByte);
        destuffedChunk.chunk = deStuffedByte;
        return destuffedChunk;
    }

    FileChunk getPayLoad(FileChunk fileChunk)
    {
        FileChunk retrivedChunk = fileChunk;
        try {
            byte[] payLoad = new byte[fileChunk.chunkSize];
            for (int i = 0; i < fileChunk.chunkSize; i++)
            {
                payLoad[i] = fileChunk.chunk[i];
            }
            retrivedChunk.chunk = payLoad;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return retrivedChunk;
    }
}
