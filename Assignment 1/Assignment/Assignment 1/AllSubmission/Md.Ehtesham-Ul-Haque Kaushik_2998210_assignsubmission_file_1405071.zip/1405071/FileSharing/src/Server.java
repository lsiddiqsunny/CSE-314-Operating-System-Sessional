import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

/**
 * Created by Kaushik on 9/23/2017.
 */
public class Server
{
    private ServerSocket serverSocket;
    public Hashtable<String, ConnectionBuilder> onlineUsers;
    public List<ArrayList<FileChunk>> allSavedChunks = Collections.synchronizedList(new ArrayList<>());
    public static int fileId = 0;
    public static int serverMemory = 10*1024*1024;

    Server() {
        onlineUsers = new Hashtable<>();
        try {
            serverSocket = new ServerSocket(10000);
            while (true) {
                Socket clientSock = serverSocket.accept();
                System.out.println("Accepted" + clientSock.getPort());
                ConnectionBuilder connectionBuilder = new ConnectionBuilder(clientSock);
                new ServerManager(onlineUsers, connectionBuilder, allSavedChunks);
            }
        }catch(Exception e) {
            System.out.println("Server starts:"+e);
        }
    }

    public static void main(String args[]) {
        Server objServer = new Server();
    }
}
