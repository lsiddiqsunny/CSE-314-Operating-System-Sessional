package Client;

import java.io.File;

/**
 * Created by Nahiyan on 30/09/2017.
 */
public class FileUtil {

    private File file ;




}
