package Utilities;

/**
 * Created by Rupak on 9/30/2017.
 */
public class createID {
    public static int ID=0;
    public static int getID()
    {
        ID++;
        return ID;
    }
}
