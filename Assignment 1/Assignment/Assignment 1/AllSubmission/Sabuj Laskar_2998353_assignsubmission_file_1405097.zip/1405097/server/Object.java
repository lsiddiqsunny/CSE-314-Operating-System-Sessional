/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatsocket;

/**
 *
 * @author sabuj
 */
public class Object {
    public byte[] b;
    public int len;

    public Object(byte[] b, int len) {
        this.b = b;
        this.len = len;
    }

    
    
}
