package UI;

public interface LogWindow {
    void appendToLog(String text);
    void appendToFrameLog(String text);
}
