/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package networkingftpassignment;

/**
 *
 * @author HP
 */
public class helper {
    public static void main(String[] args){
        String s = "101010101";
        String s2 = s.replaceFirst("01", "");
        System.out.println(s+"\n"+s2);
        
        
    }
    
}
