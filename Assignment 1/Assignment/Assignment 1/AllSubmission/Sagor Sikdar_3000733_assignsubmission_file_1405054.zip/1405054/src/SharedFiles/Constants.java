package SharedFiles;

public class Constants {
    public static final String PATHNAME_SERVER= "C:\\Users\\User\\Desktop\\Server\\";
    public static final String PATHNAME_CLIENT="C:\\Users\\User\\Desktop\\Client\\";
    public static final int PRINT_BYTE_STRING=0;
    public static final int NO_of_FILE=1000;
    public static final int TIME_OUT_TIME=5000;
}
